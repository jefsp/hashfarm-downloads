#Requires -Version 5.1
<#
.SYNOPSIS
    go2mine hashfarm-agent - Windows Installer
.DESCRIPTION
    Instala o hashfarm-agent como servico do Windows (Task Scheduler).
    Requer Python 3.9+ instalado.
.PARAMETER AgentKey
    Sua Agent Key do dashboard go2mine.com (opcional - pode ser configurada depois).
.PARAMETER InstallDir
    Diretorio de instalacao (padrao: C:\hashfarm-agent).
.EXAMPLE
    .\_install.ps1 -AgentKey "sua-chave-aqui"
.EXAMPLE
    .\_install.ps1 -InstallDir "D:\hashfarm-agent"
#>

param(
    [string]$AgentKey   = "",
    [string]$InstallDir = "C:\hashfarm-agent"
)

$DASHBOARD_URL  = "https://app.go2mine.com"
$TASK_NAME      = "go2mine hashfarm-agent"
$ErrorActionPreference = "Stop"

# ── Cores / helpers ──────────────────────────────────────────
function Ok($msg)   { Write-Host "  [OK] $msg" -ForegroundColor Green }
function Info($msg) { Write-Host "  -->  $msg" -ForegroundColor Cyan }
function Warn($msg) { Write-Host "  [!]  $msg" -ForegroundColor Yellow }
function Die($msg)  { Write-Host "  [X]  $msg" -ForegroundColor Red; exit 1 }
function Hdr($msg)  { Write-Host "`n  $msg" -ForegroundColor White }

# ── Banner ───────────────────────────────────────────────────
Clear-Host
Write-Host ""
Write-Host "  ██████   ██████  ██████  ███    ███ ██ ███    ██ ███████" -ForegroundColor Cyan
Write-Host " ██       ██  ████      ██ ████  ████ ██ ████   ██ ██     " -ForegroundColor Cyan
Write-Host " ██   ███ ██ ██ ██  █████  ██ ████ ██ ██ ██ ██  ██ █████  " -ForegroundColor Cyan
Write-Host " ██    ██ ████  ██ ██      ██  ██  ██ ██ ██  ██ ██ ██     " -ForegroundColor Cyan
Write-Host "  ██████   ██████  ███████ ██      ██ ██ ██   ████ ███████" -ForegroundColor Cyan
Write-Host ""
Write-Host "  hashfarm-agent - instalador Windows" -ForegroundColor White
Write-Host "  $DASHBOARD_URL" -ForegroundColor DarkCyan
Write-Host ""

# ── Admin ────────────────────────────────────────────────────
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
if (-not $isAdmin) {
    Die "Execute este script como Administrador (clique direito -> 'Executar como administrador')"
}

# ── Python 3.9+ ──────────────────────────────────────────────
Hdr "1/5  Verificando Python"
$pythonCmd = $null
foreach ($cmd in @("python", "python3", "py")) {
    try {
        $ver = & $cmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
        $major, $minor = $ver.Split(".")
        if ([int]$major -ge 3 -and [int]$minor -ge 9) {
            $pythonCmd = $cmd
            Ok "Encontrado: $cmd (v$ver)"
            break
        }
    } catch { }
}

if (-not $pythonCmd) {
    Warn "Python 3.9+ nao encontrado. Tentando instalar via winget..."
    try {
        $winget = Get-Command winget -ErrorAction Stop
        & winget install --id Python.Python.3.11 -e --silent --accept-package-agreements --accept-source-agreements 2>&1 | Out-Null
        $machinePath = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
        $userPath    = [System.Environment]::GetEnvironmentVariable("Path", "User")
        $env:Path    = $machinePath + ";" + $userPath
        Ok "Python instalado via winget."
    } catch {
        Warn "winget nao disponivel. Baixe Python manualmente em:"
        Write-Host "  https://www.python.org/downloads/" -ForegroundColor Cyan
        Write-Host "  IMPORTANTE: Marque 'Add Python to PATH' durante a instalacao." -ForegroundColor Yellow
        $null = Read-Host "  Pressione ENTER apos instalar o Python"
    }
    foreach ($cmd in @("python", "python3", "py")) {
        try {
            $ver = & $cmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
            $major, $minor = $ver.Split(".")
            if ([int]$major -ge 3 -and [int]$minor -ge 9) {
                $pythonCmd = $cmd; Ok "Python detectado: $cmd (v$ver)"; break
            }
        } catch { }
    }
    if (-not $pythonCmd) { Die "Python 3.9+ nao encontrado. Instale manualmente e tente novamente." }
}

# ── Copia arquivos ───────────────────────────────────────────
Hdr "2/5  Instalando em $InstallDir"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

if (Test-Path $InstallDir) {
    Warn "Diretorio ja existe - atualizando arquivos do agente..."
} else {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
}

Copy-Item -Recurse -Force "$scriptDir\agent" "$InstallDir\"
Copy-Item -Force "$scriptDir\requirements.txt" "$InstallDir\"
if (Test-Path "$scriptDir\pyproject.toml")        { Copy-Item -Force "$scriptDir\pyproject.toml"        "$InstallDir\" }
if (Test-Path "$scriptDir\_uninstall.ps1")        { Copy-Item -Force "$scriptDir\_uninstall.ps1"        "$InstallDir\" }
if (Test-Path "$scriptDir\Install-agent.bat")     { Copy-Item -Force "$scriptDir\Install-agent.bat"     "$InstallDir\" }
if (Test-Path "$scriptDir\Uninstall-agent.bat")   { Copy-Item -Force "$scriptDir\Uninstall-agent.bat"   "$InstallDir\" }
if (Test-Path "$scriptDir\Restart-agent.bat")     { Copy-Item -Force "$scriptDir\Restart-agent.bat"     "$InstallDir\" }
if (Test-Path "$scriptDir\Update-agent.bat")      { Copy-Item -Force "$scriptDir\Update-agent.bat"      "$InstallDir\" }
Ok "Arquivos copiados para $InstallDir"

Info "Criando ambiente virtual Python..."
& $pythonCmd -m venv "$InstallDir\venv"
Ok "Virtualenv criado"

Info "Instalando dependencias (pode demorar alguns segundos)..."
& "$InstallDir\venv\Scripts\pip.exe" install --quiet --upgrade pip
& "$InstallDir\venv\Scripts\pip.exe" install --quiet -r "$InstallDir\requirements.txt"
Ok "Dependencias instaladas"

$configDest = "$InstallDir\config.toml"
if (-not (Test-Path $configDest)) {
    Copy-Item -Force "$scriptDir\config.template.toml" $configDest
    Ok "config.toml criado a partir do template"
} else {
    Ok "config.toml ja existe - mantido sem alteracoes"
}

# ── Agent Key ─────────────────────────────────────────────────
Hdr "3/5  Configurando Agent Key"
if ([string]::IsNullOrWhiteSpace($AgentKey)) {
    Write-Host ""
    Write-Host "  Voce precisa de uma Agent Key do dashboard go2mine." -ForegroundColor Yellow
    Write-Host "  Acesse: $DASHBOARD_URL -> Configuracoes -> Chaves do Agente" -ForegroundColor Cyan
    Write-Host ""
    $AgentKey = Read-Host "  Cole sua Agent Key aqui (ou ENTER para pular)"
}

if (-not [string]::IsNullOrWhiteSpace($AgentKey)) {
    $config = Get-Content $configDest -Raw
    $config = $config -replace 'agent_key\s*=\s*"[^"]*"', "agent_key = `"$AgentKey`""
    Set-Content -Path $configDest -Value $config -Encoding UTF8
    Ok "Agent Key configurada"
} else {
    Warn "Agent Key nao configurada. Edite $configDest antes de iniciar o agente."
}

# ── Script de execucao ────────────────────────────────────────
Hdr "4/5  Criando script de inicializacao"

$runScript  = "$InstallDir\_run-agent.ps1"
$pythonExe  = "$InstallDir\venv\Scripts\python.exe"

$psWrapper = "Set-Location `"$InstallDir`"`r`n"
$psWrapper += "`$proc = Start-Process -FilePath `"$pythonExe`" ``" + "`r`n"
$psWrapper += "    -ArgumentList `"-m`", `"agent.main`" ``" + "`r`n"
$psWrapper += "    -WorkingDirectory `"$InstallDir`" ``" + "`r`n"
$psWrapper += "    -WindowStyle Hidden ``" + "`r`n"
$psWrapper += "    -PassThru" + "`r`n"
$psWrapper += "`$proc.WaitForExit()" + "`r`n"

Set-Content -Path $runScript -Value $psWrapper -Encoding UTF8
Ok "Script interno de execucao criado"

# ── Task Scheduler ────────────────────────────────────────────
Hdr "5/5  Registrando no Task Scheduler (inicio automatico)"

$existingTask = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
if ($existingTask) {
    Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false
    Info "Tarefa anterior removida"
}

$action = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument "-NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$InstallDir\_run-agent.ps1`"" `
    -WorkingDirectory $InstallDir

$trigger = New-ScheduledTaskTrigger -AtStartup

$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Hours 0) `
    -RestartCount 5 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -StartWhenAvailable `
    -RunOnlyIfNetworkAvailable

$principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest

Register-ScheduledTask `
    -TaskName $TASK_NAME `
    -Action $action `
    -Trigger $trigger `
    -Settings $settings `
    -Principal $principal `
    -Description "go2mine hashfarm-agent - ASIC Mining Monitor ($DASHBOARD_URL)" | Out-Null

Ok "Tarefa registrada: '$TASK_NAME' (inicia com o Windows)"

if (-not [string]::IsNullOrWhiteSpace($AgentKey)) {
    Info "Iniciando o agente agora..."
    Start-ScheduledTask -TaskName $TASK_NAME
    Start-Sleep -Seconds 2
    $state = (Get-ScheduledTask -TaskName $TASK_NAME).State
    if ($state -eq "Running") {
        Ok "Agente iniciado! (estado: $state)"
    } else {
        Warn "Agente pode nao ter iniciado ainda (estado: $state). Verifique os logs."
    }
} else {
    Warn "Agente NAO iniciado - configure a Agent Key no config.toml primeiro."
    Write-Host "  Depois execute: Start-ScheduledTask -TaskName '$TASK_NAME'" -ForegroundColor Cyan
}

# ── Resumo ───────────────────────────────────────────────────
Write-Host ""
Write-Host "  ============================================" -ForegroundColor Green
Write-Host "    Instalacao concluida!" -ForegroundColor White
Write-Host "  ============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Diretorio:   $InstallDir" -ForegroundColor White
Write-Host "  Config:      $InstallDir\config.toml" -ForegroundColor White
Write-Host "  Parar:       Stop-ScheduledTask -TaskName '$TASK_NAME'" -ForegroundColor White
Write-Host "  Iniciar:     Start-ScheduledTask -TaskName '$TASK_NAME'" -ForegroundColor White
Write-Host "  Dashboard:   $DASHBOARD_URL" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Proximos passos:" -ForegroundColor Yellow
Write-Host "  1. Acesse $DASHBOARD_URL e faca login"
Write-Host "  2. Seus ASICs aparecerao automaticamente no dashboard"
Write-Host ""
