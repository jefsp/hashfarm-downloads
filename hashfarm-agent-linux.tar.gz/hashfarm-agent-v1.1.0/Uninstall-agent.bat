@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~f0\"' -Verb RunAs"
    exit /b
)
echo Desinstalando agente go2mine...
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0_uninstall.ps1"
if %errorlevel% neq 0 (
    echo.
    echo [ERRO] A desinstalacao falhou. Leia a mensagem acima.
)
pause
