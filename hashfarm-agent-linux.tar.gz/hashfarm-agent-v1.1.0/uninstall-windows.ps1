#Requires -Version 5.1
# go2mine hashfarm-agent — Desinstalador Windows
param([string]$InstallDir = "C:\hashfarm-agent")

$TASK_NAME = "go2mine hashfarm-agent"

function Ok($m)   { Write-Host "  [OK] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  [!]  $m" -ForegroundColor Yellow }

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
if (-not $isAdmin) { Write-Host "  [X] Execute como Administrador." -ForegroundColor Red; exit 1 }

Write-Host "`n  go2mine hashfarm-agent — Desinstalação`n" -ForegroundColor Red
$resp = Read-Host "  Tem certeza que deseja remover o hashfarm-agent? [s/N]"
if ($resp -notmatch "^[sS]$") { Write-Host "  Cancelado."; exit 0 }

# Para e remove a tarefa agendada
$task = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
if ($task) {
    if ($task.State -eq "Running") {
        Stop-ScheduledTask -TaskName $TASK_NAME
        Ok "Agente parado"
    }
    Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false
    Ok "Tarefa '$TASK_NAME' removida do Task Scheduler"
}

# Pergunta sobre config
$keep = Read-Host "  Manter config.toml (recomendado para reinstalação)? [S/n]"
if ($keep -match "^[nN]$") {
    if (Test-Path $InstallDir) { Remove-Item -Recurse -Force $InstallDir }
    Ok "Diretório $InstallDir removido"
} else {
    if (Test-Path $InstallDir) {
        Get-ChildItem $InstallDir -Exclude "config.toml","hashfarm.db" | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        Ok "Arquivos removidos (config.toml e hashfarm.db preservados)"
    }
}

Write-Host "`n  Desinstalação concluída.`n" -ForegroundColor Green
