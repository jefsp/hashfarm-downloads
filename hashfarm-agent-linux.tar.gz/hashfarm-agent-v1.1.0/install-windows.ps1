#Requires -Version 5.1
<#
.SYNOPSIS
    go2mine hashfarm-agent — Windows Installer
.DESCRIPTION
    Instala o hashfarm-agent como serviço do Windows (Task Scheduler).
    Requer Python 3.9+ instalado.
.PARAMETER AgentKey
    Sua Agent Key do dashboard go2mine.com (opcional — pode ser configurada depois).
.PARAMETER InstallDir
    Diretório de instalação (padrão: C:\hashfarm-agent).
.EXAMPLE
    .\install-windows.ps1 -AgentKey "sua-chave-aqui"
.EXAMPLE
    .\install-windows.ps1 -InstallDir "D:\hashfarm-agent"
#>

param(
    [string]$AgentKey   = "",
    [string]$InstallDir = "C:\hashfarm-agent"
)

$DASHBOARD_URL  = "https://app.go2mine.com"
$SERVICE_NAME   = "hashfarm-agent"
$TASK_NAME      = "go2mine hashfarm-agent"
$ErrorActionPreference = "Stop"

# ── Cores / helpers ──────────────────────────────────────────
function Ok($msg)   { Write-Host "  [OK] $msg" -ForegroundColor Green }
function Info($msg) { Write-Host "  -->  $msg" -ForegroundColor Cyan }
function Warn($msg) { Write-Host "  [!]  $msg" -ForegroundColor Yellow }
function Die($msg)  { Write-Host "  [X]  $msg" -ForegroundColor Red; exit 1 }
function Hdr($msg)  { Write-Host "`n  $msg" -ForegroundColor White }

# ── Banner ───────────────────────────────────────────────────
Clear-Host
Write-Host ""
Write-Host "  ██████   ██████  ██████  ███    ███ ██ ███    ██ ███████" -ForegroundColor Cyan
Write-Host " ██       ██  ████      ██ ████  ████ ██ ████   ██ ██     " -ForegroundColor Cyan
Write-Host " ██   ███ ██ ██ ██  █████  ██ ████ ██ ██ ██ ██  ██ █████  " -ForegroundColor Cyan
Write-Host " ██    ██ ████  ██ ██      ██  ██  ██ ██ ██  ██ ██ ██     " -ForegroundColor Cyan
Write-Host "  ██████   ██████  ███████ ██      ██ ██ ██   ████ ███████" -ForegroundColor Cyan
Write-Host ""
Write-Host "  hashfarm-agent — instalador Windows" -ForegroundColor White
Write-Host "  $DASHBOARD_URL" -ForegroundColor DarkCyan
Write-Host ""

# ── Admin ────────────────────────────────────────────────────
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
if (-not $isAdmin) {
    Die "Execute este script como Administrador (clique direito → 'Executar como administrador')"
}

# ── Python 3.9+ ──────────────────────────────────────────────
Hdr "1/5  Verificando Python"
$pythonCmd = $null
foreach ($cmd in @("python", "python3", "py")) {
    try {
        $ver = & $cmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
        $major, $minor = $ver.Split(".")
        if ([int]$major -ge 3 -and [int]$minor -ge 9) {
            $pythonCmd = $cmd
            Ok "Encontrado: $cmd (v$ver)"
            break
        }
    } catch { }
}

if (-not $pythonCmd) {
    Warn "Python 3.9+ não encontrado. Tentando instalar via winget..."
    try {
        $winget = Get-Command winget -ErrorAction Stop
        & winget install --id Python.Python.3.11 -e --silent --accept-package-agreements --accept-source-agreements 2>&1 | Out-Null
        # Refresh PATH
        $env:Path = [System.Environment]::GetEnvironmentVariable('Path','Machine') + ';' + [System.Environment]::GetEnvironmentVariable('Path','User')
        Ok "Python instalado via winget."
    } catch {
        Warn "winget não disponível. Baixe Python manualmente em:"
        Write-Host "  https://www.python.org/downloads/" -ForegroundColor Cyan
        Write-Host "  IMPORTANTE: Marque 'Add Python to PATH' durante a instalação." -ForegroundColor Yellow
        $null = Read-Host "  Pressione ENTER após instalar o Python"
    }
    # Tenta de novo
    foreach ($cmd in @("python", "python3", "py")) {
        try {
            $ver = & $cmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
            $major, $minor = $ver.Split(".")
            if ([int]$major -ge 3 -and [int]$minor -ge 9) {
                $pythonCmd = $cmd; Ok "Python detectado: $cmd (v$ver)"; break
            }
        } catch { }
    }
    if (-not $pythonCmd) { Die "Python 3.9+ não encontrado. Instale manualmente e tente novamente." }
}

# ── Copia arquivos ───────────────────────────────────────────
Hdr "2/5  Instalando em $InstallDir"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

if (Test-Path $InstallDir) {
    Warn "Diretório já existe — atualizando arquivos do agente..."
} else {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
}

# Copia código do agente
Copy-Item -Recurse -Force "$scriptDir\agent" "$InstallDir\"
Copy-Item -Force "$scriptDir\requirements.txt" "$InstallDir\"
if (Test-Path "$scriptDir\pyproject.toml")         { Copy-Item -Force "$scriptDir\pyproject.toml"         "$InstallDir\" }
if (Test-Path "$scriptDir\uninstall-windows.ps1")  { Copy-Item -Force "$scriptDir\uninstall-windows.ps1"  "$InstallDir\" }
if (Test-Path "$scriptDir\desinstalar-agente.bat") { Copy-Item -Force "$scriptDir\desinstalar-agente.bat" "$InstallDir\" }
if (Test-Path "$scriptDir\reiniciar-agente.bat")   { Copy-Item -Force "$scriptDir\reiniciar-agente.bat"   "$InstallDir\" }
Ok "Arquivos copiados para $InstallDir"

# Cria virtualenv
Info "Criando ambiente virtual Python..."
& $pythonCmd -m venv "$InstallDir\venv"
Ok "Virtualenv criado"

# Instala dependências
Info "Instalando dependências (pode demorar alguns segundos)..."
& "$InstallDir\venv\Scripts\pip.exe" install --quiet --upgrade pip
& "$InstallDir\venv\Scripts\pip.exe" install --quiet -r "$InstallDir\requirements.txt"
Ok "Dependências instaladas"

# Config
$configDest = "$InstallDir\config.toml"
if (-not (Test-Path $configDest)) {
    Copy-Item -Force "$scriptDir\config.template.toml" $configDest
    Ok "config.toml criado a partir do template"
} else {
    Ok "config.toml já existe — mantido sem alterações"
}

# ── Agent Key ─────────────────────────────────────────────────
Hdr "3/5  Configurando Agent Key"
if ([string]::IsNullOrWhiteSpace($AgentKey)) {
    Write-Host ""
    Write-Host "  Você precisa de uma Agent Key do dashboard go2mine." -ForegroundColor Yellow
    Write-Host "  Acesse: $DASHBOARD_URL → Configurações → Chaves do Agente" -ForegroundColor Cyan
    Write-Host ""
    $AgentKey = Read-Host "  Cole sua Agent Key aqui (ou ENTER para pular)"
}

if (-not [string]::IsNullOrWhiteSpace($AgentKey)) {
    $config = Get-Content $configDest -Raw
    $config = $config -replace 'agent_key\s*=\s*"[^"]*"', "agent_key = `"$AgentKey`""
    Set-Content -Path $configDest -Value $config -Encoding UTF8
    Ok "Agent Key configurada"
} else {
    Warn "Agent Key não configurada. Edite $configDest antes de iniciar o agente."
}

# ── Script de execução ────────────────────────────────────────
Hdr "4/5  Criando script de inicialização"

$runScript = @"
@echo off
cd /d "$InstallDir"
"$InstallDir\venv\Scripts\python.exe" -m agent.main
"@
Set-Content -Path "$InstallDir\run-agent.bat" -Value $runScript -Encoding ASCII

# Batch de reinicialização rápida (duplo-clique → pede UAC → reinicia)
$restartBat = @"
@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)
echo Reiniciando agente go2mine...
schtasks /End /TN "go2mine hashfarm-agent" >nul 2>&1
timeout /t 2 /nobreak >nul
schtasks /Run /TN "go2mine hashfarm-agent"
echo Agente reiniciado com sucesso!
timeout /t 3 /nobreak >nul
"@
Set-Content -Path "$InstallDir\reiniciar-agente.bat" -Value $restartBat -Encoding ASCII
Ok "Atalho 'reiniciar-agente.bat' criado em $InstallDir"

# Script PowerShell wrapper (para Task Scheduler sem janela)
$psWrapper = @"
Set-Location "$InstallDir"
`$proc = Start-Process -FilePath "$InstallDir\venv\Scripts\python.exe" ``
    -ArgumentList "-m", "agent.main" ``
    -WorkingDirectory "$InstallDir" ``
    -WindowStyle Hidden ``
    -PassThru
`$proc.WaitForExit()
"@
Set-Content -Path "$InstallDir\run-agent.ps1" -Value $psWrapper -Encoding UTF8
Ok "Scripts de execução criados"

# ── Task Scheduler ────────────────────────────────────────────
Hdr "5/5  Registrando no Task Scheduler (início automático)"

# Remove tarefa existente se houver
$existingTask = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
if ($existingTask) {
    Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false
    Info "Tarefa anterior removida"
}

$action = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument "-NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$InstallDir\run-agent.ps1`"" `
    -WorkingDirectory $InstallDir

$trigger = New-ScheduledTaskTrigger -AtStartup

$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Hours 0) `
    -RestartCount 5 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -StartWhenAvailable `
    -RunOnlyIfNetworkAvailable

$principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest

Register-ScheduledTask `
    -TaskName $TASK_NAME `
    -Action $action `
    -Trigger $trigger `
    -Settings $settings `
    -Principal $principal `
    -Description "go2mine hashfarm-agent — ASIC Mining Monitor ($DASHBOARD_URL)" | Out-Null

Ok "Tarefa registrada: '$TASK_NAME' (inicia com o Windows)"

# Inicia agora se a Agent Key foi configurada
if (-not [string]::IsNullOrWhiteSpace($AgentKey)) {
    Info "Iniciando o agente agora..."
    Start-ScheduledTask -TaskName $TASK_NAME
    Start-Sleep -Seconds 2
    $state = (Get-ScheduledTask -TaskName $TASK_NAME).State
    if ($state -eq "Running") {
        Ok "Agente iniciado! (estado: $state)"
    } else {
        Warn "Agente pode não ter iniciado ainda (estado: $state). Verifique os logs."
    }
} else {
    Warn "Agente NÃO iniciado — configure a Agent Key no config.toml primeiro."
    Write-Host "  Depois execute: Start-ScheduledTask -TaskName '$TASK_NAME'" -ForegroundColor Cyan
}

# ── Resumo ───────────────────────────────────────────────────
Write-Host ""
Write-Host "  ══════════════════════════════════════════" -ForegroundColor Green
Write-Host "    Instalação concluída!" -ForegroundColor White
Write-Host "  ══════════════════════════════════════════" -ForegroundColor Green
Write-Host ""
Write-Host "  Diretório:   $InstallDir" -ForegroundColor White
Write-Host "  Config:      $InstallDir\config.toml" -ForegroundColor White
Write-Host "  Logs:        Get-WinEvent -LogName Application | Where-Object Source -eq 'hashfarm'" -ForegroundColor White
Write-Host "  Parar:       Stop-ScheduledTask -TaskName '$TASK_NAME'" -ForegroundColor White
Write-Host "  Iniciar:     Start-ScheduledTask -TaskName '$TASK_NAME'" -ForegroundColor White
Write-Host "  Dashboard:   $DASHBOARD_URL" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Próximos passos:" -ForegroundColor Yellow
Write-Host "  1. Edite $InstallDir\config.toml e adicione seus mineradores"
Write-Host "  2. Acesse $DASHBOARD_URL e faça login"
Write-Host "  3. Seus ASICs aparecerão automaticamente no dashboard"
Write-Host ""
