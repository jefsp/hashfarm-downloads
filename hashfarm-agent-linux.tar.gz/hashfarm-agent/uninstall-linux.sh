#!/usr/bin/env bash
# go2mine hashfarm-agent — Desinstalador Linux
set -euo pipefail

INSTALL_DIR="/opt/hashfarm-agent"
SERVICE_NAME="hashfarm-agent"
SERVICE_USER="hashfarm"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RESET='\033[0m'
ok()   { echo -e "${GREEN}✔${RESET}  $*"; }
warn() { echo -e "${YELLOW}⚠${RESET}  $*"; }

[[ $EUID -ne 0 ]] && echo -e "${RED}✖  Execute como root: sudo bash $0${RESET}" && exit 1

echo ""
echo -e "${RED}  go2mine hashfarm-agent — Desinstalação${RESET}"
echo ""
read -rp "  Tem certeza que deseja remover o hashfarm-agent? [s/N] " resp
[[ "$resp" =~ ^[sS]$ ]] || { echo "  Cancelado."; exit 0; }

echo ""
# Para e desabilita o serviço
if systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
    systemctl stop "$SERVICE_NAME"
    ok "Serviço parado"
fi
if systemctl is-enabled --quiet "$SERVICE_NAME" 2>/dev/null; then
    systemctl disable "$SERVICE_NAME"
    ok "Serviço desabilitado"
fi

# Remove o arquivo de serviço
if [[ -f /etc/systemd/system/${SERVICE_NAME}.service ]]; then
    rm -f /etc/systemd/system/${SERVICE_NAME}.service
    systemctl daemon-reload
    ok "Arquivo de serviço removido"
fi

# Pergunta se deve manter o config
read -rp "  Manter o arquivo config.toml (recomendado para reinstalação)? [S/n] " keep
if [[ "$keep" =~ ^[nN]$ ]]; then
    rm -rf "$INSTALL_DIR"
    ok "Diretório $INSTALL_DIR removido completamente"
else
    find "$INSTALL_DIR" -maxdepth 1 -mindepth 1 \
        ! -name "config.toml" ! -name "hashfarm.db" \
        -exec rm -rf {} +
    ok "Arquivos removidos (config.toml e hashfarm.db preservados em $INSTALL_DIR)"
fi

# Remove usuário de serviço
if id "$SERVICE_USER" &>/dev/null; then
    userdel "$SERVICE_USER" 2>/dev/null || true
    ok "Usuário '$SERVICE_USER' removido"
fi

echo ""
echo -e "${GREEN}  Desinstalação concluída.${RESET}"
echo ""
