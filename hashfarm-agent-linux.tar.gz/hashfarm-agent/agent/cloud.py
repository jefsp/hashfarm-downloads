"""
hashfarm-agent · cloud.py · v1.3
Conector WebSocket com o servidor cloud.

Modelo on-demand:
- O agente mantém uma conexão WebSocket de saída permanente (idle).
- O servidor sinaliza quando um usuário abre o dashboard → agente inicia coleta.
- O servidor sinaliza quando o usuário fecha → agente para coleta.
- Dados das ASICs trafegam APENAS durante sessões ativas.
- Nenhuma telemetria é gravada no banco — o cloud só roteia.

Protocolo de mensagens (JSON):
  Cloud → Agente:
    {"type": "session_start", "session_id": "...", "farm_id": "..."}
    {"type": "session_end",   "session_id": "..."}
    {"type": "command",       "cmd_id": "...", "ip": "...", "command": "restart|stop|start"}
    {"type": "ping"}

  Agente → Cloud:
    {"type": "hello",   "agent_key": "...", "version": "1.0.0", "miners": [...]}
    {"type": "data",    "session_id": "...", "snapshots": [...]}
    {"type": "cmd_result", "cmd_id": "...", "result": "ok|error: msg"}
    {"type": "pong"}
"""

import asyncio
import json
import logging
import re
import time
from typing import Optional

import websockets
from websockets.exceptions import ConnectionClosed

from .config import AgentConfig, MinerEntry, save_miners_cache
from .store import LocalStore
from .vnish import MinerConfig, MinerPoller, VnishClient
from .whatsminer import WhatsminerClient, WhatsminerConfig, WhatsminerPoller
from .bitmain import BitmainStockPoller, cgminer_send
from .pool_manager import PoolManager
from .devfee_tracker import DevFeeTracker
from .turbo import TurboEngine, _parse_wattage

log = logging.getLogger("hashfarm.cloud")

VERSION = "1.6.71"


class CloudConnector:
    """
    Mantém a conexão WebSocket com o servidor cloud.
    Gerencia sessões ativas e despacha coleta on-demand.

    Uma única task de coleta é compartilhada por todas as sessões ativas.
    Ela começa com a primeira sessão e para quando não há mais nenhuma.
    Os dados são enviados para cada session_id individualmente (fan-out).
    """

    def __init__(self, cfg: AgentConfig, store: LocalStore):
        self.cfg = cfg
        self.store = store
        self._ws: Optional[websockets.WebSocketClientProtocol] = None
        self._running = False
        # Conjunto de session_ids ativos (não mais um dict de tasks)
        self._active_sessions: set[str] = set()
        # Task única de coleta (compartilhada entre todas as sessões)
        self._collection_task: Optional[asyncio.Task] = None
        self._reconnect_delay = cfg.cloud.reconnect_delay
        self._session_client = None   # aiohttp session compartilhada
        self._poller: Optional[MinerPoller] = None
        self._wm_client: Optional[WhatsminerClient] = None
        self._wm_poller: Optional[WhatsminerPoller] = None
        self._bm_poller: Optional[BitmainStockPoller] = None
        self._pending_firmware_reports: dict[str, str] = {}
        self._firmware_cache: dict[str, str] = {}
        self._update_triggered = False
        self._last_pong = time.time()
        self._pool_manager: Optional[PoolManager] = None
        self._devfee_tracker: Optional[DevFeeTracker] = None
        self._last_devfee_report: float = 0
        self._turbo_engine: Optional[TurboEngine] = None
        self._last_turbo_report: float = 0
        self._known_presets: dict[str, str] = {}
        self._ws_connected: bool = False
        self._last_billing_confirm_ts: float = 0

    # ─── Ciclo de vida ─────────────────────────────────────────────────────

    async def run_forever(self):
        """Loop principal — reconecta com backoff exponencial."""
        self._running = True
        import aiohttp

        connector = aiohttp.TCPConnector(force_close=True, limit=50, limit_per_host=3, ssl=False)
        async with aiohttp.ClientSession(connector=connector) as session:
            self._session_client = session
            client = VnishClient(session)
            self._poller = MinerPoller(client)
            self._wm_client = WhatsminerClient()
            self._wm_poller = WhatsminerPoller(self._wm_client)
            self._bm_poller = BitmainStockPoller()
            self._pool_manager = PoolManager(vnish_client=client, wm_client=self._wm_client)
            self._devfee_tracker = DevFeeTracker(self._pool_manager, store=self.store)
            self._turbo_engine = TurboEngine(store=self.store)

            while self._running:
                try:
                    await self._connect_and_serve()
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    log.warning(f"Conexão perdida: {e}")

                if not self._running:
                    break

                log.info(f"Reconectando em {self._reconnect_delay}s…")
                await asyncio.sleep(self._reconnect_delay)

                # Backoff exponencial até o máximo configurado
                self._reconnect_delay = min(
                    self._reconnect_delay * 2,
                    self.cfg.cloud.reconnect_max,
                )

        log.info("CloudConnector encerrado")

    def stop(self):
        self._running = False
        self._active_sessions.clear()
        if self._collection_task and not self._collection_task.done():
            self._collection_task.cancel()
            self._collection_task = None

    # ─── Conexão ───────────────────────────────────────────────────────────

    async def _connect_and_serve(self):
        # Passa agent_key como query param para compatibilidade com versões
        # antigas do websockets que não suportam extra_headers
        key = self.cfg.cloud.agent_key
        base = self.cfg.cloud.url.rstrip("?")
        url = f"{base}?agent_key={key}"
        log.info(f"Conectando a {self.cfg.cloud.url}…")

        async with websockets.connect(
            url,
            ping_interval=None,   # Render proxy não repassa WS ping/pong frames
            close_timeout=10,
        ) as ws:
            self._ws = ws
            self._ws_connected = True
            self._reconnect_delay = self.cfg.cloud.reconnect_delay
            self._update_triggered = False
            self._last_pong = time.time()
            self._active_sessions.clear()
            if self._collection_task and not self._collection_task.done():
                self._collection_task.cancel()
                self._collection_task = None
            log.info("Conectado ao servidor cloud")

            # Apresenta o agente
            await self._send(ws, {
                "type": "hello",
                "agent_key": self.cfg.cloud.agent_key,
                "version": VERSION,
                "miners": [m.ip for m in self.cfg.miners],
            })

            keepalive_task = asyncio.create_task(self._keepalive_loop(ws))
            http_keepalive_task = asyncio.create_task(self._http_keepalive())

            try:
                async for raw in ws:
                    if not self._running:
                        break
                    try:
                        msg = json.loads(raw)
                        await self._handle(ws, msg)
                    except json.JSONDecodeError:
                        log.warning(f"Mensagem inválida: {raw[:100]}")
                    except Exception as e:
                        log.error(f"Erro ao processar mensagem: {e}")
            finally:
                self._ws_connected = False
                log.warning("[cloud] WS desconectado — restaurando pools (politica conservadora)")
                if self._devfee_tracker and self._devfee_tracker.enabled:
                    try:
                        await self._devfee_tracker.restore_all(
                            self.cfg.miners, self._firmware_cache, self._miner_kw
                        )
                        log.info("[cloud] pools restauradas apos desconexao WS")
                    except Exception as e:
                        log.error(f"[cloud] erro ao restaurar pools: {e}")
                keepalive_task.cancel()
                http_keepalive_task.cancel()
                for t in (keepalive_task, http_keepalive_task):
                    try:
                        await t
                    except asyncio.CancelledError:
                        pass

    # ─── Handlers de mensagens ─────────────────────────────────────────────

    async def _handle(self, ws, msg: dict):
        t = msg.get("type")

        if t == "session_start":
            await self._on_session_start(ws, msg)

        elif t == "session_end":
            await self._on_session_end(msg)

        elif t == "command":
            await self._on_command(ws, msg)

        elif t == "get_presets":
            await self._on_get_presets(ws, msg)

        elif t == "apply_preset":
            await self._on_apply_preset(ws, msg)

        elif t == "miners_updated":
            await self._on_miners_updated(msg)

        elif t == "ping":
            self._last_pong = time.time()
            await self._send(ws, {"type": "pong"})

        elif t == "pong":
            self._last_pong = time.time()

        elif t == "get_log":
            await self._on_get_log(ws, msg)

        elif t == "scan_network":
            await self._on_scan_network(ws, msg)

        elif t == "update_available":
            await self._on_update_available(msg)

        elif t == "billing_config":
            await self._on_billing_config(msg)

        elif t == "billing_heartbeat":
            if msg.get("active"):
                self._last_billing_confirm_ts = time.time()
            else:
                if self._devfee_tracker:
                    log.warning("[billing] heartbeat: server diz billing INATIVO — restaurando pools")
                    self._last_billing_confirm_ts = 0
                    await self._devfee_tracker.restore_all(
                        self.cfg.miners, self._firmware_cache, self._miner_kw
                    )
                    await self._devfee_tracker.emergency_decontaminate(
                        self.cfg.miners, self._firmware_cache, self._miner_kw
                    )
                    if self._devfee_tracker._billing_config:
                        self._devfee_tracker._billing_config["enabled"] = False
                    else:
                        self._devfee_tracker.set_config({"enabled": False})

        elif t == "turbo_config":
            await self._on_turbo_config(msg)

        elif t == "purge_pool_state":
            log.warning("[admin] purge_pool_state recebido — limpando TODOS os pool_states salvos")
            if self.store:
                self.store.clear_all_pool_states()
            if self._devfee_tracker:
                self._devfee_tracker._states.clear()
            await self._send(ws, {"type": "purge_pool_state_result", "result": "ok"})
            log.info("[admin] pool_states purgados — proximo ciclo vai reler pools dos miners")

        else:
            log.debug(f"Mensagem desconhecida: {t}")

    async def _on_session_start(self, ws, msg: dict):
        session_id = msg["session_id"]
        if session_id in self._active_sessions:
            log.debug(f"Sessão {session_id} já registrada")
            return

        self._active_sessions.add(session_id)
        log.info(
            f"Sessão iniciada: {session_id} "
            f"(total ativas: {len(self._active_sessions)})"
        )

        # Inicia a task de coleta apenas se ainda não estiver rodando
        if self._collection_task is None or self._collection_task.done():
            self._collection_task = asyncio.create_task(
                self._collection_loop(ws),
                name="collection",
            )

    async def _on_session_end(self, msg: dict):
        session_id = msg["session_id"]
        self._active_sessions.discard(session_id)
        log.info(
            f"Sessão encerrada: {session_id} "
            f"(restantes: {len(self._active_sessions)})"
        )

        # Para a task de coleta quando não há mais sessões ativas
        if not self._active_sessions:
            if self._collection_task and not self._collection_task.done():
                self._collection_task.cancel()
                self._collection_task = None
            log.info("Nenhuma sessão ativa — coleta pausada")

    async def _on_command(self, ws, msg: dict):
        """Executa um comando remoto em uma ASIC (start/stop/restart/blink/blink_off)."""
        cmd_id = msg.get("cmd_id", "?")
        ip = msg.get("ip")
        command = msg.get("command")

        log.info(f"Comando recebido: {command} → {ip} (cmd_id={cmd_id})")

        self.store.save_command(cmd_id, ip, command, msg.get("params"))

        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            await self._send(ws, {
                "type": "cmd_result",
                "cmd_id": cmd_id,
                "result": f"error: IP {ip} não encontrado",
            })
            return

        try:
            if command in ("blink", "blink_off"):
                await self._exec_blink(miner, command)
            else:
                mc = MinerConfig(
                    ip=miner.ip,
                    port=miner.port,
                    user=miner.user,
                    password=miner.password,
                    api_key=miner.api_key,
                )
                endpoint_map = {
                    "start": "/mining/start",
                    "stop": "/mining/stop",
                    "restart": "/mining/restart",
                    "reboot": "/reboot",
                }
                endpoint = endpoint_map.get(command)
                if not endpoint:
                    raise ValueError(f"Comando desconhecido: {command}")
                await self._poller.client.post(mc, endpoint)

            self.store.complete_command(cmd_id, "ok")
            await self._send(ws, {"type": "cmd_result", "cmd_id": cmd_id, "result": "ok"})
            log.info(f"Comando {command} executado em {ip}")

        except Exception as e:
            err = f"error: {e}"
            self.store.complete_command(cmd_id, err)
            await self._send(ws, {"type": "cmd_result", "cmd_id": cmd_id, "result": err})
            log.warning(f"Falha no comando {command} em {ip}: {e}")

    async def _exec_blink(self, miner, command: str):
        """Envia comando de LED blink/locate conforme o firmware da ASIC."""
        fw = await self._detect_firmware(miner)
        log.info(f"[{miner.ip}] _exec_blink: fw={fw} command={command}")

        if fw == "vnish":
            mc = MinerConfig(
                ip=miner.ip, port=miner.port,
                user=miner.user, password=miner.password,
                api_key=miner.api_key,
            )
            enabled = command == "blink"
            result = await self._poller.client.post(mc, "/mining/find_miner", {"enabled": enabled})
            log.info(f"[{miner.ip}] find_miner enabled={enabled} result={result}")

        elif fw == "whatsminer":
            wm_cfg = WhatsminerConfig(ip=miner.ip, password=miner.password)
            if command == "blink":
                await self._wm_client.send(wm_cfg, "set_led", {"param": "user-define", "led": 1})
            else:
                await self._wm_client.send(wm_cfg, "set_led", {"param": "auto"})

        elif fw in ("bitmain_stock", "braiins"):
            await self._bitmain_blink(miner, command == "blink")

        else:
            raise ValueError(f"Firmware desconhecido para blink: {fw}")

    async def _bitmain_blink(self, miner, enable: bool):
        result = await cgminer_send(miner.ip, 4028, "ascidentify|0", timeout=3)
        if result:
            log.info(f"[{miner.ip}] bitmain ascidentify: {result}")
        else:
            log.warning(f"[{miner.ip}] bitmain blink: ascidentify sem resposta")

    async def _on_miners_updated(self, msg: dict):
        """
        Servidor atualizou a lista de miners cadastrados via dashboard.
        Atualiza self.cfg.miners em memória — sem tocar config.toml.
        Miners já conhecidos têm suas credenciais preservadas;
        novos IPs recebem as credenciais padrão do config (admin/admin).
        """
        server_miners = msg.get("miners", [])  # [{"ip": ..., "label": ...}]

        existing = {m.ip: m for m in self.cfg.miners}
        new_list = []
        for sm in server_miners:
            ip = sm["ip"]
            if ip in existing:
                entry = existing[ip]
                if sm.get("label"):
                    entry.label = sm["label"]
                if sm.get("username"):
                    entry.user = sm["username"]
                if sm.get("password"):
                    entry.password = sm["password"]
                new_list.append(entry)
            else:
                ref = next(iter(existing.values()), None)
                new_list.append(MinerEntry(
                    ip=ip,
                    port=ref.port if ref else 80,
                    user=sm.get("username") or "admin",
                    password=sm.get("password") or "admin",
                    api_key=ref.api_key if ref else None,
                    label=sm.get("label", ip),
                ))

        old_ips = {m.ip for m in self.cfg.miners}
        new_ips = {m["ip"] for m in server_miners}
        added = new_ips - old_ips
        removed = old_ips - new_ips

        self.cfg.miners = new_list
        save_miners_cache(new_list)

        for ip in removed:
            self._firmware_cache.pop(ip, None)
        if added:
            log.info(f"Miners adicionados via dashboard: {added}")
        if removed:
            log.info(f"Miners removidos via dashboard: {removed}")
        log.info(f"Lista de miners atualizada: {len(self.cfg.miners)} ativo(s)")

    async def _on_update_available(self, msg: dict):
        latest = msg.get("latest_version", "")
        if not latest or latest == VERSION:
            return
        if self._update_triggered:
            return
        self._update_triggered = True
        log.info(f"Atualização disponível: {VERSION} → {latest}")
        if self._ws:
            await self._send(self._ws, {
                "type": "update_started",
                "current_version": VERSION,
                "latest_version": latest,
            })
        from .updater import trigger_update
        download_base = msg.get("download_base")
        if download_base:
            base = self.cfg.cloud.url.replace("wss://", "https://").replace("ws://", "http://").split("/ws/")[0]
            download_base = base + download_base
        try:
            await trigger_update(latest, download_base=download_base)
        except Exception as e:
            log.error(f"Erro no auto-update: {e}")
        self._update_triggered = False

    def _miner_kw(self, ip: str) -> dict:
        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            return {}
        return {
            "port": miner.port,
            "user": miner.user,
            "password": miner.password,
            "api_key": miner.api_key,
        }

    async def _on_billing_config(self, msg: dict):
        if not self._devfee_tracker:
            return
        enabled = msg.get("enabled", False)
        if enabled:
            self._devfee_tracker.set_config(msg)
            self._last_billing_confirm_ts = time.time()
            await self._devfee_tracker.crash_recovery(self._firmware_cache, self._miner_kw)
            log.info("[billing] habilitado e confirmado pelo servidor")
        else:
            self._last_billing_confirm_ts = 0
            self._devfee_tracker.set_config(msg)
            await self._devfee_tracker.crash_recovery(self._firmware_cache, self._miner_kw)
            await self._devfee_tracker.restore_all(
                self.cfg.miners, self._firmware_cache, self._miner_kw
            )
            fixed = await self._devfee_tracker.emergency_decontaminate(
                self.cfg.miners, self._firmware_cache, self._miner_kw
            )
            if self._devfee_tracker._billing_config:
                self._devfee_tracker._billing_config["enabled"] = False
            else:
                self._devfee_tracker.set_config({"enabled": False})
            log.info(f"[billing] desabilitado — decontaminate corrigiu {fixed} miner(s)")

    async def _on_turbo_config(self, msg: dict):
        if not self._turbo_engine:
            return
        was_enabled = self._turbo_engine.enabled
        enabled = msg.get("enabled", False)
        self._turbo_engine.set_config(msg)
        if enabled:
            log.info(f"[turbo] enabled profile={msg.get('profile', 'normal')}")
        elif was_enabled and not enabled:
            log.info("[turbo] disabled — parando ajustes (presets mantidos)")
            self._turbo_engine.clear_states()
        else:
            log.info("[turbo] disabled")

    async def _apply_turbo(self, ip: str, preset: str, firmware: str) -> bool:
        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            return False
        try:
            if firmware == "whatsminer":
                wm_cfg = WhatsminerConfig(ip=miner.ip, password=miner.password)
                ok = await self._wm_client.set_power_mode(wm_cfg, preset)
                if ok:
                    self._known_presets[ip] = preset
                return ok
            else:
                mc = MinerConfig(
                    ip=miner.ip, port=miner.port,
                    user=miner.user, password=miner.password,
                    api_key=miner.api_key,
                )
                payload = {"miner": {"overclock": {"preset": preset}}}
                resp = await self._poller.client.post(mc, "/settings", payload)
                if isinstance(resp, dict):
                    if resp.get("reboot_required"):
                        await self._poller.client.post(mc, "/system/reboot")
                    elif resp.get("restart_required"):
                        await self._poller.client.post(mc, "/mining/restart")
                self._known_presets[ip] = preset
                return True
        except Exception as e:
            log.warning(f"[{ip}] turbo apply error: {e}")
            return False

    async def _read_current_preset(self, ip: str) -> str:
        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            return ""
        mc = MinerConfig(
            ip=miner.ip, port=miner.port,
            user=miner.user, password=miner.password,
            api_key=miner.api_key,
        )
        try:
            data = await self._poller.client.get(mc, "/settings")
            if isinstance(data, dict):
                oc = data.get("miner", {}).get("overclock", {})
                preset = oc.get("preset") or oc.get("current_preset") or ""
                if not preset or preset.lower() == "disabled":
                    oc_keys = list(oc.keys())[:10] if oc else []
                    top_keys = list(data.keys())[:10]
                    miner_keys = list(data.get("miner", {}).keys())[:10] if data.get("miner") else []
                    log.warning(f"[{ip}] /settings preset vazio | oc_keys={oc_keys} | miner_keys={miner_keys} | top_keys={top_keys}")
                    for k, v in oc.items():
                        if isinstance(v, str) and v and v.lower() != "disabled":
                            log.info(f"[{ip}] /settings oc[{k}] = {v}")
                    if not oc and data.get("miner"):
                        for k, v in data["miner"].items():
                            if isinstance(v, dict) and "preset" in v:
                                preset = v["preset"]
                                log.info(f"[{ip}] /settings miner.{k}.preset = {preset}")
                                break
                if preset and preset.lower() != "disabled":
                    log.info(f"[{ip}] preset lido de /settings: {preset}")
                    return str(preset)
        except Exception as e:
            log.debug(f"[{ip}] read_current_preset error: {e}")
        return ""

    async def _fetch_turbo_presets(self, ip: str) -> list[str]:
        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            return []
        mc = MinerConfig(
            ip=miner.ip, port=miner.port,
            user=miner.user, password=miner.password,
            api_key=miner.api_key,
        )
        try:
            data = await self._poller.client.get(mc, "/autotune/presets")
            if isinstance(data, list):
                return [
                    p["name"] for p in data
                    if p.get("name", "").lower() != "disabled"
                ]
        except Exception as e:
            log.debug(f"[{ip}] fetch turbo presets error: {e}")
        return []

    async def _on_get_presets(self, ws, msg: dict):
        """Busca presets disponíveis de cada ASIC e devolve ao cloud."""
        session_id = msg.get("session_id")
        requested_ips = msg.get("miners", [m.ip for m in self.cfg.miners])

        async def fetch_presets(miner):
            mc = MinerConfig(
                ip=miner.ip,
                port=miner.port,
                user=miner.user,
                password=miner.password,
                api_key=miner.api_key,
            )
            try:
                data = await self._poller.client.get(mc, "/autotune/presets")
                presets = [
                    {"name": p["name"], "pretty": p.get("pretty", p["name"])}
                    for p in (data if isinstance(data, list) else [])
                    # Remove "disabled" — tratado pelo dashboard como "Restaurar padrão"
                    if p.get("name", "").lower() != "disabled"
                ]
                return {"ip": miner.ip, "presets": presets}
            except Exception as e:
                log.debug(f"[{miner.ip}] get_presets erro: {e}")
                return {"ip": miner.ip, "presets": [], "error": str(e)}

        miners_to_query = [m for m in self.cfg.miners if m.ip in requested_ips]
        results = await asyncio.gather(*[fetch_presets(m) for m in miners_to_query])

        await self._send(ws, {
            "type": "presets_result",
            "session_id": session_id,
            "miners": list(results),
        })
        log.info(f"Presets enviados para sessão {session_id} ({len(results)} miners)")

    async def _on_apply_preset(self, ws, msg: dict):
        """Aplica um preset em uma ASIC. Preset '__disabled__' restaura o padrão."""
        cmd_id = msg.get("cmd_id", "?")
        ip = msg.get("ip")
        preset = msg.get("preset")

        log.info(f"apply_preset: {preset} → {ip} (cmd_id={cmd_id})")

        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            await self._send(ws, {
                "type": "preset_applied",
                "cmd_id": cmd_id,
                "ip": ip,
                "result": f"error: IP {ip} não encontrado",
            })
            return

        mc = MinerConfig(
            ip=miner.ip,
            port=miner.port,
            user=miner.user,
            password=miner.password,
            api_key=miner.api_key,
        )
        try:
            if preset == "__disabled__":
                # Lê configurações para extrair volt/freq de fábrica
                settings_data = await self._poller.client.get(mc, "/settings")
                settings_str = json.dumps(settings_data or {})
                volt_m = re.search(r'"default_voltage"\s*:\s*(\d+)', settings_str)
                freq_m = re.search(r'"default_freq"\s*:\s*(\d+)', settings_str)
                volt = int(volt_m.group(1)) if volt_m else 0
                freq = int(freq_m.group(1)) if freq_m else 0
                if volt == 0 or freq == 0:
                    log.warning(f"[{ip}] default_voltage/freq não encontrados — usando 0")
                payload = {"miner": {"overclock": {
                    "preset": "disabled",
                    "globals": {"volt": volt, "freq": freq},
                }}}
            else:
                payload = {"miner": {"overclock": {"preset": preset}}}

            resp = await self._poller.client.post(mc, "/settings", payload)
            result = "ok"
            log.info(f"Preset {preset} aplicado em {ip}")

            if preset != "__disabled__" and preset != "disabled":
                self._known_presets[ip] = preset
                log.info(f"[{ip}] known_preset atualizado: {preset}")
            else:
                self._known_presets.pop(ip, None)

            if isinstance(resp, dict):
                if resp.get("reboot_required"):
                    log.info(f"[{ip}] reboot_required → reiniciando sistema")
                    await self._poller.client.post(mc, "/system/reboot")
                    result = "ok:rebooted"
                elif resp.get("restart_required"):
                    log.info(f"[{ip}] restart_required → reiniciando mineração")
                    await self._poller.client.post(mc, "/mining/restart")
                    result = "ok:restarted"

        except Exception as e:
            result = f"error: {e}"
            log.warning(f"Falha ao aplicar preset {preset} em {ip}: {e}")

        await self._send(ws, {
            "type": "preset_applied",
            "cmd_id": cmd_id,
            "ip": ip,
            "result": result,
        })

    async def _on_get_log(self, ws, msg: dict):
        import os
        lines = msg.get("lines", 500)
        log_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        log_path = os.path.join(log_dir, "agent.log")
        try:
            with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                all_lines = f.readlines()
            tail = all_lines[-lines:]
            await self._send(ws, {
                "type": "log_result",
                "session_id": msg.get("session_id"),
                "log": "".join(tail),
            })
        except Exception as e:
            await self._send(ws, {
                "type": "log_result",
                "session_id": msg.get("session_id"),
                "log": f"Erro ao ler log: {e}",
            })

    async def _on_scan_network(self, ws, msg: dict):
        session_id = msg.get("session_id")
        try:
            from .scanner import scan_subnet, get_local_ip
            local_ip = get_local_ip()
            prefix = ".".join(local_ip.split(".")[:3])
            known_ips = {m.ip for m in self.cfg.miners}

            log.info(f"Scan rede: {prefix}.0/24 (excluindo {len(known_ips)} miners conhecidos)")
            results = await scan_subnet(prefix)
            discovered = [r for r in results if r["ip"] not in known_ips]

            await self._send(ws, {
                "type": "scan_result",
                "session_id": session_id,
                "miners": discovered,
            })
            log.info(f"Scan concluído: {len(discovered)} novas ASICs encontradas")
        except Exception as e:
            log.error(f"Erro no scan_network: {e}")
            await self._send(ws, {
                "type": "scan_result",
                "session_id": session_id,
                "miners": [],
                "error": str(e),
            })

    # ─── Keepalive de aplicação ────────────────────────────────────────────

    async def _keepalive_loop(self, ws):
        """Envia ping de aplicação a cada 15s. Fecha se sem pong por 60s."""
        try:
            while True:
                await asyncio.sleep(15)
                if time.time() - self._last_pong > 60:
                    log.warning("Sem pong há 60s — forçando reconexão")
                    await ws.close()
                    return
                await self._send(ws, {"type": "ping"})
        except asyncio.CancelledError:
            pass

    async def _http_keepalive(self):
        """GET /health a cada 4min para impedir spin-down do Render free tier."""
        import aiohttp as _aio
        base = self.cfg.cloud.url.split("/ws/")[0]
        health_url = base.replace("wss://", "https://").replace("ws://", "http://") + "/health"
        try:
            while True:
                await asyncio.sleep(240)
                try:
                    if self._session_client:
                        async with self._session_client.get(health_url, timeout=_aio.ClientTimeout(total=10)) as r:
                            log.debug(f"HTTP keepalive → {r.status}")
                except Exception:
                    pass
        except asyncio.CancelledError:
            pass

    # ─── Loop único de coleta com fan-out ──────────────────────────────────

    async def _collection_loop(self, ws):
        """
        Task única de coleta: faz poll das ASICs e envia os dados
        para TODAS as sessões ativas (fan-out).
        Para automaticamente quando _active_sessions fica vazio.
        """
        interval = self.cfg.collector.interval
        sem = asyncio.Semaphore(self.cfg.collector.parallel_limit)

        log.info(f"Coleta on-demand iniciada (intervalo {interval}s)")

        try:
            while self._active_sessions:
                t0 = time.time()
                snapshots = await self._poll_all(sem)

                if self._pending_firmware_reports:
                    for ip, fw in list(self._pending_firmware_reports.items()):
                        await self._send(ws, {"type": "firmware_detected", "ip": ip, "firmware": fw})
                    self._pending_firmware_reports.clear()

                billing_allowed = (
                    self._ws_connected
                    and self._devfee_tracker
                    and self._devfee_tracker.enabled
                    and (time.time() - self._last_billing_confirm_ts) < 300
                )

                if not billing_allowed and self._devfee_tracker and self._devfee_tracker.enabled:
                    has_devfee_miners = any(
                        s.current_mode != "user" for s in self._devfee_tracker._states.values()
                    )
                    if has_devfee_miners:
                        reason = "ws_disconnected" if not self._ws_connected else "billing_stale"
                        log.warning(f"[billing] {reason} — restaurando pools (politica conservadora)")
                        await self._devfee_tracker.restore_all(
                            self.cfg.miners, self._firmware_cache, self._miner_kw
                        )

                if snapshots and billing_allowed:
                    for snap in snapshots:
                        if snap.get("status") == "mining":
                            ip = snap.get("ip", "")
                            fw = snap.get("firmware") or self._firmware_cache.get(ip, "bitmain_stock")
                            kw = self._miner_kw(ip)
                            try:
                                mode = await self._devfee_tracker.tick(ip, fw, kw)
                                snap["devfee_mode"] = mode
                            except Exception as e:
                                log.warning(f"[{ip}] devfee tick erro: {e}")
                                snap["devfee_mode"] = "user"
                                await self._send(ws, {
                                    "type": "devfee_alert",
                                    "ip": ip,
                                    "alert_type": "tick_error",
                                    "detail": str(e),
                                })

                if snapshots:
                    for snap in snapshots:
                        ip = snap.get("ip", "")
                        if ip in self._known_presets and not snap.get("current_preset"):
                            snap["current_preset"] = self._known_presets[ip]

                if snapshots and self._turbo_engine and self._turbo_engine.enabled:
                    for snap in snapshots:
                        if snap.get("status") != "mining":
                            continue
                        ip = snap.get("ip", "")
                        fw = snap.get("firmware") or self._firmware_cache.get(ip, "bitmain_stock")
                        try:
                            if fw in ("vnish", "braiins"):
                                if ip not in self._turbo_engine._available_presets or \
                                   time.time() - self._turbo_engine._preset_fetch_ts.get(ip, 0) > 3600:
                                    presets = await self._fetch_turbo_presets(ip)
                                    if presets:
                                        self._turbo_engine.set_presets(ip, presets)
                                if ip not in self._known_presets:
                                    inferred = None
                                    api_preset = await self._read_current_preset(ip)
                                    if api_preset:
                                        avail = self._turbo_engine._available_presets.get(ip, [])
                                        if api_preset in avail:
                                            inferred = api_preset
                                            log.info(f"[{ip}] preset from API: {api_preset}")
                                        else:
                                            closest = self._turbo_engine.infer_preset_from_power(ip, _parse_wattage(api_preset))
                                            if closest:
                                                inferred = closest
                                                log.info(f"[{ip}] preset from API {api_preset} not in list, closest: {closest}")
                                            else:
                                                log.warning(f"[{ip}] preset from API {api_preset} not in available presets {avail}")
                                    if not inferred:
                                        pw = snap.get("power_w") or 0
                                        if pw > 0:
                                            inferred = self._turbo_engine.infer_preset_from_power(ip, pw)
                                        if not inferred:
                                            inferred = self._turbo_engine.infer_preset_from_hashrate(
                                                ip, snap.get("hr_realtime_ths", 0), snap.get("hr_stock_ths", 0)
                                            )
                                    if inferred:
                                        snap["current_preset"] = inferred
                                        self._known_presets[ip] = inferred
                                        log.info(f"[{ip}] initial preset → {inferred}")
                                    else:
                                        log.debug(f"[{ip}] no preset inferred (presets={len(self._turbo_engine._available_presets.get(ip, []))})")
                                decision = await self._turbo_engine.tick(
                                    ip, snap, fw,
                                    lambda _ip, _preset, _fw=fw: self._apply_turbo(_ip, _preset, _fw),
                                )
                                snap["turbo_decision"] = decision.to_dict()
                            elif fw == "whatsminer":
                                decision = await self._turbo_engine.tick(
                                    ip, snap, fw,
                                    lambda _ip, _preset, _fw=fw: self._apply_turbo(_ip, _preset, _fw),
                                )
                                snap["turbo_decision"] = decision.to_dict()
                            elif fw == "bitmain_stock":
                                alert = self._turbo_engine.monitor_only(ip, snap)
                                if alert:
                                    snap["turbo_alert"] = alert
                        except Exception as e:
                            log.warning(f"[{ip}] turbo tick error: {e}")

                if snapshots:
                    ts = int(time.time())
                    for session_id in list(self._active_sessions):
                        await self._send(ws, {
                            "type": "data",
                            "session_id": session_id,
                            "ts": ts,
                            "snapshots": snapshots,
                        })

                    if self._devfee_tracker and self._devfee_tracker.enabled:
                        now = time.time()
                        if now - self._last_devfee_report >= 300:
                            report = self._devfee_tracker.get_report()
                            if report:
                                await self._send(ws, {
                                    "type": "devfee_report",
                                    "miners": report,
                                })
                            self._last_devfee_report = now

                    if self._turbo_engine and self._turbo_engine.enabled:
                        now = time.time()
                        if now - self._last_turbo_report >= 60:
                            turbo_report = self._turbo_engine.get_report()
                            if turbo_report:
                                await self._send(ws, {
                                    "type": "turbo_report",
                                    "miners": turbo_report,
                                })
                            self._last_turbo_report = now

                elapsed = time.time() - t0
                wait = max(0, interval - elapsed)
                if wait > 0:
                    await asyncio.sleep(wait)

        except asyncio.CancelledError:
            log.info("Coleta on-demand encerrada")
        except ConnectionClosed:
            log.warning("WebSocket fechou durante coleta")

    @staticmethod
    def _classify_cgminer(cgm_ver: dict) -> str:
        ver_str = json.dumps(cgm_ver).lower()
        if any(k in ver_str for k in ("braiins", "bosminer", "bos+", "bos_", "braiinos")):
            return "braiins"
        return "bitmain_stock"

    async def _vnish_probe(self, ip: str) -> bool:
        try:
            import aiohttp
            timeout = aiohttp.ClientTimeout(total=3)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.get(f"http://{ip}/api/v1/info") as r:
                    if r.status != 200:
                        return False
                    ct = r.headers.get("content-type", "")
                    if "html" in ct:
                        return False
                    try:
                        data = await r.json(content_type=None)
                        return isinstance(data, dict)
                    except Exception:
                        return False
        except Exception:
            pass
        return False

    async def _detect_firmware(self, miner) -> str:
        if miner.ip in self._firmware_cache:
            return self._firmware_cache[miner.ip]

        cgm_task = asyncio.ensure_future(cgminer_send(miner.ip, 4028, "version", timeout=3))
        vnish_task = asyncio.ensure_future(self._vnish_probe(miner.ip))
        wm_cfg = WhatsminerConfig(ip=miner.ip, password=miner.password)
        wm_task = asyncio.ensure_future(self._wm_client.send(wm_cfg, "summary"))

        cgm, is_vnish, wm = await asyncio.gather(cgm_task, vnish_task, wm_task)

        if is_vnish:
            fw = "vnish"
        elif wm and isinstance(wm, dict) and wm.get("SUMMARY"):
            fw = "whatsminer"
        elif cgm is not None:
            s_list = cgm.get("STATUS", [])
            s0 = s_list[0] if s_list and isinstance(s_list[0], dict) else {}
            desc = s0.get("Description", "").lower()
            if "microbt" in desc or "whatsminer" in desc:
                fw = "whatsminer"
            else:
                fw = self._classify_cgminer(cgm)
        else:
            fw = "bitmain_stock"

        self._firmware_cache[miner.ip] = fw
        self._pending_firmware_reports[miner.ip] = fw
        log.info(f"[{miner.ip}] firmware detectado: {fw}")
        return fw

    async def _poll_all(self, sem: asyncio.Semaphore) -> list[dict]:
        """Coleta todos os mineradores em paralelo com semáforo."""
        async def poll_one(miner):
            async with sem:
                fw = None
                try:
                    fw = await self._detect_firmware(miner)

                    if fw == "whatsminer":
                        wm_cfg = WhatsminerConfig(ip=miner.ip, password=miner.password)
                        raw  = await self._wm_poller.poll(wm_cfg)
                        kpis = self._wm_poller.extract_kpis(raw)
                    elif fw in ("bitmain_stock", "braiins"):
                        raw  = await self._bm_poller.poll(miner.ip)
                        kpis = self._bm_poller.extract_kpis(raw)
                    else:
                        mc = MinerConfig(
                            ip=miner.ip,
                            port=miner.port,
                            user=miner.user,
                            password=miner.password,
                            api_key=miner.api_key,
                        )
                        raw  = await self._poller.poll(mc)
                        kpis = self._poller.extract_kpis(raw)

                    kpis["label"]          = miner.label or miner.ip
                    kpis["firmware"]       = fw
                    kpis["preset_day_w"]   = miner.preset_day_w
                    kpis["preset_night_w"] = miner.preset_night_w
                    kpis["alarms"] = self._poller._check_alarms(
                        kpis, temp_warn=self.cfg.collector.temp_warn
                    )
                    return kpis
                except Exception as e:
                    log.debug(f"[{miner.ip}] poll erro: {e}")
                    return {
                        "ip": miner.ip,
                        "ts": int(time.time()),
                        "status": "offline",
                        "label": miner.label or miner.ip,
                        "firmware": self._firmware_cache.get(miner.ip) or fw,
                        "alarms": ["offline"],
                    }

        results = await asyncio.gather(*[poll_one(m) for m in self.cfg.miners])
        return list(results)

    # ─── Helpers ───────────────────────────────────────────────────────────

    async def _send(self, ws, payload: dict):
        try:
            await ws.send(json.dumps(payload))
        except ConnectionClosed:
            log.debug("Tentou enviar em conexão fechada")
        except Exception as e:
            log.debug(f"Erro ao enviar: {e}")
