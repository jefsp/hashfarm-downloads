"""
hashfarm-agent · cloud.py · v1.3
Conector WebSocket com o servidor cloud.

Modelo on-demand:
- O agente mantém uma conexão WebSocket de saída permanente (idle).
- O servidor sinaliza quando um usuário abre o dashboard → agente inicia coleta.
- O servidor sinaliza quando o usuário fecha → agente para coleta.
- Dados das ASICs trafegam APENAS durante sessões ativas.
- Nenhuma telemetria é gravada no banco — o cloud só roteia.

Protocolo de mensagens (JSON):
  Cloud → Agente:
    {"type": "session_start", "session_id": "...", "farm_id": "..."}
    {"type": "session_end",   "session_id": "..."}
    {"type": "command",       "cmd_id": "...", "ip": "...", "command": "restart|stop|start"}
    {"type": "ping"}

  Agente → Cloud:
    {"type": "hello",   "agent_key": "...", "version": "1.0.0", "miners": [...]}
    {"type": "data",    "session_id": "...", "snapshots": [...]}
    {"type": "cmd_result", "cmd_id": "...", "result": "ok|error: msg"}
    {"type": "pong"}
"""

import asyncio
import json
import logging
import re
import time
from typing import Optional

import websockets
from websockets.exceptions import ConnectionClosed

from .config import AgentConfig, MinerEntry, save_miners_cache
from .store import LocalStore
from .vnish import MinerConfig, MinerPoller, VnishClient
from .whatsminer import WhatsminerClient, WhatsminerConfig, WhatsminerPoller
from .bitmain import BitmainStockPoller, cgminer_send
from .pool_manager import PoolManager
from .devfee_tracker import DevFeeTracker
from .turbo import TurboEngine, _parse_wattage
from . import vnish_turbo
from . import braiins_turbo

log = logging.getLogger("hashfarm.cloud")

VERSION = "1.6.150"


class CloudConnector:
    """
    Mantém a conexão WebSocket com o servidor cloud.
    Gerencia sessões ativas e despacha coleta on-demand.

    Uma única task de coleta é compartilhada por todas as sessões ativas.
    Ela começa com a primeira sessão e para quando não há mais nenhuma.
    Os dados são enviados para cada session_id individualmente (fan-out).
    """

    def __init__(self, cfg: AgentConfig, store: LocalStore):
        self.cfg = cfg
        self.store = store
        self._ws: Optional[websockets.WebSocketClientProtocol] = None
        self._running = False
        # Conjunto de session_ids ativos (não mais um dict de tasks)
        self._active_sessions: set[str] = set()
        # Task única de coleta (compartilhada entre todas as sessões)
        self._collection_task: Optional[asyncio.Task] = None
        self._reconnect_delay = cfg.cloud.reconnect_delay
        self._session_client = None   # aiohttp session compartilhada
        self._poller: Optional[MinerPoller] = None
        self._wm_client: Optional[WhatsminerClient] = None
        self._wm_poller: Optional[WhatsminerPoller] = None
        self._bm_poller: Optional[BitmainStockPoller] = None
        self._pending_firmware_reports: dict[str, str] = {}
        self._firmware_cache: dict[str, str] = {}
        self._update_triggered = False
        self._last_pong = time.time()
        self._pool_manager: Optional[PoolManager] = None
        self._devfee_tracker: Optional[DevFeeTracker] = None
        self._last_devfee_report: float = 0
        self._turbo_engine: Optional[TurboEngine] = None
        self._last_turbo_report: float = 0
        self._known_presets: dict[str, str] = {}
        self._braiins_snapshot: dict[str, int] = {}
        self._braiins_power_cache: dict[str, tuple] = {}
        self._braiins_locate_cache: dict[str, tuple] = {}
        self._scan_active: bool = False
        self._poll_fail_count: dict[str, int] = {}
        self._ws_connected: bool = False
        self._last_billing_confirm_ts: float = 0
        self._blink_state: dict[str, bool] = {}
        self._cgminer_model_cache: dict[str, str] = {}
        self._last_env_report: float = 0
        self._last_turbo_profile: Optional[str] = None
        self._last_turbo_excluded: list = []
        self._last_turbo_enabled: bool = False
        self._load_turbo_state()

    _TURBO_STATE_FILE = "turbo_state.json"

    def _load_turbo_state(self):
        try:
            from pathlib import Path
            p = Path(self._TURBO_STATE_FILE)
            if p.exists():
                data = json.loads(p.read_text(encoding="utf-8"))
                self._last_turbo_profile = data.get("profile")
                self._last_turbo_excluded = data.get("excluded_ips") or []
                self._last_turbo_enabled = bool(data.get("enabled"))
                log.info(f"[turbo] estado anterior carregado de disco: enabled={self._last_turbo_enabled} profile={self._last_turbo_profile} excluded={len(self._last_turbo_excluded)}")
        except Exception as e:
            log.debug(f"[turbo] nao conseguiu carregar estado anterior: {e}")

    def _save_turbo_state(self, enabled: bool, profile: str, excluded_ips: list):
        try:
            from pathlib import Path
            data = {"enabled": bool(enabled), "profile": profile or "normal", "excluded_ips": list(excluded_ips or [])}
            Path(self._TURBO_STATE_FILE).write_text(json.dumps(data), encoding="utf-8")
        except Exception as e:
            log.debug(f"[turbo] nao conseguiu salvar estado: {e}")

    # ─── Ciclo de vida ─────────────────────────────────────────────────────

    async def run_forever(self):
        """Loop principal — reconecta com backoff exponencial."""
        self._running = True
        import aiohttp

        connector = aiohttp.TCPConnector(force_close=True, limit=50, limit_per_host=3, ssl=False)
        async with aiohttp.ClientSession(connector=connector) as session:
            self._session_client = session
            client = VnishClient(session)
            self._poller = MinerPoller(client)
            self._wm_client = WhatsminerClient()
            self._wm_poller = WhatsminerPoller(self._wm_client)
            self._bm_poller = BitmainStockPoller()
            self._pool_manager = PoolManager(vnish_client=client, wm_client=self._wm_client)
            self._devfee_tracker = DevFeeTracker(self._pool_manager, store=self.store)
            self._turbo_engine = TurboEngine(store=self.store)

            while self._running:
                try:
                    await self._connect_and_serve()
                except asyncio.CancelledError:
                    break
                except Exception as e:
                    log.warning(f"Conexão perdida: {e}")

                if not self._running:
                    break

                log.info(f"Reconectando em {self._reconnect_delay}s…")
                await asyncio.sleep(self._reconnect_delay)

                # Backoff exponencial até o máximo configurado
                self._reconnect_delay = min(
                    self._reconnect_delay * 2,
                    self.cfg.cloud.reconnect_max,
                )

        log.info("CloudConnector encerrado")

    def stop(self):
        self._running = False
        self._active_sessions.clear()
        if self._collection_task and not self._collection_task.done():
            self._collection_task.cancel()
            self._collection_task = None

    # ─── Conexão ───────────────────────────────────────────────────────────

    async def _connect_and_serve(self):
        # Passa agent_key como query param para compatibilidade com versões
        # antigas do websockets que não suportam extra_headers
        key = self.cfg.cloud.agent_key
        base = self.cfg.cloud.url.rstrip("?")
        url = f"{base}?agent_key={key}"
        log.info(f"Conectando a {self.cfg.cloud.url}…")

        async with websockets.connect(
            url,
            ping_interval=None,   # Render proxy não repassa WS ping/pong frames
            close_timeout=10,
        ) as ws:
            self._ws = ws
            self._ws_connected = True
            self._reconnect_delay = self.cfg.cloud.reconnect_delay
            self._update_triggered = False
            self._last_pong = time.time()
            self._active_sessions.clear()
            if self._collection_task and not self._collection_task.done():
                self._collection_task.cancel()
                self._collection_task = None
            log.info("Conectado ao servidor cloud")

            # Apresenta o agente
            await self._send(ws, {
                "type": "hello",
                "agent_key": self.cfg.cloud.agent_key,
                "version": VERSION,
                "miners": [m.ip for m in self.cfg.miners],
            })

            keepalive_task = asyncio.create_task(self._keepalive_loop(ws))
            http_keepalive_task = asyncio.create_task(self._http_keepalive())
            billing_task = asyncio.create_task(self._billing_loop(ws))
            env_task = asyncio.create_task(self._env_loop(ws))

            try:
                async for raw in ws:
                    if not self._running:
                        break
                    try:
                        msg = json.loads(raw)
                        await self._handle(ws, msg)
                    except json.JSONDecodeError:
                        log.warning(f"Mensagem inválida: {raw[:100]}")
                    except Exception as e:
                        log.error(f"Erro ao processar mensagem: {e}")
            finally:
                self._ws_connected = False
                log.warning("[cloud] WS desconectado — restaurando pools (politica conservadora)")
                if self._devfee_tracker and self._devfee_tracker.enabled:
                    try:
                        await self._devfee_tracker.restore_all(
                            self.cfg.miners, self._firmware_cache, self._miner_kw
                        )
                        log.info("[cloud] pools restauradas apos desconexao WS")
                    except Exception as e:
                        log.error(f"[cloud] erro ao restaurar pools: {e}")
                keepalive_task.cancel()
                http_keepalive_task.cancel()
                billing_task.cancel()
                env_task.cancel()
                for t in (keepalive_task, http_keepalive_task, billing_task, env_task):
                    try:
                        await t
                    except asyncio.CancelledError:
                        pass

    # ─── Handlers de mensagens ─────────────────────────────────────────────

    async def _handle(self, ws, msg: dict):
        t = msg.get("type")
        self._last_pong = time.time()   # qualquer mensagem do servidor prova que a conexão está viva

        # Mensagens leves: dispatch inline (rápido, não bloqueia)
        if t == "ping":
            await self._send(ws, {"type": "pong"})
            return
        if t == "pong":
            return
        if t == "session_start":
            await self._on_session_start(ws, msg)
            return
        if t == "session_end":
            await self._on_session_end(msg)
            return
        if t == "miners_updated":
            await self._on_miners_updated(msg)
            return
        if t == "turbo_config":
            await self._on_turbo_config(msg)
            return
        if t == "billing_heartbeat":
            if msg.get("active"):
                self._last_billing_confirm_ts = time.time()
                return
            # billing inactive → restore + decontaminate são pesados, dispatch em background
            asyncio.create_task(self._handle_billing_inactive(), name="billing-inactive")
            return

        # Mensagens pesadas: dispatch em background para não bloquear iter_text
        if t in ("command", "get_presets", "apply_preset", "set_pools",
                 "get_log", "scan_network", "update_available",
                 "billing_config", "purge_pool_state"):
            asyncio.create_task(self._handle_heavy(ws, msg), name=f"handle-{t}")
            return

        log.debug(f"Mensagem desconhecida: {t}")

    async def _handle_billing_inactive(self):
        if not self._devfee_tracker:
            return
        try:
            log.warning("[billing] heartbeat: server diz billing INATIVO — restaurando pools")
            self._last_billing_confirm_ts = 0
            await self._devfee_tracker.restore_all(
                self.cfg.miners, self._firmware_cache, self._miner_kw
            )
            await self._devfee_tracker.emergency_decontaminate(
                self.cfg.miners, self._firmware_cache, self._miner_kw
            )
            if self._devfee_tracker._billing_config:
                self._devfee_tracker._billing_config["enabled"] = False
            else:
                self._devfee_tracker.set_config({"enabled": False})
        except Exception as e:
            log.error(f"[billing] erro em heartbeat inactive: {e}")

    async def _handle_heavy(self, ws, msg: dict):
        t = msg.get("type")
        try:
            if t == "command":
                await self._on_command(ws, msg)
            elif t == "get_presets":
                await self._on_get_presets(ws, msg)
            elif t == "apply_preset":
                await self._on_apply_preset(ws, msg)
            elif t == "set_pools":
                await self._on_set_pools(ws, msg)
            elif t == "get_log":
                await self._on_get_log(ws, msg)
            elif t == "scan_network":
                await self._on_scan_network(ws, msg)
            elif t == "update_available":
                await self._on_update_available(msg)
            elif t == "billing_config":
                await self._on_billing_config(msg)
            elif t == "purge_pool_state":
                log.warning("[admin] purge_pool_state recebido — limpando TODOS os pool_states salvos")
                if self.store:
                    self.store.clear_all_pool_states()
                if self._devfee_tracker:
                    self._devfee_tracker._states.clear()
                await self._send(ws, {"type": "purge_pool_state_result", "result": "ok"})
                log.info("[admin] pool_states purgados — proximo ciclo vai reler pools dos miners")
        except Exception as e:
            log.error(f"Erro em handler {t}: {e}")

    async def _on_session_start(self, ws, msg: dict):
        session_id = msg["session_id"]
        if session_id in self._active_sessions:
            log.debug(f"Sessão {session_id} já registrada")
            return

        self._active_sessions.add(session_id)
        log.info(
            f"Sessão iniciada: {session_id} "
            f"(total ativas: {len(self._active_sessions)})"
        )

        # Inicia a task de coleta apenas se ainda não estiver rodando
        if self._collection_task is None or self._collection_task.done():
            self._collection_task = asyncio.create_task(
                self._collection_loop(ws),
                name="collection",
            )

    async def _on_session_end(self, msg: dict):
        session_id = msg["session_id"]
        self._active_sessions.discard(session_id)
        log.info(
            f"Sessão encerrada: {session_id} "
            f"(restantes: {len(self._active_sessions)})"
        )

        # Para a task de coleta quando não há mais sessões ativas
        if not self._active_sessions:
            if self._collection_task and not self._collection_task.done():
                self._collection_task.cancel()
                self._collection_task = None
            log.info("Nenhuma sessão ativa — coleta pausada")

    async def _on_command(self, ws, msg: dict):
        """Executa um comando remoto em uma ASIC (start/stop/restart/blink/blink_off)."""
        cmd_id = msg.get("cmd_id", "?")
        ip = msg.get("ip")
        command = msg.get("command")

        log.info(f"Comando recebido: {command} → {ip} (cmd_id={cmd_id})")

        self.store.save_command(cmd_id, ip, command, msg.get("params"))

        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            await self._send(ws, {
                "type": "cmd_result",
                "cmd_id": cmd_id,
                "result": f"error: IP {ip} não encontrado",
            })
            return

        try:
            if command in ("blink", "blink_off"):
                await self._exec_blink(miner, command)
            else:
                mc = MinerConfig(
                    ip=miner.ip,
                    port=miner.port,
                    user=miner.user,
                    password=miner.password,
                    api_key=miner.api_key,
                )
                endpoint_map = {
                    "start": "/mining/start",
                    "stop": "/mining/stop",
                    "restart": "/mining/restart",
                    "reboot": "/reboot",
                }
                endpoint = endpoint_map.get(command)
                if not endpoint:
                    raise ValueError(f"Comando desconhecido: {command}")
                await self._poller.client.post(mc, endpoint)

            self.store.complete_command(cmd_id, "ok")
            await self._send(ws, {"type": "cmd_result", "cmd_id": cmd_id, "result": "ok"})
            log.info(f"Comando {command} executado em {ip}")

        except Exception as e:
            err = f"error: {e}"
            self.store.complete_command(cmd_id, err)
            await self._send(ws, {"type": "cmd_result", "cmd_id": cmd_id, "result": err})
            log.warning(f"Falha no comando {command} em {ip}: {e}")

    async def _exec_blink(self, miner, command: str):
        """Envia comando de LED blink/locate conforme o firmware da ASIC."""
        fw = await self._detect_firmware(miner)
        enable = command == "blink"
        log.info(f"[{miner.ip}] _exec_blink: fw={fw} enable={enable}")

        if fw == "vnish":
            await self._vnish_blink(miner, enable)
        elif fw == "whatsminer":
            await self._whatsminer_blink(miner, enable)
        elif fw == "braiins":
            await self._braiins_blink(miner, enable)
        elif fw == "bitmain_stock":
            await self._bitmain_stock_blink(miner, enable)
        else:
            raise ValueError(f"Firmware desconhecido para blink: {fw}")

    async def _vnish_blink(self, miner, enable: bool):
        """Vnish: tenta /locate-miner (v1.3.3+) com enable explícito; fallback para /find-miner toggle (v1.2.x)."""
        mc = MinerConfig(
            ip=miner.ip, port=miner.port,
            user=miner.user, password=miner.password,
            api_key=miner.api_key,
        )
        try:
            result = await self._poller.client.post(mc, "/locate-miner", {"enable": enable})
            log.info(f"[{miner.ip}] vnish POST /locate-miner enable={enable} → {result}")
            self._blink_state[miner.ip] = enable
            return
        except Exception:
            pass

        current_on = False
        try:
            status = await self._poller.client.get(mc, "/status")
            current_on = bool((status or {}).get("locate_miner") or (status or {}).get("find_miner", False))
        except Exception as e:
            log.warning(f"[{miner.ip}] vnish blink legacy: nao conseguiu ler /status: {e}")

        log.info(f"[{miner.ip}] vnish blink legacy: atual={current_on} desejado={enable}")
        if current_on == enable:
            self._blink_state[miner.ip] = enable
            return

        try:
            result = await self._poller.client.post(mc, "/find-miner")
            log.info(f"[{miner.ip}] vnish POST /find-miner → {result}")
            self._blink_state[miner.ip] = enable
        except Exception as e:
            log.error(f"[{miner.ip}] vnish POST /find-miner FALHOU: {e}")
            raise

    async def _whatsminer_blink(self, miner, enable: bool):
        """Whatsminer: set_led com formato correto (param + color + timings)."""
        wm_cfg = WhatsminerConfig(ip=miner.ip, password=miner.password)
        if enable:
            payload = {
                "param": "user-define",
                "color": "red",
                "start": 0,
                "duration": 1000,
                "period": 2000,
            }
        else:
            payload = {"param": "auto"}
        resp = await self._wm_client.send(wm_cfg, "set_led", payload)
        codes = []
        if resp and isinstance(resp.get("STATUS"), list):
            codes = [c.get("Code") for c in resp["STATUS"] if isinstance(c, dict)]
        log.info(f"[{miner.ip}] whatsminer set_led enable={enable} codes={codes}")
        self._blink_state[miner.ip] = enable

    async def _braiins_blink(self, miner, enable: bool):
        """BraiinsOS+: REST API oficial — login + PUT /api/v1/actions/locate (LED de
        localizacao sustentado, liga/desliga). Fallback: cgminer ascidentify (flash)."""
        import aiohttp
        user = miner.user or "root"
        pw = miner.password or ""
        base = f"http://{miner.ip}/api/v1"
        timeout = aiohttp.ClientTimeout(total=8)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as s:
                token = None
                try:
                    async with s.post(f"{base}/auth/login", json={"username": user, "password": pw}) as r:
                        if r.status == 200:
                            data = await r.json(content_type=None)
                            token = (data or {}).get("token")
                        else:
                            log.warning(f"[{miner.ip}] braiins login status={r.status}")
                except Exception as e:
                    log.warning(f"[{miner.ip}] braiins login erro: {e}")
                headers = {"Authorization": token} if token else {}
                async with s.put(f"{base}/actions/locate", json=enable, headers=headers) as r2:
                    body = (await r2.text(errors="replace"))[:150]
                    log.info(f"[{miner.ip}] braiins PUT /actions/locate enable={enable} status={r2.status} body={body}")
                    if r2.status in (200, 204):
                        self._blink_state[miner.ip] = enable
                        self._braiins_locate_cache[miner.ip] = (time.time(), enable)
                        return
        except Exception as e:
            log.warning(f"[{miner.ip}] braiins locate REST erro: {e}")
        # Fallback legacy: ascidentify (so um flash momentaneo, mas melhor que nada)
        log.warning(f"[{miner.ip}] braiins locate REST falhou — fallback ascidentify")
        try:
            await cgminer_send(miner.ip, 4028, "ascidentify|0", timeout=3)
        except Exception:
            pass
        self._blink_state[miner.ip] = enable

    async def _bitmain_stock_blink(self, miner, enable: bool):
        """Antminer Stock: POST /cgi-bin/blink.cgi.
        Tenta JSON, form com bool string e form com 0/1. Verifica via get_blink_status."""
        import json as _json
        from .bitmain import _http_request_with_auth, query_blink_status
        user = miner.user or "root"
        pw = miner.password or "root"
        path = "/cgi-bin/blink.cgi"
        target_str = "true" if enable else "false"
        target_int = "1" if enable else "0"

        attempts = [
            (_json.dumps({"blink": target_str}).encode(), {"Content-Type": "application/json"}, "json-bool"),
            (_json.dumps({"blink": enable}).encode(),    {"Content-Type": "application/json"}, "json-native"),
            ({"blink": target_str},                       None,                                 "form-bool"),
            ({"blink": target_int},                       None,                                 "form-int"),
        ]
        ok = False
        for data, hdrs, kind in attempts:
            status, txt = await _http_request_with_auth(
                "POST", miner.ip, path, user, pw,
                data=data, headers=hdrs, timeout=5,
            )
            log.info(f"[{miner.ip}] bitmain blink ({kind}) enable={enable} status={status} body={(txt or '')[:120]}")
            if status in (200, 204):
                await asyncio.sleep(0.4)
                actual = await query_blink_status(miner.ip, user, pw)
                if actual == enable:
                    ok = True
                    break
                if actual is None:
                    # ASIC nao reporta — confiar no 200 OK
                    ok = True
                    break

        if not ok:
            log.warning(f"[{miner.ip}] bitmain blink HTTP falhou — tentando ascidentify fallback")
            result = await cgminer_send(miner.ip, 4028, "ascidentify|0", timeout=3)
            if result:
                log.info(f"[{miner.ip}] bitmain ascidentify fallback → {str(result)[:120]}")

        await asyncio.sleep(0.3)
        actual = await query_blink_status(miner.ip, user, pw)
        if actual is None:
            self._blink_state[miner.ip] = enable
            log.info(f"[{miner.ip}] bitmain blink: status nao verificavel, assumindo {enable}")
        else:
            self._blink_state[miner.ip] = actual
            if actual != enable:
                log.warning(f"[{miner.ip}] bitmain blink: desejado={enable} mas ASIC reporta {actual}")
            else:
                log.info(f"[{miner.ip}] bitmain blink confirmado: {actual}")

    async def _on_miners_updated(self, msg: dict):
        """
        Servidor atualizou a lista de miners cadastrados via dashboard.
        Atualiza self.cfg.miners em memória — sem tocar config.toml.
        Miners já conhecidos têm suas credenciais preservadas;
        novos IPs recebem as credenciais padrão do config (admin/admin).
        """
        server_miners = msg.get("miners", [])  # [{"ip": ..., "label": ...}]

        existing = {m.ip: m for m in self.cfg.miners}
        new_list = []
        for sm in server_miners:
            ip = sm["ip"]
            if ip in existing:
                entry = existing[ip]
                if sm.get("label"):
                    entry.label = sm["label"]
                if sm.get("username"):
                    entry.user = sm["username"]
                if sm.get("password"):
                    entry.password = sm["password"]
                new_list.append(entry)
            else:
                ref = next(iter(existing.values()), None)
                new_list.append(MinerEntry(
                    ip=ip,
                    port=ref.port if ref else 80,
                    user=sm.get("username") or "admin",
                    password=sm.get("password") or "admin",
                    api_key=ref.api_key if ref else None,
                    label=sm.get("label", ip),
                ))

        old_ips = {m.ip for m in self.cfg.miners}
        new_ips = {m["ip"] for m in server_miners}
        added = new_ips - old_ips
        removed = old_ips - new_ips

        self.cfg.miners = new_list
        save_miners_cache(new_list)

        for ip in removed:
            self._firmware_cache.pop(ip, None)
        if added:
            log.info(f"Miners adicionados via dashboard: {added}")
        if removed:
            log.info(f"Miners removidos via dashboard: {removed}")
        log.info(f"Lista de miners atualizada: {len(self.cfg.miners)} ativo(s)")

    async def _on_update_available(self, msg: dict):
        latest = msg.get("latest_version", "")
        if not latest or latest == VERSION:
            return
        if self._update_triggered:
            return
        self._update_triggered = True
        log.info(f"Atualização disponível: {VERSION} → {latest}")
        if self._ws:
            await self._send(self._ws, {
                "type": "update_started",
                "current_version": VERSION,
                "latest_version": latest,
            })
        from .updater import trigger_update
        download_base = msg.get("download_base")
        if download_base:
            base = self.cfg.cloud.url.replace("wss://", "https://").replace("ws://", "http://").split("/ws/")[0]
            download_base = base + download_base
        try:
            await trigger_update(latest, download_base=download_base)
        except Exception as e:
            log.error(f"Erro no auto-update: {e}")
        self._update_triggered = False

    def _miner_kw(self, ip: str) -> dict:
        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            return {}
        return {
            "port": miner.port,
            "user": miner.user,
            "password": miner.password,
            "api_key": miner.api_key,
        }

    async def _on_billing_config(self, msg: dict):
        if not self._devfee_tracker:
            return
        enabled = msg.get("enabled", False)
        if enabled:
            self._devfee_tracker.set_config(msg)
            self._last_billing_confirm_ts = time.time()
            await self._devfee_tracker.crash_recovery(self._firmware_cache, self._miner_kw)
            log.info("[billing] habilitado e confirmado pelo servidor")
        else:
            self._last_billing_confirm_ts = 0
            self._devfee_tracker.set_config(msg)
            await self._devfee_tracker.crash_recovery(self._firmware_cache, self._miner_kw)
            await self._devfee_tracker.restore_all(
                self.cfg.miners, self._firmware_cache, self._miner_kw
            )
            fixed = await self._devfee_tracker.emergency_decontaminate(
                self.cfg.miners, self._firmware_cache, self._miner_kw
            )
            if self._devfee_tracker._billing_config:
                self._devfee_tracker._billing_config["enabled"] = False
            else:
                self._devfee_tracker.set_config({"enabled": False})
            log.info(f"[billing] desabilitado — decontaminate corrigiu {fixed} miner(s)")

    async def _on_turbo_config(self, msg: dict):
        if not self._turbo_engine:
            return
        prev_enabled = bool(self._last_turbo_enabled)
        prev_profile = self._last_turbo_profile
        prev_excluded = set(self._last_turbo_excluded or [])
        enabled = bool(msg.get("enabled", False))
        profile = msg.get("profile", "normal")
        new_excluded = set(msg.get("excluded_ips") or [])
        self._turbo_engine.set_config(msg)
        if enabled:
            same_state = (prev_enabled and prev_profile == profile and prev_excluded == new_excluded)
            if same_state:
                log.info(f"[turbo] config identica ao ultimo aplicado (enabled={enabled} profile={profile}) — sem reapply")
            else:
                full_apply_needed = (not prev_enabled) or (prev_profile != profile)
                if full_apply_needed:
                    log.info(f"[turbo] mudanca real: prev(enabled={prev_enabled} profile={prev_profile}) -> new(enabled={enabled} profile={profile}) — aplicando em todos os miners Vnish + BraiinsOS")
                    asyncio.create_task(self._apply_turbo_to_all_vnish(profile, list(new_excluded)))
                    asyncio.create_task(self._apply_turbo_to_all_braiins(profile, list(new_excluded)))
                else:
                    added = new_excluded - prev_excluded
                    removed = prev_excluded - new_excluded
                    if added or removed:
                        log.info(f"[turbo] excluded_ips delta: +{list(added)} -{list(removed)} (mudanca cirurgica)")
                        asyncio.create_task(self._apply_turbo_excluded_delta(profile, added, removed))
        elif prev_enabled and not enabled:
            log.info("[turbo] disabled — configuracao do firmware mantida como esta nos miners Vnish")
            self._turbo_engine.clear_states()
        else:
            log.debug("[turbo] disabled (estado ja era off)")
        self._last_turbo_profile = profile
        self._last_turbo_excluded = list(new_excluded)
        self._last_turbo_enabled = enabled
        self._save_turbo_state(enabled, profile, list(new_excluded))

    async def _apply_turbo_excluded_delta(self, profile: str, added: set, removed: set):
        for ip in added:
            miner = next((m for m in self.cfg.miners if m.ip == ip), None)
            if not miner:
                continue
            try:
                fw = self._firmware_cache.get(ip) or await self._detect_firmware(miner)
            except Exception:
                fw = ""
            if fw == "braiins":
                try:
                    snap = self._braiins_snapshot.get(ip)
                    ok, _ = await braiins_turbo.restore_profile(
                        ip, miner.user, miner.password, snap,
                        dry_run=not self.cfg.braiins_live_for(ip))
                    log.info(f"[{ip}] turbo excluded (braiins): restore snapshot={snap}W ok={ok}")
                except Exception as e:
                    log.warning(f"[{ip}] braiins turbo excluded erro: {e}")
                continue
            if fw != "vnish":
                continue
            try:
                ok = await self._apply_vnish_turbo_disable(miner)
                log.info(f"[{ip}] turbo excluded: preset_switcher disabled ok={ok}")
                await self._send_safe({
                    "type": "turbo_action",
                    "ip": ip,
                    "from_preset": self._known_presets.get(ip) or "",
                    "to_preset": "",
                    "reason": f"turbo_ignore · preset_switcher disabled (miner removido do auto-switch)",
                })
            except Exception as e:
                log.warning(f"[{ip}] turbo excluded apply erro: {e}")
        for ip in removed:
            miner = next((m for m in self.cfg.miners if m.ip == ip), None)
            if not miner:
                continue
            try:
                fw = self._firmware_cache.get(ip) or await self._detect_firmware(miner)
            except Exception:
                fw = ""
            if fw == "braiins":
                try:
                    ok, det = await braiins_turbo.apply_profile(
                        ip, miner.user, miner.password, profile,
                        dry_run=not self.cfg.braiins_live_for(ip))
                    if det.get("snapshot_w") is not None:
                        self._braiins_snapshot.setdefault(ip, det["snapshot_w"])
                    log.info(f"[{ip}] turbo unexcluded (braiins): reaplicado ok={ok} target={det.get('target_w')}W")
                except Exception as e:
                    log.warning(f"[{ip}] braiins turbo unexcluded erro: {e}")
                continue
            if fw != "vnish":
                continue
            try:
                from_preset = self._known_presets.get(ip) or ""
                ok, detail = await self._apply_vnish_turbo_profile_with_detail(miner, profile)
                log.info(f"[{ip}] turbo unexcluded: preset_switcher reenabled ok={ok}")
                if ok and detail:
                    await self._send_safe({
                        "type": "turbo_action",
                        "ip": ip,
                        "from_preset": from_preset,
                        "to_preset": detail.get("stock_preset") or "",
                        "reason": f"turbo_unignore · profile={profile} (miner reincluido no auto-switch)",
                    })
            except Exception as e:
                log.warning(f"[{ip}] turbo unexcluded apply erro: {e}")

    async def _apply_vnish_turbo_disable(self, miner) -> bool:
        mc = MinerConfig(
            ip=miner.ip, port=miner.port,
            user=miner.user, password=miner.password,
            api_key=miner.api_key,
        )
        try:
            cur_settings = await self._poller.client.get(mc, "/settings")
            cur_sw = (cur_settings or {}).get("miner", {}).get("overclock", {}).get("preset_switcher", {}) if isinstance(cur_settings, dict) else {}
            if cur_sw and bool(cur_sw.get("enabled")) is False:
                log.info(f"[{miner.ip}] vnish turbo disable: preset_switcher ja desabilitado — pulando POST (sem restart)")
                return True
        except Exception as e:
            log.debug(f"[{miner.ip}] vnish turbo disable: pre-check falhou ({e}) — vai aplicar normalmente")
        payload = {"miner": {"overclock": {"preset_switcher": {"enabled": False}}}}
        try:
            resp = await self._poller.client.post(mc, "/settings", payload)
        except Exception as e:
            log.warning(f"[{miner.ip}] vnish turbo disable POST /settings falhou: {e}")
            return False
        if isinstance(resp, dict):
            if resp.get("reboot_required"):
                try: await self._poller.client.post(mc, "/system/reboot")
                except Exception as e: log.warning(f"[{miner.ip}] /system/reboot falhou apos disable: {e}")
            elif resp.get("restart_required"):
                try: await self._poller.client.post(mc, "/mining/restart")
                except Exception as e: log.warning(f"[{miner.ip}] /mining/restart falhou apos disable: {e}")
        return True

    async def _apply_turbo_to_all_vnish(self, profile: str, excluded_ips: list):
        excl = set(excluded_ips or [])
        applied = 0
        skipped = 0
        failed = 0
        vnish_miners = []
        for miner in list(self.cfg.miners):
            if miner.ip in excl:
                continue
            try:
                fw = self._firmware_cache.get(miner.ip) or await self._detect_firmware(miner)
            except Exception:
                fw = ""
            if fw == "vnish":
                vnish_miners.append(miner)
        await self._send_safe({
            "type": "turbo_apply_started",
            "profile": profile,
            "total": len(vnish_miners),
            "miners": [{"ip": m.ip, "label": (m.label or m.ip)} for m in vnish_miners],
        })
        for miner in vnish_miners:
            await self._send_safe({
                "type": "turbo_apply_progress",
                "ip": miner.ip,
                "label": miner.label or miner.ip,
                "phase": "applying",
            })
            try:
                from_preset = self._known_presets.get(miner.ip) or ""
                ok, detail = await self._apply_vnish_turbo_profile_with_detail(miner, profile)
                if ok:
                    applied += 1
                else:
                    skipped += 1
                await self._send_safe({
                    "type": "turbo_apply_progress",
                    "ip": miner.ip,
                    "label": miner.label or miner.ip,
                    "phase": "applied" if ok else "error",
                    **(detail or {}),
                })
                if ok and detail:
                    parts = [f"profile={profile}"]
                    if detail.get("top_preset"):     parts.append(f"top={detail['top_preset']}")
                    if detail.get("min_preset"):     parts.append(f"min={detail['min_preset']}")
                    if detail.get("decrease_temp") is not None and detail.get("rise_temp") is not None:
                        parts.append(f"{detail['decrease_temp']}/{detail['rise_temp']}")
                    if detail.get("check_minutes") is not None:
                        parts.append(f"{detail['check_minutes']}min")
                    if detail.get("action") and detail["action"] != "no_restart":
                        parts.append(detail["action"])
                    await self._send_safe({
                        "type": "turbo_action",
                        "ip": miner.ip,
                        "from_preset": from_preset,
                        "to_preset": detail.get("stock_preset") or "",
                        "reason": "turbo_enabled · " + " · ".join(parts),
                    })
                elif not ok:
                    await self._send_safe({
                        "type": "turbo_action",
                        "ip": miner.ip,
                        "from_preset": from_preset,
                        "to_preset": "",
                        "reason": f"turbo_enable_failed · profile={profile} · " + (detail.get("error", "") if detail else ""),
                    })
            except Exception as e:
                failed += 1
                log.warning(f"[{miner.ip}] vnish turbo apply erro: {e}")
                await self._send_safe({
                    "type": "turbo_apply_progress",
                    "ip": miner.ip,
                    "label": miner.label or miner.ip,
                    "phase": "error",
                    "error": str(e),
                })
                await self._send_safe({
                    "type": "turbo_action",
                    "ip": miner.ip,
                    "from_preset": self._known_presets.get(miner.ip) or "",
                    "to_preset": "",
                    "reason": f"turbo_enable_exception · profile={profile} · {e}",
                })
        log.info(f"[turbo] vnish profile={profile} aplicado: ok={applied} skipped={skipped} fail={failed}")
        await self._send_safe({
            "type": "turbo_apply_completed",
            "profile": profile,
            "total": len(vnish_miners),
            "applied": applied,
            "skipped": skipped,
            "failed": failed,
        })

    async def _apply_turbo_to_all_braiins(self, profile: str, excluded_ips: list):
        """BraiinsOS+: configura o autotuner nativo (power-target + DPS) por miner.
        Dry-run por padrao (so loga o plano); live com env BRAIINS_TURBO_LIVE=1."""
        excl = set(excluded_ips or [])
        braiins_miners = []
        for miner in list(self.cfg.miners):
            if miner.ip in excl:
                continue
            try:
                fw = self._firmware_cache.get(miner.ip) or await self._detect_firmware(miner)
            except Exception:
                fw = ""
            if fw == "braiins":
                braiins_miners.append(miner)
        if not braiins_miners:
            return
        log.info(f"[turbo] braiins profile={profile} — {len(braiins_miners)} miner(s) "
                 f"(global_live={self.cfg.braiins.live} live_ips={self.cfg.braiins.live_ips or []})")
        applied = skipped = failed = 0
        for miner in braiins_miners:
            try:
                dry = not self.cfg.braiins_live_for(miner.ip)
                ok, det = await braiins_turbo.apply_profile(
                    miner.ip, miner.user, miner.password, profile, dry_run=dry)
                if det.get("snapshot_w") is not None:
                    self._braiins_snapshot.setdefault(miner.ip, det["snapshot_w"])
                if ok:
                    applied += 1
                else:
                    failed += 1
                mode = "DRY-RUN" if det.get("dry_run") else "LIVE"
                if ok:
                    reason = (f"braiins_turbo {mode} · profile={profile} · "
                              f"power-target={det.get('target_w')}W (stock={det.get('stock_w')}W "
                              f"+{int(det.get('margin', 0) * 100)}%) · dps={det.get('dps')}")
                else:
                    reason = f"braiins_turbo {mode} FALHOU · profile={profile} · {det.get('error', '')}"
                await self._send_safe({
                    "type": "turbo_action",
                    "ip": miner.ip,
                    "from_preset": (f"{det.get('snapshot_w')}W" if det.get("snapshot_w") else ""),
                    "to_preset": (f"{det.get('target_w')}W" if det.get("target_w") else ""),
                    "reason": reason,
                })
            except Exception as e:
                failed += 1
                log.warning(f"[{miner.ip}] braiins turbo apply erro: {e}")
        log.info(f"[turbo] braiins profile={profile} aplicado: ok={applied} skipped={skipped} fail={failed}")

    async def _send_safe(self, payload: dict):
        ws = self._ws
        if not ws or not self._ws_connected:
            return
        try:
            await self._send(ws, payload)
        except Exception as e:
            log.debug(f"_send_safe falhou: {e}")

    async def _apply_vnish_turbo_profile(self, miner, profile: str) -> bool:
        ok, _ = await self._apply_vnish_turbo_profile_with_detail(miner, profile)
        return ok

    async def _apply_vnish_turbo_profile_with_detail(self, miner, profile: str):
        detail: dict = {"profile": profile}
        mc = MinerConfig(
            ip=miner.ip, port=miner.port,
            user=miner.user, password=miner.password,
            api_key=miner.api_key,
        )
        presets_raw = await self._poller.client.get(mc, "/autotune/presets")
        if not isinstance(presets_raw, list) or not presets_raw:
            log.warning(f"[{miner.ip}] vnish turbo: lista de presets vazia")
            detail["error"] = "lista de presets vazia"
            return False, detail
        presets = [
            {"name": p.get("name", ""), "pretty": p.get("pretty", p.get("name", ""))}
            for p in presets_raw
            if p.get("name") and p.get("name", "").lower() != "disabled"
        ]
        stock_th = 0.0
        try:
            summary = await self._poller.client.get(mc, "/summary")
            if isinstance(summary, dict):
                mi = summary.get("miner") or {}
                measure = mi.get("hr_measure", "GH/s")
                div = 1000 if measure == "GH/s" else 1_000_000
                stock_raw = mi.get("hr_stock") or 0
                if stock_raw:
                    stock_th = float(stock_raw) / div
        except Exception as e:
            log.debug(f"[{miner.ip}] vnish turbo: falha lendo /summary: {e}")
        if stock_th <= 0:
            try:
                from .bitmain import _lookup_antminer_stock
                info = await self._poller.client.get(mc, "/info")
                model = (info or {}).get("miner")
                fb = _lookup_antminer_stock(model)
                if fb:
                    stock_th = float(fb)
            except Exception:
                pass
        detail["stock_th"] = round(stock_th, 1)
        plan = vnish_turbo.plan(profile, presets, stock_th)
        if not plan:
            log.warning(f"[{miner.ip}] vnish turbo: plan() retornou None (profile={profile} stock_th={stock_th})")
            detail["error"] = f"sem plan (stock_th={stock_th})"
            return False, detail
        meta = plan.pop("_meta", {})
        sw = plan.get("miner", {}).get("overclock", {}).get("preset_switcher", {})
        detail.update({
            "stock_preset": meta.get("initial_preset") or meta.get("stock_preset"),
            "factory_stock_preset": meta.get("stock_preset"),
            "top_preset": meta.get("top_preset"),
            "min_preset": meta.get("min_preset"),
            "decrease_temp": sw.get("decrease_temp"),
            "rise_temp": sw.get("rise_temp"),
            "check_minutes": int((sw.get("check_time") or 0) / 60),
            "ignore_fan_speed": sw.get("ignore_fan_speed"),
        })
        log.info(
            f"[{miner.ip}] vnish turbo profile={profile} stock_th={stock_th:.1f} "
            f"stock={meta.get('stock_preset')} initial={meta.get('initial_preset')} "
            f"top={meta.get('top_preset')} min={meta.get('min_preset')}"
        )
        try:
            cur_settings = await self._poller.client.get(mc, "/settings")
            cur_oc = (cur_settings or {}).get("miner", {}).get("overclock", {}) if isinstance(cur_settings, dict) else {}
            cur_sw = cur_oc.get("preset_switcher") or {}
            cur_preset = cur_oc.get("preset") or cur_oc.get("current_preset") or ""
            desired_preset = plan.get("miner", {}).get("overclock", {}).get("preset")
            if (cur_preset == desired_preset
                and bool(cur_sw.get("enabled")) == bool(sw.get("enabled"))
                and (cur_sw.get("decrease_temp") or 0) == (sw.get("decrease_temp") or 0)
                and (cur_sw.get("rise_temp") or 0) == (sw.get("rise_temp") or 0)
                and (cur_sw.get("top_preset") or "") == (sw.get("top_preset") or "")
                and (cur_sw.get("min_preset") or "") == (sw.get("min_preset") or "")
                and (cur_sw.get("check_time") or 0) == (sw.get("check_time") or 0)
                and bool(cur_sw.get("ignore_fan_speed")) == bool(sw.get("ignore_fan_speed"))):
                log.info(f"[{miner.ip}] vnish turbo: settings ja identicos ao desejado — pulando POST (sem restart)")
                detail["action"] = "no_restart"
                detail["skipped"] = True
                applied_name = meta.get("initial_preset") or meta.get("stock_preset")
                if applied_name:
                    self._known_presets[miner.ip] = applied_name
                return True, detail
        except Exception as e:
            log.debug(f"[{miner.ip}] vnish turbo: pre-check de /settings falhou ({e}) — vai aplicar normalmente")
        try:
            resp = await self._poller.client.post(mc, "/settings", plan)
        except Exception as e:
            log.warning(f"[{miner.ip}] vnish turbo POST /settings falhou: {e}")
            detail["error"] = f"POST /settings: {e}"
            return False, detail
        reboot_required = bool(isinstance(resp, dict) and resp.get("reboot_required"))
        restart_required = bool(isinstance(resp, dict) and resp.get("restart_required"))
        action = "no_restart"
        if reboot_required:
            log.info(f"[{miner.ip}] vnish turbo: reboot completo solicitado — POST /system/reboot")
            try:
                await self._poller.client.post(mc, "/system/reboot")
                action = "rebooted"
            except Exception as e:
                log.warning(f"[{miner.ip}] /system/reboot falhou: {e}")
                action = "reboot_failed"
        elif restart_required:
            log.info(f"[{miner.ip}] vnish turbo: restart de mineracao solicitado — POST /mining/restart")
            try:
                await self._poller.client.post(mc, "/mining/restart")
                action = "restarted"
            except Exception as e:
                log.warning(f"[{miner.ip}] /mining/restart falhou: {e}")
                action = "restart_failed"
        else:
            log.info(f"[{miner.ip}] vnish turbo: aplicado sem necessidade de restart")
        detail["action"] = action
        applied_name = meta.get("initial_preset") or meta.get("stock_preset")
        if applied_name:
            self._known_presets[miner.ip] = applied_name
        return True, detail

    async def _apply_turbo(self, ip: str, preset: str, firmware: str) -> bool:
        if not self._turbo_engine or not self._turbo_engine.enabled:
            log.warning(f"[{ip}] turbo apply REJEITADO: turbo desabilitado")
            return False
        if self._turbo_engine.is_excluded(ip):
            log.warning(f"[{ip}] turbo apply REJEITADO: miner excluido pelo usuario")
            return False
        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            return False
        try:
            if firmware == "whatsminer":
                wm_cfg = WhatsminerConfig(ip=miner.ip, password=miner.password)
                ok = await self._wm_client.set_power_mode(wm_cfg, preset)
                if ok:
                    self._known_presets[ip] = preset
                return ok
            else:
                mc = MinerConfig(
                    ip=miner.ip, port=miner.port,
                    user=miner.user, password=miner.password,
                    api_key=miner.api_key,
                )
                payload = {"miner": {"overclock": {"preset": preset}}}
                resp = await self._poller.client.post(mc, "/settings", payload)
                if isinstance(resp, dict):
                    if resp.get("reboot_required"):
                        await self._poller.client.post(mc, "/system/reboot")
                    elif resp.get("restart_required"):
                        await self._poller.client.post(mc, "/mining/restart")
                self._known_presets[ip] = preset
                return True
        except Exception as e:
            log.warning(f"[{ip}] turbo apply error: {e}")
            return False

    async def _read_current_preset(self, ip: str) -> str:
        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            return ""
        mc = MinerConfig(
            ip=miner.ip, port=miner.port,
            user=miner.user, password=miner.password,
            api_key=miner.api_key,
        )
        try:
            data = await self._poller.client.get(mc, "/settings")
            if isinstance(data, dict):
                oc = data.get("miner", {}).get("overclock", {})
                preset = oc.get("preset") or oc.get("current_preset") or ""
                if not preset or preset.lower() == "disabled":
                    oc_keys = list(oc.keys())[:10] if oc else []
                    top_keys = list(data.keys())[:10]
                    miner_keys = list(data.get("miner", {}).keys())[:10] if data.get("miner") else []
                    log.warning(f"[{ip}] /settings preset vazio | oc_keys={oc_keys} | miner_keys={miner_keys} | top_keys={top_keys}")
                    for k, v in oc.items():
                        if isinstance(v, str) and v and v.lower() != "disabled":
                            log.info(f"[{ip}] /settings oc[{k}] = {v}")
                    if not oc and data.get("miner"):
                        for k, v in data["miner"].items():
                            if isinstance(v, dict) and "preset" in v:
                                preset = v["preset"]
                                log.info(f"[{ip}] /settings miner.{k}.preset = {preset}")
                                break
                if preset and preset.lower() != "disabled":
                    log.info(f"[{ip}] preset lido de /settings: {preset}")
                    return str(preset)
        except Exception as e:
            log.debug(f"[{ip}] read_current_preset error: {e}")
        return ""

    async def _fetch_turbo_presets(self, ip: str) -> list[str]:
        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            return []
        mc = MinerConfig(
            ip=miner.ip, port=miner.port,
            user=miner.user, password=miner.password,
            api_key=miner.api_key,
        )
        try:
            data = await self._poller.client.get(mc, "/autotune/presets")
            if isinstance(data, list):
                return [
                    p["name"] for p in data
                    if p.get("name", "").lower() != "disabled"
                ]
        except Exception as e:
            log.debug(f"[{ip}] fetch turbo presets error: {e}")
        return []

    async def _on_get_presets(self, ws, msg: dict):
        """Busca presets disponíveis de cada ASIC e devolve ao cloud."""
        session_id = msg.get("session_id")
        requested_ips = msg.get("miners", [m.ip for m in self.cfg.miners])

        async def fetch_presets(miner):
            mc = MinerConfig(
                ip=miner.ip,
                port=miner.port,
                user=miner.user,
                password=miner.password,
                api_key=miner.api_key,
            )
            try:
                data = await self._poller.client.get(mc, "/autotune/presets")
                presets = [
                    {"name": p["name"], "pretty": p.get("pretty", p["name"])}
                    for p in (data if isinstance(data, list) else [])
                    # Remove "disabled" — tratado pelo dashboard como "Restaurar padrão"
                    if p.get("name", "").lower() != "disabled"
                ]
                return {"ip": miner.ip, "presets": presets}
            except Exception as e:
                log.debug(f"[{miner.ip}] get_presets erro: {e}")
                return {"ip": miner.ip, "presets": [], "error": str(e)}

        miners_to_query = [m for m in self.cfg.miners if m.ip in requested_ips]
        results = await asyncio.gather(*[fetch_presets(m) for m in miners_to_query])

        await self._send(ws, {
            "type": "presets_result",
            "session_id": session_id,
            "miners": list(results),
        })
        log.info(f"Presets enviados para sessão {session_id} ({len(results)} miners)")

    async def _on_apply_preset(self, ws, msg: dict):
        """Aplica um preset em uma ASIC. Preset '__disabled__' restaura o padrão."""
        cmd_id = msg.get("cmd_id", "?")
        ip = msg.get("ip")
        preset = msg.get("preset")

        log.info(f"apply_preset: {preset} → {ip} (cmd_id={cmd_id})")

        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            await self._send(ws, {
                "type": "preset_applied",
                "cmd_id": cmd_id,
                "ip": ip,
                "result": f"error: IP {ip} não encontrado",
            })
            return

        mc = MinerConfig(
            ip=miner.ip,
            port=miner.port,
            user=miner.user,
            password=miner.password,
            api_key=miner.api_key,
        )
        try:
            if preset == "__disabled__":
                # Lê configurações para extrair volt/freq de fábrica
                settings_data = await self._poller.client.get(mc, "/settings")
                settings_str = json.dumps(settings_data or {})
                volt_m = re.search(r'"default_voltage"\s*:\s*(\d+)', settings_str)
                freq_m = re.search(r'"default_freq"\s*:\s*(\d+)', settings_str)
                volt = int(volt_m.group(1)) if volt_m else 0
                freq = int(freq_m.group(1)) if freq_m else 0
                if volt == 0 or freq == 0:
                    log.warning(f"[{ip}] default_voltage/freq não encontrados — usando 0")
                payload = {"miner": {"overclock": {
                    "preset": "disabled",
                    "globals": {"volt": volt, "freq": freq},
                    "preset_switcher": {"enabled": False},
                }}}
            else:
                payload = {"miner": {"overclock": {
                    "preset": preset,
                    "preset_switcher": {"enabled": False},
                }}}
            log.info(f"[{ip}] apply_preset: desativando autoswitch + aplicando preset='{preset}'")

            resp = await self._poller.client.post(mc, "/settings", payload)
            result = "ok"
            log.info(f"Preset {preset} aplicado em {ip}")

            if preset != "__disabled__" and preset != "disabled":
                self._known_presets[ip] = preset
                log.info(f"[{ip}] known_preset atualizado: {preset}")
            else:
                self._known_presets.pop(ip, None)

            if isinstance(resp, dict):
                if resp.get("reboot_required"):
                    log.info(f"[{ip}] reboot_required → reiniciando sistema")
                    await self._poller.client.post(mc, "/system/reboot")
                    result = "ok:rebooted"
                elif resp.get("restart_required"):
                    log.info(f"[{ip}] restart_required → reiniciando mineração")
                    await self._poller.client.post(mc, "/mining/restart")
                    result = "ok:restarted"

        except Exception as e:
            result = f"error: {e}"
            log.warning(f"Falha ao aplicar preset {preset} em {ip}: {e}")

        await self._send(ws, {
            "type": "preset_applied",
            "cmd_id": cmd_id,
            "ip": ip,
            "result": result,
        })

    async def _on_set_pools(self, ws, msg: dict):
        cmd_id = msg.get("cmd_id", "?")
        ip = msg.get("ip")
        pools = msg.get("pools") or []
        log.info(f"set_pools: {len(pools)} pool(s) -> {ip} (cmd_id={cmd_id})")

        miner = next((m for m in self.cfg.miners if m.ip == ip), None)
        if not miner:
            await self._send(ws, {
                "type": "pools_set", "cmd_id": cmd_id, "ip": ip,
                "result": f"error: IP {ip} nao encontrado",
            })
            return

        fw = self._firmware_cache.get(ip) or await self._detect_firmware(miner)
        if not fw:
            await self._send(ws, {
                "type": "pools_set", "cmd_id": cmd_id, "ip": ip,
                "result": "error: firmware nao detectado",
            })
            return

        clean_pools = []
        for p in pools:
            url = (p.get("url") or "").strip()
            user = (p.get("user") or "").strip()
            if not url or not user:
                continue
            clean_pools.append({
                "url": url,
                "user": user,
                "password": (p.get("password") or p.get("pass") or "x").strip() or "x",
            })
        if not clean_pools:
            await self._send(ws, {
                "type": "pools_set", "cmd_id": cmd_id, "ip": ip,
                "result": "error: nenhuma pool valida informada",
            })
            return

        try:
            rv = await self._pool_manager.set_user_pools(ip, fw, clean_pools, **self._miner_kw(ip))
            if rv is True:
                result = "ok"
            elif rv is False:
                result = "error: set_user_pools retornou false"
            else:
                result = f"error: {rv}"
            if rv is True and self.store:
                try:
                    self.store.save_pool_state(ip, [
                        {"url": p["url"], "user": p["user"], "pass": p["password"]}
                        for p in clean_pools
                    ], mode="user")
                except Exception as e:
                    log.warning(f"[{ip}] falha salvando pool_state pos set_pools: {e}")
        except Exception as e:
            result = f"error: {type(e).__name__}: {e}"
            log.warning(f"Falha em set_pools {ip}: {e!r}")

        await self._send(ws, {
            "type": "pools_set", "cmd_id": cmd_id, "ip": ip, "result": result,
        })

        if result == "ok":
            asyncio.create_task(self._refresh_miner_snapshot(ws, ip, delay=4.0))

    async def _on_get_log(self, ws, msg: dict):
        import os
        lines = msg.get("lines", 500)
        log_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        log_path = os.path.join(log_dir, "agent.log")
        try:
            with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                all_lines = f.readlines()
            tail = all_lines[-lines:]
            await self._send(ws, {
                "type": "log_result",
                "session_id": msg.get("session_id"),
                "log": "".join(tail),
            })
        except Exception as e:
            await self._send(ws, {
                "type": "log_result",
                "session_id": msg.get("session_id"),
                "log": f"Erro ao ler log: {e}",
            })

    async def _on_scan_network(self, ws, msg: dict):
        session_id = msg.get("session_id")
        self._scan_active = True
        try:
            from .scanner import scan_subnet, get_local_ip, get_all_local_prefixes
            local_ip = get_local_ip()
            prefixes = get_all_local_prefixes()
            known_ips = {m.ip for m in self.cfg.miners}
            # Inclui as subnets das maquinas ja cadastradas — o host do agente pode
            # estar em outra faixa (VLAN/roteador) e o scan nunca as enxergaria
            for kip in known_ips:
                parts = kip.split(".")
                if len(parts) == 4:
                    p = ".".join(parts[:3])
                    if p not in prefixes:
                        prefixes.append(p)

            log.info(f"Scan rede: {[p+'.0/24' for p in prefixes]} (excluindo {len(known_ips)} miners conhecidos)")

            total_subnets = len(prefixes)
            all_results = []
            for idx, prefix in enumerate(prefixes, start=1):
                await self._send(ws, {
                    "type": "scan_progress",
                    "session_id": session_id,
                    "phase": "subnet_start",
                    "subnet": f"{prefix}.0/24",
                    "subnet_idx": idx,
                    "subnet_total": total_subnets,
                    "done": 0,
                    "total": 254,
                    "found": len(all_results),
                })

                async def _progress(done, total, found_in_subnet, sub_prefix, _idx=idx):
                    await self._send(ws, {
                        "type": "scan_progress",
                        "session_id": session_id,
                        "phase": "scanning",
                        "subnet": f"{sub_prefix}.0/24",
                        "subnet_idx": _idx,
                        "subnet_total": total_subnets,
                        "done": done,
                        "total": total,
                        "found": len(all_results) + found_in_subnet,
                    })

                results = await scan_subnet(prefix, progress_cb=_progress)
                all_results.extend(results)

            seen_ips: set[str] = set()
            discovered = []
            known_found = 0
            for r in all_results:
                if r["ip"] in seen_ips:
                    continue
                seen_ips.add(r["ip"])
                if r["ip"] in known_ips:
                    known_found += 1
                else:
                    discovered.append(r)

            ranges_str = ", ".join(p + ".0/24" for p in prefixes)
            await self._send(ws, {
                "type": "scan_result",
                "session_id": session_id,
                "miners": discovered,
                "known_found": known_found,
                "range": ranges_str,
                "local_ip": local_ip,
            })
            log.info(f"Scan concluído: {len(discovered)} novas + {known_found} ja cadastradas em {ranges_str}")
        except Exception as e:
            log.error(f"Erro no scan_network: {e}")
            await self._send(ws, {
                "type": "scan_result",
                "session_id": session_id,
                "miners": [],
                "error": str(e),
            })
        finally:
            self._scan_active = False

    # ─── Keepalive de aplicação ────────────────────────────────────────────

    async def _keepalive_loop(self, ws):
        """Envia ping de aplicação a cada 25s. Fecha se sem pong por 180s."""
        try:
            while True:
                await asyncio.sleep(25)
                if time.time() - self._last_pong > 180:
                    log.warning("Sem pong há 180s — forçando reconexão")
                    await ws.close()
                    return
                await self._send(ws, {"type": "ping"})
        except asyncio.CancelledError:
            pass

    async def _http_keepalive(self):
        """GET /health a cada 4min para impedir spin-down do Render free tier."""
        import aiohttp as _aio
        base = self.cfg.cloud.url.split("/ws/")[0]
        health_url = base.replace("wss://", "https://").replace("ws://", "http://") + "/health"
        try:
            while True:
                await asyncio.sleep(240)
                try:
                    if self._session_client:
                        async with self._session_client.get(health_url, timeout=_aio.ClientTimeout(total=10)) as r:
                            log.debug(f"HTTP keepalive → {r.status}")
                except Exception:
                    pass
        except asyncio.CancelledError:
            pass

    # ─── Env report (temperatura ambiente vs miners) ──────────────────────

    async def _emit_env_report(self, ws, snapshots, force: bool = False) -> bool:
        """Envia env_report se ja passaram 300s desde o ultimo. Retorna True se enviou."""
        now = time.time()
        if not force and (now - self._last_env_report) < 290:
            return False
        if not snapshots:
            return False
        mining = [s for s in snapshots if s.get("status") == "mining"]
        total_cfg = len(self.cfg.miners)
        temps = []
        max_t = None
        for s in mining:
            t = s.get("chip_temp_max")
            if t is None:
                continue
            try:
                tf = float(t)
            except (TypeError, ValueError):
                continue
            if not (-20 <= tf <= 150):
                continue
            temps.append(tf)
            if max_t is None or tf > max_t:
                max_t = tf
        if not mining and not temps:
            return False
        payload = {
            "type": "env_report",
            "miner_avg_c": round(sum(temps) / len(temps), 2) if temps else None,
            "miner_max_c": round(max_t, 2) if max_t is not None else None,
            "online_count": len(mining),
            "total_count": total_cfg,
        }
        try:
            await self._send(ws, payload)
            self._last_env_report = now
            log.debug(f"[env] avg={payload['miner_avg_c']} max={payload['miner_max_c']} online={payload['online_count']}/{total_cfg}")
            return True
        except Exception as e:
            log.debug(f"[env] send falhou: {e}")
            return False

    async def _env_loop(self, ws):
        """Poll leve a cada 5 min quando nao ha sessao ativa, para popular historico."""
        try:
            while self._ws_connected:
                await asyncio.sleep(300)
                if not self._ws_connected:
                    break
                if self._active_sessions:
                    continue
                if not self._firmware_cache:
                    log.debug("[env-standalone] firmware_cache vazio - pulando")
                    continue
                try:
                    sem = asyncio.Semaphore(self.cfg.collector.parallel_limit)
                    snapshots = await self._poll_all(sem)
                    await self._emit_env_report(ws, snapshots)
                except Exception as e:
                    log.debug(f"[env-standalone] erro: {e}")
        except asyncio.CancelledError:
            pass

    # ─── Billing standalone (independente de sessões ativas) ──────────────

    async def _billing_loop(self, ws):
        """Ticks de devfee mesmo sem dashboard aberto. Usa firmware_cache populado por sessões anteriores."""
        interval = self.cfg.collector.interval
        try:
            while self._ws_connected:
                await asyncio.sleep(interval)

                if self._active_sessions:
                    continue

                billing_allowed = (
                    self._ws_connected
                    and self._devfee_tracker
                    and self._devfee_tracker.enabled
                    and (time.time() - self._last_billing_confirm_ts) < 300
                )

                if not billing_allowed:
                    if self._devfee_tracker and self._devfee_tracker.enabled:
                        has_devfee_miners = any(
                            s.current_mode != "user"
                            for s in self._devfee_tracker._states.values()
                        )
                        if has_devfee_miners:
                            reason = "ws_disconnected" if not self._ws_connected else "billing_stale"
                            log.warning(f"[billing] {reason} — restaurando pools (standalone)")
                            await self._devfee_tracker.restore_all(
                                self.cfg.miners, self._firmware_cache, self._miner_kw
                            )
                    continue

                if not self._firmware_cache:
                    log.debug("[billing-standalone] firmware_cache vazio — aguardando primeira sessão")
                    continue

                for miner in self.cfg.miners:
                    ip = miner.ip
                    fw = self._firmware_cache.get(ip)
                    if not fw:
                        continue
                    kw = self._miner_kw(ip)
                    try:
                        mode = await self._devfee_tracker.tick(ip, fw, kw)
                        log.debug(f"[billing-standalone] {ip} fw={fw} mode={mode}")
                    except Exception as e:
                        log.warning(f"[{ip}] billing-standalone tick erro: {e}")

                now = time.time()
                if now - self._last_devfee_report >= 300:
                    report = self._devfee_tracker.get_report() if self._devfee_tracker else None
                    if report:
                        await self._send(ws, {"type": "devfee_report", "miners": report})
                        self._last_devfee_report = now
                        log.info(f"[billing-standalone] report enviado: {len(report)} miner(s)")
        except asyncio.CancelledError:
            pass

    # ─── Loop único de coleta com fan-out ──────────────────────────────────

    async def _collection_loop(self, ws):
        """
        Task única de coleta: faz poll das ASICs e envia os dados
        para TODAS as sessões ativas (fan-out).
        Para automaticamente quando _active_sessions fica vazio.
        """
        interval = self.cfg.collector.interval
        sem = asyncio.Semaphore(self.cfg.collector.parallel_limit)

        log.info(f"Coleta on-demand iniciada (intervalo {interval}s)")

        first_cycle = True
        try:
            while self._active_sessions:
                t0 = time.time()
                if self._scan_active:
                    # Scan de rede em andamento — pausa o poll para nao disputar
                    # a porta 4028 com as sondas (cgminer atende 1 conexao por vez)
                    await asyncio.sleep(1)
                    continue
                if first_cycle:
                    snapshots = await self._poll_all_streaming(ws, sem)
                    first_cycle = False
                else:
                    snapshots = await self._poll_all(sem)

                if self._pending_firmware_reports:
                    for ip, fw in list(self._pending_firmware_reports.items()):
                        await self._send(ws, {"type": "firmware_detected", "ip": ip, "firmware": fw})
                    self._pending_firmware_reports.clear()

                billing_allowed = (
                    self._ws_connected
                    and self._devfee_tracker
                    and self._devfee_tracker.enabled
                    and (time.time() - self._last_billing_confirm_ts) < 300
                )

                if not billing_allowed and self._devfee_tracker and self._devfee_tracker.enabled:
                    has_devfee_miners = any(
                        s.current_mode != "user" for s in self._devfee_tracker._states.values()
                    )
                    if has_devfee_miners:
                        reason = "ws_disconnected" if not self._ws_connected else "billing_stale"
                        log.warning(f"[billing] {reason} — restaurando pools (politica conservadora)")
                        await self._devfee_tracker.restore_all(
                            self.cfg.miners, self._firmware_cache, self._miner_kw
                        )

                if snapshots and billing_allowed:
                    for snap in snapshots:
                        if snap.get("status") == "mining":
                            ip = snap.get("ip", "")
                            fw = snap.get("firmware") or self._firmware_cache.get(ip, "bitmain_stock")
                            kw = self._miner_kw(ip)
                            try:
                                mode = await self._devfee_tracker.tick(ip, fw, kw)
                                snap["devfee_mode"] = mode
                            except Exception as e:
                                log.warning(f"[{ip}] devfee tick erro: {e}")
                                snap["devfee_mode"] = "user"
                                await self._send(ws, {
                                    "type": "devfee_alert",
                                    "ip": ip,
                                    "alert_type": "tick_error",
                                    "detail": str(e),
                                })

                if snapshots:
                    for snap in snapshots:
                        ip = snap.get("ip", "")
                        if ip in self._known_presets and not snap.get("current_preset"):
                            snap["current_preset"] = self._known_presets[ip]

                if snapshots and self._turbo_engine and self._turbo_engine.enabled:
                    for snap in snapshots:
                        if snap.get("status") != "mining":
                            continue
                        ip = snap.get("ip", "")
                        fw = snap.get("firmware") or self._firmware_cache.get(ip, "bitmain_stock")
                        if self._turbo_engine.is_excluded(ip):
                            snap["turbo_decision"] = {"state": "excluded", "reason": "miner_excluded_by_user"}
                            continue
                        try:
                            if fw == "vnish":
                                self._turbo_engine.track_only_stats(ip, snap, fw)
                                snap["turbo_decision"] = {"state": "firmware_managed", "reason": "vnish_native_switcher"}
                            elif fw == "braiins":
                                # BraiinsOS+ usa o autotuner NATIVO (power-target + DPS),
                                # configurado em _apply_turbo_to_all_braiins ao habilitar.
                                # Por tick so acumulamos estatisticas (como no Vnish).
                                self._turbo_engine.track_only_stats(ip, snap, fw)
                                snap["turbo_decision"] = {
                                    "state": "firmware_managed",
                                    "reason": "braiins_native_tuner" + ("" if self.cfg.braiins_live_for(ip) else "_dryrun"),
                                }
                            elif fw == "whatsminer":
                                decision = await self._turbo_engine.tick(
                                    ip, snap, fw,
                                    lambda _ip, _preset, _fw=fw: self._apply_turbo(_ip, _preset, _fw),
                                )
                                snap["turbo_decision"] = decision.to_dict()
                            elif fw == "bitmain_stock":
                                alert = self._turbo_engine.monitor_only(ip, snap)
                                if alert:
                                    snap["turbo_alert"] = alert
                        except Exception as e:
                            log.warning(f"[{ip}] turbo tick error: {e}")

                if snapshots:
                    ts = int(time.time())
                    for session_id in list(self._active_sessions):
                        await self._send(ws, {
                            "type": "data",
                            "session_id": session_id,
                            "ts": ts,
                            "snapshots": snapshots,
                        })

                    if self._devfee_tracker and self._devfee_tracker.enabled:
                        now = time.time()
                        if now - self._last_devfee_report >= 300:
                            report = self._devfee_tracker.get_report()
                            if report:
                                await self._send(ws, {
                                    "type": "devfee_report",
                                    "miners": report,
                                })
                            self._last_devfee_report = now

                    if self._turbo_engine and self._turbo_engine.enabled:
                        now = time.time()
                        if now - self._last_turbo_report >= 60:
                            turbo_report = self._turbo_engine.get_report()
                            if turbo_report:
                                await self._send(ws, {
                                    "type": "turbo_report",
                                    "miners": turbo_report,
                                })
                            self._last_turbo_report = now

                    await self._emit_env_report(ws, snapshots)

                elapsed = time.time() - t0
                has_blinking = any(self._blink_state.values())
                active_interval = 2 if has_blinking else interval
                wait = max(0, active_interval - elapsed)
                if wait > 0:
                    await asyncio.sleep(wait)

        except asyncio.CancelledError:
            log.info("Coleta on-demand encerrada")
        except ConnectionClosed:
            log.warning("WebSocket fechou durante coleta")

    @staticmethod
    def _classify_cgminer(cgm_ver: dict) -> str:
        ver_str = json.dumps(cgm_ver).lower()
        if any(k in ver_str for k in ("braiins", "bosminer", "boser", "bos+", "bos_", "braiinos")):
            return "braiins"
        if "vnish" in ver_str:
            return "vnish"
        return "bitmain_stock"

    async def _braiins_probe(self, ip: str) -> bool:
        try:
            import aiohttp
            timeout = aiohttp.ClientTimeout(total=5)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.get(f"http://{ip}/", allow_redirects=True) as r:
                    if r.status in (200, 401, 403):
                        text = (await r.text(errors="replace"))[:3000].lower()
                        return "braiins" in text or "bosminer" in text or "bos+" in text
        except Exception:
            pass
        return False

    async def _vnish_probe(self, ip: str) -> bool:
        try:
            import aiohttp
            timeout = aiohttp.ClientTimeout(total=6)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.get(f"http://{ip}/api/v1/info") as r:
                    if r.status != 200:
                        return False
                    ct = r.headers.get("content-type", "")
                    if "html" in ct:
                        return False
                    try:
                        data = await r.json(content_type=None)
                        return isinstance(data, dict)
                    except Exception:
                        return False
        except Exception:
            pass
        try:
            import aiohttp
            timeout = aiohttp.ClientTimeout(total=5)
            async with aiohttp.ClientSession(timeout=timeout) as s:
                async with s.get(f"http://{ip}/api/v1/status") as r:
                    if r.status == 200:
                        ct = r.headers.get("content-type", "")
                        if "json" in ct or "html" not in ct:
                            return True
        except Exception:
            pass
        return False

    async def _detect_firmware(self, miner, force_redetect: bool = False) -> str:
        cached = self._firmware_cache.get(miner.ip)
        if cached and cached != "bitmain_stock" and not force_redetect:
            return cached

        cgm_task = asyncio.ensure_future(cgminer_send(miner.ip, 4028, "version", timeout=3))
        vnish_task = asyncio.ensure_future(self._vnish_probe(miner.ip))
        braiins_task = asyncio.ensure_future(self._braiins_probe(miner.ip))
        wm_cfg = WhatsminerConfig(ip=miner.ip, password=miner.password)
        wm_task = asyncio.ensure_future(self._wm_client.send(wm_cfg, "summary"))

        cgm, is_vnish, is_braiins, wm = await asyncio.gather(cgm_task, vnish_task, braiins_task, wm_task)

        wm_ok = bool(wm and isinstance(wm, dict) and wm.get("SUMMARY"))
        reachable = (cgm is not None) or bool(is_vnish) or bool(is_braiins) or wm_ok

        if is_vnish:
            fw = "vnish"
        elif wm_ok:
            fw = "whatsminer"
        elif cgm is not None:
            s_list = cgm.get("STATUS", [])
            s0 = s_list[0] if s_list and isinstance(s_list[0], dict) else {}
            desc = s0.get("Description", "").lower()
            if "microbt" in desc or "whatsminer" in desc:
                fw = "whatsminer"
            elif "braiins" in desc or "bosminer" in desc or "boser" in desc:
                fw = "braiins"
            else:
                fw = self._classify_cgminer(cgm)
        elif is_braiins:
            fw = "braiins"
        else:
            fw = "bitmain_stock"

        if cgm is not None:
            ver_list = cgm.get("VERSION", [])
            ver = ver_list[0] if ver_list else {}
            cgm_model = ver.get("Type") or ver.get("Model")
            if cgm_model and miner.ip not in self._cgminer_model_cache:
                self._cgminer_model_cache[miner.ip] = cgm_model

        # Re-deteccao forcada: se a maquina esta inalcancavel agora (todas as probes
        # falharam = provavel offline temporario), NAO troca o firmware — evita falso
        # positivo / flapping. So troca quando uma probe identifica positivamente.
        if force_redetect and not reachable and cached:
            return cached
        if cached != fw:
            self._firmware_cache[miner.ip] = fw
            self._pending_firmware_reports[miner.ip] = fw
            if cached and cached != fw:
                log.info(f"[{miner.ip}] firmware MUDOU: {cached} -> {fw} (re-detectado)")
            else:
                log.info(f"[{miner.ip}] firmware detectado: {fw}")
        return fw

    def _ensure_power_w(self, kpis):
        """Garante power_w em TODA maquina (real quando o firmware reporta, senao
        estima) para o consumo/custo de energia contabilizar a frota inteira."""
        try:
            p = kpis.get("power_w")
            if p and float(p) > 0:
                return
        except (TypeError, ValueError):
            pass
        est = 0.0
        # 1) preset nomeado em watts (vnish/whatsminer: '3320', '3500 watt ~ 122 TH')
        try:
            est = float(_parse_wattage(kpis.get("current_preset") or ""))
        except (TypeError, ValueError):
            est = 0.0
        # 2) eficiencia (W/TH) reportada x hashrate atual
        if est <= 0:
            try:
                eff = float(kpis.get("efficiency_w_th") or 0)
                hr = float(kpis.get("hr_realtime_ths") or 0)
                if eff > 0 and hr > 0:
                    est = eff * hr
            except (TypeError, ValueError):
                pass
        # 3) ultimo recurso: hashrate (atual ou stock) x eficiencia tipica (~30 W/TH)
        if est <= 0:
            try:
                hr = float(kpis.get("hr_realtime_ths") or kpis.get("hr_stock_ths") or 0)
                if hr > 0:
                    est = hr * 30.0
            except (TypeError, ValueError):
                pass
        if est > 0:
            kpis["power_w"] = int(round(est))
            kpis["power_w_estimated"] = True

    async def _braiins_power(self, miner):
        """Consumo (W) de uma braiins via REST, com cache de 40s (e ate 5min se a
        leitura falhar). O poller cgminer nao traz potencia para BraiinsOS."""
        ip = miner.ip
        now = time.time()
        cached = self._braiins_power_cache.get(ip)
        if cached and now - cached[0] < 40:
            return cached[1]
        pw = await braiins_turbo.read_power_w(ip, miner.user, miner.password)
        if pw is not None:
            self._braiins_power_cache[ip] = (now, pw)
            return pw
        if cached and now - cached[0] < 300:
            return cached[1]
        return None

    async def _braiins_locate(self, miner) -> bool:
        """Estado REAL do LED locate de uma braiins (cache 20s). Detecta blink
        ligado manualmente na maquina e sobrevive a restart do agente.
        Fallback: ultimo comando enviado (_blink_state)."""
        ip = miner.ip
        now = time.time()
        cached = self._braiins_locate_cache.get(ip)
        if cached and now - cached[0] < 20:
            return cached[1]
        actual = await braiins_turbo.read_locate(ip, miner.user, miner.password)
        if actual is not None:
            self._braiins_locate_cache[ip] = (now, actual)
            if not actual:
                self._blink_state[ip] = False
            return actual
        if cached and now - cached[0] < 300:
            return cached[1]
        return bool(self._blink_state.get(ip, False))

    async def _poll_one_miner(self, miner) -> dict:
        fw = None
        try:
            # Maquina que ja falhou varios polls seguidos pode ter trocado de firmware
            # (ex: Vnish -> BraiinsOS). Forca uma re-deteccao (rate-limited: 1x a cada
            # 3 falhas) — so troca se outro firmware for identificado positivamente.
            force_rd = self._poll_fail_count.get(miner.ip, 0) >= 3
            if force_rd:
                self._poll_fail_count[miner.ip] = 0
            fw = await self._detect_firmware(miner, force_redetect=force_rd)

            if fw == "whatsminer":
                wm_cfg = WhatsminerConfig(ip=miner.ip, password=miner.password)
                raw  = await self._wm_poller.poll(wm_cfg)
                kpis = self._wm_poller.extract_kpis(raw)
            elif fw in ("bitmain_stock", "braiins"):
                raw  = await self._bm_poller.poll(miner.ip)
                kpis = self._bm_poller.extract_kpis(raw)
                if fw == "braiins" and not kpis.get("power_w"):
                    pw = await self._braiins_power(miner)
                    if pw is not None:
                        kpis["power_w"] = pw
            else:
                mc = MinerConfig(
                    ip=miner.ip,
                    port=miner.port,
                    user=miner.user,
                    password=miner.password,
                    api_key=miner.api_key,
                )
                raw  = await self._poller.poll(mc)
                kpis = self._poller.extract_kpis(raw)

            kpis["label"]          = miner.label or miner.ip
            kpis["firmware"]       = fw
            if fw == "vnish" and miner.ip in self._cgminer_model_cache:
                kpis["model"] = self._cgminer_model_cache[miner.ip]
            kpis["preset_day_w"]   = miner.preset_day_w
            kpis["preset_night_w"] = miner.preset_night_w
            kpis["alarms"] = self._poller._check_alarms(
                kpis, temp_warn=self.cfg.collector.temp_warn
            )
            if fw == "vnish":
                kpis["find_miner"] = bool(kpis.get("find_miner", False))
            elif fw == "bitmain_stock":
                # Le estado real do LED no Antminer Stock — refletindo na UI
                from .bitmain import query_blink_status
                actual = await query_blink_status(
                    miner.ip, miner.user or "root", miner.password or "root",
                )
                if actual is None:
                    kpis["find_miner"] = bool(self._blink_state.get(miner.ip, False))
                else:
                    kpis["find_miner"] = actual
                    self._blink_state[miner.ip] = actual
            elif fw == "braiins":
                # Le estado REAL do LED (detecta blink manual + restart do agente)
                kpis["find_miner"] = await self._braiins_locate(miner)
            else:
                kpis["find_miner"] = bool(self._blink_state.get(miner.ip, False))
            self._ensure_power_w(kpis)
            if kpis.get("status") != "offline":
                self._poll_fail_count[miner.ip] = 0
            else:
                self._poll_fail_count[miner.ip] = self._poll_fail_count.get(miner.ip, 0) + 1
            return kpis
        except Exception as e:
            log.debug(f"[{miner.ip}] poll erro: {e}")
            self._poll_fail_count[miner.ip] = self._poll_fail_count.get(miner.ip, 0) + 1
            return {
                "ip": miner.ip,
                "ts": int(time.time()),
                "status": "offline",
                "label": miner.label or miner.ip,
                "firmware": self._firmware_cache.get(miner.ip) or fw,
                "alarms": ["offline"],
            }

    async def _poll_all(self, sem: asyncio.Semaphore) -> list[dict]:
        """Coleta todos os mineradores em paralelo com semáforo."""
        async def poll_one(miner):
            async with sem:
                return await self._poll_one_miner(miner)

        results = await asyncio.gather(*[poll_one(m) for m in self.cfg.miners])
        return list(results)

    async def _poll_all_streaming(self, ws, sem: asyncio.Semaphore) -> list[dict]:
        """Coleta paralela com streaming: envia parciais ao browser conforme miners respondem.
        Usado na primeira coleta de uma sessao para o usuario ver maquinas ligando rapido."""
        async def poll_one(miner):
            async with sem:
                return await self._poll_one_miner(miner)

        coros = [poll_one(m) for m in self.cfg.miners]
        all_snaps: list[dict] = []
        pending: list[dict] = []
        last_flush = time.time()

        for fut in asyncio.as_completed(coros):
            try:
                snap = await fut
            except Exception as e:
                log.debug(f"poll erro: {e}")
                continue
            if not snap:
                continue
            ip = snap.get("ip", "")
            if ip in self._known_presets and not snap.get("current_preset"):
                snap["current_preset"] = self._known_presets[ip]
            all_snaps.append(snap)
            pending.append(snap)
            now = time.time()
            if (now - last_flush) >= 0.6 or len(pending) >= 4:
                ts_now = int(now)
                for sid in list(self._active_sessions):
                    await self._send(ws, {
                        "type": "data",
                        "session_id": sid,
                        "ts": ts_now,
                        "snapshots": pending,
                    })
                pending = []
                last_flush = now

        if pending:
            ts_now = int(time.time())
            for sid in list(self._active_sessions):
                await self._send(ws, {
                    "type": "data",
                    "session_id": sid,
                    "ts": ts_now,
                    "snapshots": pending,
                })

        return all_snaps

    async def _refresh_miner_snapshot(self, ws, ip: str, delay: float = 4.0):
        try:
            await asyncio.sleep(delay)
            miner = next((m for m in self.cfg.miners if m.ip == ip), None)
            if not miner:
                return
            kpis = await self._poll_one_miner(miner)
            if not kpis:
                return
            ts = int(time.time())
            for session_id in list(self._active_sessions):
                await self._send(ws, {
                    "type": "data",
                    "session_id": session_id,
                    "ts": ts,
                    "snapshots": [kpis],
                })
            log.info(f"[{ip}] snapshot refresh enviado pos set_pools")
        except Exception as e:
            log.debug(f"[{ip}] refresh snapshot erro: {e}")

    # ─── Helpers ───────────────────────────────────────────────────────────

    async def _send(self, ws, payload: dict):
        try:
            await ws.send(json.dumps(payload))
        except ConnectionClosed:
            log.debug("Tentou enviar em conexão fechada")
        except Exception as e:
            log.debug(f"Erro ao enviar: {e}")
