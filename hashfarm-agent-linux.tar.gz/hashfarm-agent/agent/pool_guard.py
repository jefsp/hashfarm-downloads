import asyncio
import json
import logging
import os
import time
from pathlib import Path

log = logging.getLogger("hashfarm.pool_guard")


def _flag(name: str) -> bool:
    return os.environ.get(name, "0").strip().lower() in ("1", "true", "yes", "on")


_RESTORE_COOLDOWN = 180


def _is_devfee(p: dict) -> bool:
    return str(p.get("pool_type", "UserPool")).lower() in ("devfee", "refund")


def _valid_worker(user: str) -> bool:
    u = (user or "").strip()
    return bool(u) and "." in u


class PoolGuard:
    def __init__(self, store_path: str | None = None):
        self.enabled = _flag("POOL_GUARD_ENABLED")
        self.dry_run = _flag("POOL_GUARD_DRYRUN")
        self.path = Path(store_path or os.environ.get("POOL_GUARD_FILE", "pool_guard.json"))
        self._mem: dict[str, dict] = {}
        self._last_restore: dict[str, float] = {}
        self._load()
        if self.enabled:
            log.info(f"PoolGuard ATIVO (dry_run={self.dry_run}) store={self.path} conhecidas={len(self._mem)}")

    def _load(self):
        try:
            if self.path.exists():
                self._mem = json.loads(self.path.read_text())
        except Exception as e:
            log.warning(f"PoolGuard load falhou: {e}")
            self._mem = {}

    def _save(self):
        try:
            self.path.write_text(json.dumps(self._mem))
        except Exception as e:
            log.warning(f"PoolGuard save falhou: {e}")

    @staticmethod
    def _user_pools(pools) -> list[dict]:
        out = []
        for p in (pools or []):
            if _is_devfee(p):
                continue
            url = (p.get("url") or "").strip()
            user = (p.get("user") or "").strip()
            if url and user:
                out.append({"url": url, "user": user, "pass": (p.get("pass") or p.get("password") or "x")})
        return out

    async def observe(self, ip, firmware, pools, pool_manager, miner_kw_fn):
        if not self.enabled:
            return
        try:
            ups = self._user_pools(pools)
            if ups:
                good = [p for p in ups if _valid_worker(p["user"])]
                if good and self._mem.get(ip, {}).get("pools") != good:
                    self._mem[ip] = {"pools": good, "fw": firmware, "ts": int(time.time())}
                    self._save()
                    log.info(f"[{ip}] PoolGuard aprendeu/atualizou pool ({len(good)}) worker={good[0]['user']}")
                return

            saved = self._mem.get(ip, {}).get("pools")
            if not saved:
                return
            now = time.time()
            if now - self._last_restore.get(ip, 0) < _RESTORE_COOLDOWN:
                return
            self._last_restore[ip] = now
            worker = saved[0]["user"]
            if self.dry_run:
                log.warning(f"[{ip}] PoolGuard DRY-RUN: restauraria pool (fw={firmware}) worker={worker}")
                return
            log.warning(f"[{ip}] PoolGuard: SEM pool -> restaurando (fw={firmware}) worker={worker}")
            ok = await pool_manager.restore_pools(ip, firmware, saved, **miner_kw_fn(ip))
            log.warning(f"[{ip}] PoolGuard restore_pools -> {ok}")
        except Exception as e:
            log.debug(f"[{ip}] PoolGuard observe erro: {e}")
