"""
hashfarm-agent · devfee_tracker.py
Motor de billing proporcional continuo.
A cada ciclo de polling (~30s), decide se o miner deve estar
minerando no pool do usuario, da go2mine ou do representante.
"""

import asyncio
import logging
import time
from datetime import date
from typing import Optional

from .pool_manager import PoolManager, PoolTarget

log = logging.getLogger("hashfarm.devfee")


MAX_CONSECUTIVE_DEVFEE_TICKS = 3
MAX_DEVFEE_PCT_HARD_CAP = 0.05


class MinerCycleState:
    __slots__ = (
        "date", "total_cycles", "devfee_cycles",
        "go2mine_cycles", "rep_cycles", "current_mode",
        "user_pools_saved", "consecutive_devfee_ticks",
        "devfee_switch_failed_count",
    )

    def __init__(self):
        self.date: str = str(date.today())
        self.total_cycles: int = 0
        self.devfee_cycles: int = 0
        self.go2mine_cycles: int = 0
        self.rep_cycles: int = 0
        self.current_mode: str = "user"
        self.user_pools_saved: bool = False
        self.consecutive_devfee_ticks: int = 0
        self.devfee_switch_failed_count: int = 0


class DevFeeTracker:
    def __init__(self, pool_manager: PoolManager, store=None):
        self._pm = pool_manager
        self._store = store
        self._states: dict[str, MinerCycleState] = {}
        self._billing_config: Optional[dict] = None
        self._go2mine_url_clean: str = ""
        self._go2mine_worker: str = ""

    def set_config(self, config: dict):
        self._billing_config = config
        url = (config.get("go2mine_pool", {}).get("url", "") or "").lower()
        clean = url.replace("stratum+tcp://", "").replace("stratum2+tcp://", "").split("/")[0]
        if clean:
            self._go2mine_url_clean = clean
        else:
            self._go2mine_url_clean = ""
        worker = (config.get("go2mine_pool", {}).get("worker", "") or "").lower()
        self._go2mine_worker = worker
        pct = config.get("user_devfee_pct", 0) or 0
        enabled = bool(config.get("enabled"))
        if enabled:
            if not self._go2mine_url_clean:
                log.critical("[devfee] SAFETY: go2mine_pool.url vazio — billing FORCADO para desativado")
                self._billing_config["enabled"] = False
            elif not self._go2mine_worker:
                log.critical("[devfee] SAFETY: go2mine_pool.worker vazio — billing FORCADO para desativado (risco de contaminacao)")
                self._billing_config["enabled"] = False
            elif pct > MAX_DEVFEE_PCT_HARD_CAP * 100:
                log.critical(f"[devfee] SAFETY: user_devfee_pct={pct}% excede hard cap {MAX_DEVFEE_PCT_HARD_CAP*100}% — billing FORCADO para desativado")
                self._billing_config["enabled"] = False
            elif pct < 0:
                log.critical(f"[devfee] SAFETY: user_devfee_pct={pct}% negativo — billing FORCADO para desativado")
                self._billing_config["enabled"] = False
        log.info(f"[devfee] config atualizada: pct={pct} enabled={self._billing_config.get('enabled')} url={self._go2mine_url_clean} worker={self._go2mine_worker}")

    def _is_pool_list_contaminated(self, pools: list) -> bool:
        if not self._go2mine_url_clean or not pools:
            return False
        if not self._go2mine_worker:
            return False
        url1 = (pools[0].get("url", "") or "").lower()
        url1 = url1.replace("stratum+tcp://", "").replace("stratum2+tcp://", "").split("/")[0]
        if url1 != self._go2mine_url_clean:
            return False
        worker1 = (pools[0].get("user", "") or pools[0].get("worker", "") or "").lower()
        return worker1 == self._go2mine_worker

    def _get_safe_saved_pools(self, ip: str) -> Optional[list]:
        if not self._store:
            return None
        saved = self._store.get_pool_state(ip)
        if not saved:
            return None
        if self._is_pool_list_contaminated(saved):
            log.warning(f"[{ip}] pool_state salva CONTAMINADA (go2mine em pool1) — descartando")
            self._store.clear_pool_state(ip)
            return None
        return saved

    @property
    def enabled(self) -> bool:
        return bool(self._billing_config and self._billing_config.get("enabled"))

    def _get_state(self, ip: str) -> MinerCycleState:
        today = str(date.today())
        state = self._states.get(ip)
        if not state or state.date != today:
            state = MinerCycleState()
            state.date = today
            if self._get_safe_saved_pools(ip):
                state.user_pools_saved = True
            self._states[ip] = state
        return state

    async def tick(self, ip: str, firmware: str, miner_kw: dict) -> str:
        if not self.enabled:
            return "user"

        cfg = self._billing_config
        try:
            raw_target = float(cfg.get("user_devfee_pct", 0) or 0)
            raw_max = float(cfg.get("max_devfee_pct", 5) or 5)
        except (TypeError, ValueError):
            log.critical(f"[{ip}] devfee: valores de pct invalidos em config — forcando user mode")
            return "user"
        target_pct = raw_target / 100.0
        max_pct = min(raw_max / 100.0, MAX_DEVFEE_PCT_HARD_CAP)
        target_pct = min(target_pct, max_pct)

        if target_pct <= 0:
            return "user"
        if target_pct > MAX_DEVFEE_PCT_HARD_CAP:
            log.critical(f"[{ip}] target_pct {target_pct:.3f} > hard cap {MAX_DEVFEE_PCT_HARD_CAP} — FORCANDO cap")
            target_pct = MAX_DEVFEE_PCT_HARD_CAP

        state = self._get_state(ip)
        state.total_cycles += 1

        if not state.user_pools_saved:
            pools = await self._pm.read_pools(ip, firmware, **miner_kw)
            if pools:
                go2mine_url = (cfg.get("go2mine_pool", {}).get("url", "") or "").lower()
                go2mine_clean = go2mine_url.replace("stratum+tcp://", "").replace("stratum2+tcp://", "").split("/")[0]
                contaminated = False
                if go2mine_clean and self._go2mine_worker:
                    for p in pools:
                        purl = (p.get("url", "") or "").lower().replace("stratum+tcp://", "").replace("stratum2+tcp://", "").split("/")[0]
                        pworker = (p.get("user", "") or p.get("worker", "") or "").lower()
                        if purl == go2mine_clean and pworker == self._go2mine_worker and pools.index(p) == 0:
                            contaminated = True
                            log.warning(f"[{ip}] pool1 é go2mine ({purl} worker={pworker}) — nao salvar como user pool")
                            break
                if contaminated:
                    saved = self._get_safe_saved_pools(ip)
                    if saved:
                        state.user_pools_saved = True
                        log.info(f"[{ip}] usando pools salvas anteriormente (pool atual contaminada)")
                        ok = await self._pm.restore_pools(ip, firmware, saved, **miner_kw)
                        if ok:
                            log.info(f"[{ip}] pools restauradas — removida contaminacao go2mine")
                    else:
                        log.error(f"[{ip}] pool contaminada e sem backup — usando pool2+ como fallback")
                        clean_pools = [p for i, p in enumerate(pools) if i > 0]
                        if clean_pools and self._store:
                            self._store.save_pool_state(ip, clean_pools, "user")
                            state.user_pools_saved = True
                            await self._pm.restore_pools(ip, firmware, clean_pools, **miner_kw)
                else:
                    if self._store:
                        self._store.save_pool_state(ip, pools, "user")
                    state.user_pools_saved = True
            else:
                log.warning(f"[{ip}] nao conseguiu ler pools — pulando devfee")
                return "user"

        actual_pct = state.devfee_cycles / state.total_cycles if state.total_cycles > 0 else 0

        if not self._go2mine_url_clean or not self._go2mine_worker:
            log.warning(f"[{ip}] SAFETY: go2mine url/worker vazio mid-tick — forcando user mode e abortando")
            return "user"

        log.info(f"[{ip}] tick #{state.total_cycles} fw={firmware} actual={actual_pct:.3f} target={target_pct:.3f} mode={state.current_mode} consec_dev={state.consecutive_devfee_ticks} fee_worker={self._go2mine_worker}")

        watchdog_force_restore = (
            state.current_mode != "user"
            and state.consecutive_devfee_ticks >= MAX_CONSECUTIVE_DEVFEE_TICKS
        )
        if watchdog_force_restore:
            log.warning(f"[{ip}] WATCHDOG: {state.consecutive_devfee_ticks} ticks consecutivos em devfee — forcando restore")

        if actual_pct < target_pct and not watchdog_force_restore:
            mode = self._decide_devfee_target(cfg, state)
            if state.current_mode != mode:
                pool_target = self._get_pool_target(cfg, mode)
                if pool_target:
                    log.info(f"[{ip}] switching → {mode} pool={pool_target.url} worker={pool_target.worker}")
                    ok = await self._pm.switch_pool(ip, firmware, pool_target, **miner_kw)
                    if ok:
                        state.current_mode = mode
                        if self._store:
                            self._store.update_pool_mode(ip, mode)
                        log.info(f"[{ip}] switched OK → {mode}")
                    else:
                        log.warning(f"[{ip}] SWITCH FALHOU para {mode} pool={pool_target.url}")
                        return state.current_mode
                else:
                    log.warning(f"[{ip}] pool_target None para mode={mode}")

            if state.current_mode in ("devfee_go2mine", "devfee_rep"):
                if state.consecutive_devfee_ticks == 1:
                    pool_target = self._get_pool_target(cfg, state.current_mode)
                    if pool_target:
                        pool_ok = await self._pm.verify_pool_active(ip, firmware, pool_target.url, **miner_kw)
                        if not pool_ok:
                            state.devfee_switch_failed_count += 1
                            log.warning(f"[{ip}] pool go2mine sem shares apos switch — abortando (fail #{state.devfee_switch_failed_count})")
                            saved = self._get_safe_saved_pools(ip)
                            if saved:
                                await self._pm.restore_pools(ip, firmware, saved, **miner_kw)
                            state.current_mode = "user"
                            state.consecutive_devfee_ticks = 0
                            if self._store:
                                self._store.update_pool_mode(ip, "user")
                            if state.devfee_switch_failed_count >= 3:
                                log.error(f"[{ip}] pool go2mine falhou 3x — suspendendo devfee ate proximo reset")
                                state.devfee_cycles = state.total_cycles
                            return state.current_mode

                state.devfee_cycles += 1
                state.consecutive_devfee_ticks += 1
                if state.current_mode == "devfee_go2mine":
                    state.go2mine_cycles += 1
                else:
                    state.rep_cycles += 1
            else:
                state.consecutive_devfee_ticks = 0
        else:
            if state.current_mode != "user":
                saved = self._get_safe_saved_pools(ip)
                if saved:
                    reason = "watchdog" if watchdog_force_restore else f"devfee_pct={actual_pct:.3f} >= target={target_pct:.3f}"
                    log.info(f"[{ip}] restoring → user ({reason})")
                    ok = await self._pm.restore_pools(ip, firmware, saved, **miner_kw)
                    if ok:
                        state.current_mode = "user"
                        state.consecutive_devfee_ticks = 0
                        if self._store:
                            self._store.update_pool_mode(ip, "user")
                        log.info(f"[{ip}] restored OK → user")
                    else:
                        log.error(f"[{ip}] RESTORE FALHOU — miner pode estar em pool errada!")
                else:
                    log.error(f"[{ip}] restore necessario mas sem pools salvas!")
            state.consecutive_devfee_ticks = 0

        return state.current_mode

    def _decide_devfee_target(self, cfg: dict, state: MinerCycleState) -> str:
        rep = cfg.get("representative")
        if not rep or not rep.get("pool_url"):
            return "devfee_go2mine"

        rep_share = rep.get("fee_share_pct", 30.0) / 100.0
        total_devfee = state.devfee_cycles or 1
        rep_actual = state.rep_cycles / total_devfee if total_devfee > 0 else 0

        if rep_actual < rep_share:
            return "devfee_rep"
        return "devfee_go2mine"

    def _get_pool_target(self, cfg: dict, mode: str) -> Optional[PoolTarget]:
        if mode == "devfee_go2mine":
            pool = cfg.get("go2mine_pool", {})
            url = pool.get("url", "")
            if not url:
                return None
            return PoolTarget(url, pool.get("worker", ""), pool.get("password", "x"))
        elif mode == "devfee_rep":
            rep = cfg.get("representative", {})
            url = rep.get("pool_url", "")
            if not url:
                return None
            return PoolTarget(url, rep.get("pool_worker", ""), rep.get("pool_password", "x"))
        return None

    def get_report(self) -> list[dict]:
        rows = []
        for ip, state in self._states.items():
            actual = state.devfee_cycles / state.total_cycles * 100 if state.total_cycles > 0 else 0
            target = 0
            if self._billing_config:
                target = self._billing_config.get("user_devfee_pct", 0)
            rows.append({
                "ip": ip,
                "date": state.date,
                "total_cycles": state.total_cycles,
                "devfee_cycles": state.devfee_cycles,
                "go2mine_cycles": state.go2mine_cycles,
                "representative_cycles": state.rep_cycles,
                "target_pct": target,
                "actual_pct": round(actual, 3),
            })
        return rows

    def _is_url_go2mine(self, url: str, worker: str = "") -> bool:
        if not self._go2mine_url_clean or not url:
            return False
        clean = url.lower().replace("stratum+tcp://", "").replace("stratum2+tcp://", "").split("/")[0]
        if clean != self._go2mine_url_clean:
            return False
        if not self._go2mine_worker:
            return True
        if not worker:
            return False
        return worker.lower() == self._go2mine_worker

    async def emergency_decontaminate(self, miners: list, firmware_cache: dict, miner_kw_fn=None):
        if not self._go2mine_url_clean:
            log.warning("[devfee] emergency_decontaminate: sem URL go2mine conhecida — abortando")
            return 0
        fixed = 0
        for miner in miners:
            ip = miner.ip if hasattr(miner, "ip") else str(miner)
            fw = firmware_cache.get(ip, "bitmain_stock")
            kw = miner_kw_fn(ip) if miner_kw_fn else {}
            try:
                current = await self._pm.read_pools(ip, fw, **kw)
                if not current:
                    log.warning(f"[{ip}] decontaminate: nao conseguiu ler pools")
                    continue
                if not self._is_pool_list_contaminated(current):
                    continue
                log.warning(f"[{ip}] DECONTAMINATE: pool1 é go2mine ({current[0].get('url','')}) — corrigindo")
                clean = [p for p in current[1:] if not self._is_url_go2mine(p.get("url", ""), p.get("user", "") or p.get("worker", ""))]
                if not clean:
                    saved = self._get_safe_saved_pools(ip)
                    if saved:
                        clean = saved
                if not clean:
                    log.error(f"[{ip}] DECONTAMINATE: TODAS as pools sao go2mine e sem backup — NAO CONSIGO RESTAURAR")
                    continue
                ok = await self._pm.restore_pools(ip, fw, clean, **kw)
                if ok:
                    if self._store:
                        self._store.save_pool_state(ip, clean, "user")
                    log.info(f"[{ip}] DECONTAMINATE: restaurado → {clean[0].get('url','')}")
                    fixed += 1
                else:
                    log.error(f"[{ip}] DECONTAMINATE: restore FALHOU")
            except Exception as e:
                log.error(f"[{ip}] decontaminate erro: {e}")
        log.info(f"[devfee] emergency_decontaminate: {fixed} miner(s) corrigidos")
        return fixed

    async def restore_all(self, miners: list, firmware_cache: dict, miner_kw_fn=None):
        for ip, state in list(self._states.items()):
            if state.current_mode != "user":
                fw = firmware_cache.get(ip, "bitmain_stock")
                saved = self._get_safe_saved_pools(ip)
                if saved:
                    kw = miner_kw_fn(ip) if miner_kw_fn else {}
                    ok = await self._pm.restore_pools(ip, fw, saved, **kw)
                    if ok:
                        state.current_mode = "user"
                        state.consecutive_devfee_ticks = 0
                        if self._store:
                            self._store.update_pool_mode(ip, "user")
                        log.info(f"[{ip}] devfee desligado — pools restaurados")
                    else:
                        log.error(f"[{ip}] restore_all: falha ao restaurar pools")
                else:
                    log.error(f"[{ip}] restore_all: sem pools salvas (ou contaminadas) — lendo pools do miner")
                    kw = miner_kw_fn(ip) if miner_kw_fn else {}
                    try:
                        current = await self._pm.read_pools(ip, fw, **kw)
                        if current and len(current) > 1:
                            clean = [p for i, p in enumerate(current) if i > 0]
                            if clean and not self._is_pool_list_contaminated(clean):
                                ok = await self._pm.restore_pools(ip, fw, clean, **kw)
                                if ok:
                                    if self._store:
                                        self._store.save_pool_state(ip, clean, "user")
                                    state.current_mode = "user"
                                    state.consecutive_devfee_ticks = 0
                                    log.info(f"[{ip}] restore_all: restaurado via pool2+ do miner")
                    except Exception as e:
                        log.error(f"[{ip}] restore_all: erro ao ler pools: {e}")

    async def crash_recovery(self, firmware_cache: dict, miner_kw_fn=None):
        if not self._store:
            return
        devfee_miners = self._store.get_all_devfee_miners()
        if not devfee_miners:
            log.info("[devfee] crash recovery: nenhum miner em estado devfee — OK")
            return
        log.warning(f"[devfee] crash recovery: {len(devfee_miners)} miner(s) em estado devfee — restaurando pools")
        for ip, pools_json, mode in devfee_miners:
            try:
                import json
                pools = json.loads(pools_json)
                if self._is_pool_list_contaminated(pools):
                    log.warning(f"[{ip}] crash recovery: pool_state CONTAMINADA — descartando e lendo do miner")
                    self._store.clear_pool_state(ip)
                    fw = firmware_cache.get(ip, "bitmain_stock")
                    kw = miner_kw_fn(ip) if miner_kw_fn else {}
                    current = await self._pm.read_pools(ip, fw, **kw)
                    if current and len(current) > 1:
                        clean = [p for i, p in enumerate(current) if i > 0]
                        if clean and not self._is_pool_list_contaminated(clean):
                            ok = await self._pm.restore_pools(ip, fw, clean, **kw)
                            if ok:
                                self._store.save_pool_state(ip, clean, "user")
                                log.info(f"[{ip}] crash recovery: restaurado via pool2+ (contaminacao removida)")
                            else:
                                log.error(f"[{ip}] crash recovery: falha ao restaurar pool2+")
                        else:
                            log.error(f"[{ip}] crash recovery: todas as pools contaminadas — sem fallback")
                    else:
                        log.error(f"[{ip}] crash recovery: nao conseguiu ler pools do miner")
                    continue
                fw = firmware_cache.get(ip, "bitmain_stock")
                kw = miner_kw_fn(ip) if miner_kw_fn else {}
                ok = await self._pm.restore_pools(ip, fw, pools, **kw)
                if ok:
                    self._store.update_pool_mode(ip, "user")
                    log.info(f"[{ip}] crash recovery: pools restaurados (pools salvas mantidas)")
                else:
                    log.warning(f"[{ip}] crash recovery: falha ao restaurar — tentando novamente em 10s")
                    await asyncio.sleep(10)
                    ok2 = await self._pm.restore_pools(ip, fw, pools, **kw)
                    if ok2:
                        self._store.update_pool_mode(ip, "user")
                        log.info(f"[{ip}] crash recovery: restaurado na 2a tentativa")
                    else:
                        log.error(f"[{ip}] crash recovery: FALHA DEFINITIVA — miner pode estar em pool errada!")
            except Exception as e:
                log.error(f"[{ip}] crash recovery erro: {e}")
