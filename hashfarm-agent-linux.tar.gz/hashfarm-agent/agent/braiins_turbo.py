"""
hashfarm-agent · braiins_turbo.py
TURBO para firmware BraiinsOS+ — delega a malha fechada ao autotuner NATIVO
(baseado em alvo de potencia) + DPS, espelhando a estrategia do Vnish.

BraiinsOS nao tem presets nomeados: o autotuner persegue um alvo de potencia (W)
ajustando freq/voltagem dentro dos limites de fabrica (constraints). O DPS
(Dynamic Performance Scaling) faz o recuo automatico por temperatura — equivalente
ao preset_switcher do Vnish.

Fluxo (por miner, ao habilitar TURBO ou trocar de perfil):
  1. login   POST /api/v1/auth/login -> token (header Authorization: <token>, SEM "Bearer")
  2. le      GET /api/v1/configuration/constraints   -> power_target.{default,min,max}.watt
             GET /api/v1/performance/mode            -> alvo atual (snapshot p/ restore)
  3. plano   target_w = clamp(stock_w * (1 + margem_do_perfil), min_w, max_w)
  4. aplica  PUT /api/v1/performance/power-target {watt}
             PUT /api/v1/performance/dps {enable:true, enable_shutdown:false}

Seguranca: DRY-RUN por padrao (so leituras + log do plano, nada e aplicado).
Para aplicar de verdade, definir env BRAIINS_TURBO_LIVE=1 no agente da farm.
"""

import os
import json
import logging
from typing import Optional, Tuple

log = logging.getLogger("hashfarm.braiins_turbo")

PROFILES = {
    "conservador": {"margin": 0.03, "dps": True},
    "normal":      {"margin": 0.06, "dps": True},
    "arrojado":    {"margin": 0.09, "dps": True},
}

HARD_MARGIN_CAP = 0.12
HTTP_TIMEOUT_S = 12


def is_live() -> bool:
    return os.environ.get("BRAIINS_TURBO_LIVE", "").strip().lower() in ("1", "true", "yes", "on")


def _short(obj) -> str:
    try:
        return json.dumps(obj, default=str)[:400]
    except Exception:
        return str(obj)[:400]


def power_bounds(constraints: Optional[dict]) -> Tuple[Optional[int], Optional[int], Optional[int]]:
    tc = (constraints or {}).get("tuner_constraints") or {}
    pt = tc.get("power_target") or {}

    def w(node):
        v = pt.get(node)
        return v.get("watt") if isinstance(v, dict) else None

    return w("min"), w("max"), w("default")


def current_power_target(mode: Optional[dict]) -> Optional[int]:
    tm = (mode or {}).get("tunermode") or {}
    tgt = tm.get("target") or {}
    ptm = tgt.get("powertarget") or {}
    pw = ptm.get("power_target") or {}
    return pw.get("watt")


def plan_power_target(profile_name: str, stock_w: Optional[int],
                      min_w: Optional[int], max_w: Optional[int]) -> Optional[dict]:
    prof = PROFILES.get(profile_name) or PROFILES["normal"]
    margin = min(prof["margin"], HARD_MARGIN_CAP)
    if not stock_w or stock_w <= 0:
        return None
    target = stock_w * (1 + margin)
    if max_w and max_w > 0:
        target = min(target, max_w)
    if min_w and min_w > 0:
        target = max(target, min_w)
    return {
        "target_w": int(round(target)),
        "stock_w": int(round(stock_w)),
        "margin": margin,
        "dps": bool(prof["dps"]),
    }


async def _login(session, base: str, user: str, pw: str) -> Optional[str]:
    try:
        async with session.post(f"{base}/auth/login", json={"username": user, "password": pw}) as r:
            if r.status == 200:
                data = await r.json(content_type=None)
                return (data or {}).get("token")
            log.warning(f"braiins login status={r.status}")
    except Exception as e:
        log.warning(f"braiins login erro: {e}")
    return None


async def _get(session, base: str, token: Optional[str], path: str):
    headers = {"Authorization": token} if token else {}
    try:
        async with session.get(f"{base}{path}", headers=headers) as r:
            if r.status == 200:
                return await r.json(content_type=None)
            log.debug(f"braiins GET {path} status={r.status}")
    except Exception as e:
        log.debug(f"braiins GET {path} erro: {e}")
    return None


async def _put(session, base: str, token: Optional[str], path: str, body: dict) -> bool:
    headers = {"Authorization": token} if token else {}
    try:
        async with session.put(f"{base}{path}", json=body, headers=headers) as r:
            ok = r.status in (200, 204)
            if not ok:
                txt = (await r.text(errors="replace"))[:150]
                log.warning(f"braiins PUT {path} status={r.status} body={txt}")
            return ok
    except Exception as e:
        log.warning(f"braiins PUT {path} erro: {e}")
        return False


async def apply_profile(ip: str, user: str, pw: str, profile_name: str,
                        dry_run: Optional[bool] = None) -> Tuple[bool, dict]:
    """Le estado, calcula o plano e (em modo live) aplica power-target + DPS.
    Em dry-run apenas loga o que faria. Retorna (ok, detail)."""
    import aiohttp
    if dry_run is None:
        dry_run = not is_live()
    base = f"http://{ip}/api/v1"
    detail: dict = {"profile": profile_name, "dry_run": dry_run}
    timeout = aiohttp.ClientTimeout(total=HTTP_TIMEOUT_S)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as s:
            token = await _login(s, base, user or "root", pw or "")
            if not token:
                detail["error"] = "login_failed"
                return False, detail

            constraints = await _get(s, base, token, "/configuration/constraints")
            mode = await _get(s, base, token, "/performance/mode")
            log.info(f"[{ip}] braiins constraints={_short(constraints)}")
            log.info(f"[{ip}] braiins mode(snapshot)={_short(mode)}")

            min_w, max_w, default_w = power_bounds(constraints)
            stock_w = default_w or current_power_target(mode)
            snapshot_w = current_power_target(mode)
            detail.update({"min_w": min_w, "max_w": max_w,
                           "stock_w_src": stock_w, "snapshot_w": snapshot_w})

            plan = plan_power_target(profile_name, stock_w, min_w, max_w)
            if not plan:
                detail["error"] = f"sem stock_w (constraints={_short(constraints)})"
                return False, detail
            detail.update(plan)

            if dry_run:
                log.info(f"[{ip}] braiins turbo DRY-RUN: APLICARIA power-target={plan['target_w']}W "
                         f"(stock={plan['stock_w']}W margin={plan['margin']:.0%} "
                         f"bounds=[{min_w},{max_w}] snapshot={snapshot_w}W) dps={plan['dps']}")
                detail["action"] = "dry_run"
                return True, detail

            ok_pt = await _put(s, base, token, "/performance/power-target", {"watt": plan["target_w"]})
            detail["power_target_applied"] = ok_pt
            if plan["dps"]:
                detail["dps_applied"] = await _put(
                    s, base, token, "/performance/dps",
                    {"enable": True, "enable_shutdown": False},
                )
            detail["action"] = "applied" if ok_pt else "power_target_failed"
            log.info(f"[{ip}] braiins turbo LIVE: power-target={plan['target_w']}W ok={ok_pt} dps={detail.get('dps_applied')}")
            return bool(ok_pt), detail
    except Exception as e:
        detail["error"] = str(e)
        log.warning(f"[{ip}] braiins turbo apply erro: {e}")
        return False, detail


async def restore_profile(ip: str, user: str, pw: str, snapshot_w: Optional[int],
                          dry_run: Optional[bool] = None) -> Tuple[bool, dict]:
    """Restaura o alvo de potencia pre-TURBO e desliga o DPS.
    Se snapshot_w for None, apenas desliga o DPS."""
    import aiohttp
    if dry_run is None:
        dry_run = not is_live()
    base = f"http://{ip}/api/v1"
    detail: dict = {"dry_run": dry_run, "snapshot_w": snapshot_w}
    if dry_run:
        log.info(f"[{ip}] braiins turbo DRY-RUN restore: APLICARIA power-target={snapshot_w}W + dps off")
        detail["action"] = "dry_run"
        return True, detail
    timeout = aiohttp.ClientTimeout(total=HTTP_TIMEOUT_S)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as s:
            token = await _login(s, base, user or "root", pw or "")
            if not token:
                detail["error"] = "login_failed"
                return False, detail
            await _put(s, base, token, "/performance/dps", {"enable": False})
            ok = True
            if snapshot_w and snapshot_w > 0:
                ok = await _put(s, base, token, "/performance/power-target", {"watt": int(snapshot_w)})
            detail["action"] = "restored" if ok else "restore_failed"
            return bool(ok), detail
    except Exception as e:
        detail["error"] = str(e)
        return False, detail
