"""
hashfarm-agent · store.py · v1.0
Fila offline-first com SQLite.

Dados coletados são gravados localmente antes de enviar para a nuvem.
Se a conexão WebSocket cair, o agente continua coletando e sincroniza
tudo quando reconectar. Leve: SQLite não requer processo separado.
"""

import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Optional

log = logging.getLogger("hashfarm.store")


class LocalStore:
    """
    SQLite store thread-safe via WAL mode.
    Operações síncronas — o collector roda num executor.
    """

    def __init__(self, path: str = "hashfarm.db", max_queue: int = 10_000):
        self.path = Path(path)
        self.max_queue = max_queue
        self._conn = self._connect()
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            self.path,
            check_same_thread=False,  # usamos lock externo / WAL
            timeout=10,
        )
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS snapshots (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                ip      TEXT    NOT NULL,
                ts      INTEGER NOT NULL,
                payload TEXT    NOT NULL,  -- JSON dos KPIs
                sent    INTEGER NOT NULL DEFAULT 0,
                sent_at INTEGER
            );

            CREATE INDEX IF NOT EXISTS idx_snapshots_unsent
                ON snapshots (sent, ts);

            CREATE INDEX IF NOT EXISTS idx_snapshots_ip_ts
                ON snapshots (ip, ts DESC);

            -- Estado de pools para crash recovery do billing
            CREATE TABLE IF NOT EXISTS pool_state (
                ip          TEXT PRIMARY KEY,
                user_pools  TEXT NOT NULL,     -- JSON dos pools originais
                current_mode TEXT NOT NULL DEFAULT 'user',
                saved_at    INTEGER NOT NULL
            );

            -- Comandos recebidos da nuvem que ainda precisam ser executados
            CREATE TABLE IF NOT EXISTS commands (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                cmd_id      TEXT    NOT NULL UNIQUE,  -- ID vindo da nuvem
                ip          TEXT    NOT NULL,
                command     TEXT    NOT NULL,          -- start|stop|restart|reboot
                params      TEXT,                      -- JSON adicional
                received_at INTEGER NOT NULL,
                executed_at INTEGER,
                result      TEXT,                      -- ok | error: mensagem
                status      TEXT    NOT NULL DEFAULT 'pending'
            );

            -- TURBO AI: estado por miner
            CREATE TABLE IF NOT EXISTS turbo_state (
                ip          TEXT PRIMARY KEY,
                preset      TEXT,
                base_preset TEXT,
                safe_ticks  INTEGER DEFAULT 0,
                unsafe_ticks INTEGER DEFAULT 0,
                last_change INTEGER,
                updated_at  INTEGER
            );

            -- TURBO AI: ganhos diarios por miner
            CREATE TABLE IF NOT EXISTS turbo_gains (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                ip             TEXT NOT NULL,
                date           TEXT NOT NULL,
                stock_hr_ths   REAL,
                turbo_hr_ths   REAL,
                stock_power_w  REAL,
                turbo_power_w  REAL,
                ticks_counted  INTEGER DEFAULT 0,
                updated_at     INTEGER,
                UNIQUE(ip, date)
            );

            -- TURBO AI: log de acoes
            CREATE TABLE IF NOT EXISTS turbo_actions (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ip          TEXT NOT NULL,
                ts          INTEGER NOT NULL,
                from_preset TEXT,
                to_preset   TEXT,
                reason      TEXT,
                kpis_json   TEXT
            );
        """)
        self._conn.commit()

    # ─── Snapshots ─────────────────────────────────────────────────────────

    def save_snapshot(self, kpis: dict) -> int:
        """Grava um snapshot de KPIs. Retorna o ID."""
        # Se fila estiver cheia, descarta os mais antigos ainda não enviados
        count = self._conn.execute(
            "SELECT COUNT(*) FROM snapshots WHERE sent=0"
        ).fetchone()[0]

        if count >= self.max_queue:
            drop = count - self.max_queue + 1
            self._conn.execute(
                "DELETE FROM snapshots WHERE sent=0 AND id IN "
                "(SELECT id FROM snapshots WHERE sent=0 ORDER BY ts ASC LIMIT ?)",
                (drop,),
            )
            log.warning(f"Fila cheia — descartados {drop} snapshots antigos")

        cur = self._conn.execute(
            "INSERT INTO snapshots (ip, ts, payload) VALUES (?, ?, ?)",
            (kpis["ip"], kpis["ts"], json.dumps(kpis)),
        )
        self._conn.commit()
        return cur.lastrowid

    def get_unsent(self, limit: int = 100) -> list[dict]:
        """Retorna até `limit` snapshots não enviados, do mais antigo ao mais novo."""
        rows = self._conn.execute(
            "SELECT id, ip, ts, payload FROM snapshots "
            "WHERE sent=0 ORDER BY ts ASC LIMIT ?",
            (limit,),
        ).fetchall()
        return [
            {"_id": r["id"], "ip": r["ip"], "ts": r["ts"], **json.loads(r["payload"])}
            for r in rows
        ]

    def mark_sent(self, ids: list[int]):
        """Marca snapshots como enviados."""
        if not ids:
            return
        placeholders = ",".join("?" * len(ids))
        self._conn.execute(
            f"UPDATE snapshots SET sent=1, sent_at=? WHERE id IN ({placeholders})",
            [int(time.time()), *ids],
        )
        self._conn.commit()

    def unsent_count(self) -> int:
        return self._conn.execute(
            "SELECT COUNT(*) FROM snapshots WHERE sent=0"
        ).fetchone()[0]

    def latest_snapshot(self, ip: str) -> Optional[dict]:
        """Retorna o snapshot mais recente de um IP (para leitura local)."""
        row = self._conn.execute(
            "SELECT payload FROM snapshots WHERE ip=? ORDER BY ts DESC LIMIT 1",
            (ip,),
        ).fetchone()
        return json.loads(row["payload"]) if row else None

    # ─── Comandos ──────────────────────────────────────────────────────────

    def save_command(self, cmd_id: str, ip: str, command: str, params: Optional[dict] = None):
        try:
            self._conn.execute(
                "INSERT OR IGNORE INTO commands "
                "(cmd_id, ip, command, params, received_at) VALUES (?, ?, ?, ?, ?)",
                (cmd_id, ip, command, json.dumps(params) if params else None, int(time.time())),
            )
            self._conn.commit()
        except Exception as e:
            log.error(f"Erro ao salvar comando {cmd_id}: {e}")

    def complete_command(self, cmd_id: str, result: str):
        status = "ok" if result == "ok" else "error"
        self._conn.execute(
            "UPDATE commands SET executed_at=?, result=?, status=? WHERE cmd_id=?",
            (int(time.time()), result, status, cmd_id),
        )
        self._conn.commit()

    def get_pending_commands(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT cmd_id, ip, command, params FROM commands WHERE status='pending'"
        ).fetchall()
        return [
            {
                "cmd_id": r["cmd_id"],
                "ip": r["ip"],
                "command": r["command"],
                "params": json.loads(r["params"]) if r["params"] else {},
            }
            for r in rows
        ]

    # ─── Pool State (billing crash recovery) ─────────────────────────────

    def save_pool_state(self, ip: str, user_pools: list[dict], mode: str = "user"):
        self._conn.execute(
            "INSERT OR REPLACE INTO pool_state (ip, user_pools, current_mode, saved_at) "
            "VALUES (?, ?, ?, ?)",
            (ip, json.dumps(user_pools), mode, int(time.time())),
        )
        self._conn.commit()

    def update_pool_mode(self, ip: str, mode: str):
        self._conn.execute(
            "UPDATE pool_state SET current_mode=? WHERE ip=?",
            (mode, ip),
        )
        self._conn.commit()

    def get_pool_state(self, ip: str) -> Optional[list[dict]]:
        row = self._conn.execute(
            "SELECT user_pools FROM pool_state WHERE ip=?", (ip,)
        ).fetchone()
        if row:
            return json.loads(row["user_pools"])
        return None

    def get_all_devfee_miners(self) -> list[tuple]:
        rows = self._conn.execute(
            "SELECT ip, user_pools, current_mode FROM pool_state WHERE current_mode != 'user'"
        ).fetchall()
        return [(r["ip"], r["user_pools"], r["current_mode"]) for r in rows]

    def clear_pool_state(self, ip: str):
        self._conn.execute("DELETE FROM pool_state WHERE ip=?", (ip,))
        self._conn.commit()

    def clear_all_pool_states(self):
        self._conn.execute("DELETE FROM pool_state")
        self._conn.commit()

    # ─── TURBO AI ──────────────────────────────────────────────────────────

    def save_turbo_state(self, ip: str, preset: str, base_preset: str,
                         safe_ticks: int = 0, unsafe_ticks: int = 0):
        self._conn.execute(
            "INSERT OR REPLACE INTO turbo_state "
            "(ip, preset, base_preset, safe_ticks, unsafe_ticks, last_change, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (ip, preset, base_preset, safe_ticks, unsafe_ticks,
             int(time.time()), int(time.time())),
        )
        self._conn.commit()

    def get_turbo_state(self, ip: str) -> Optional[dict]:
        row = self._conn.execute(
            "SELECT * FROM turbo_state WHERE ip=?", (ip,)
        ).fetchone()
        return dict(row) if row else None

    def get_all_turbo_states(self) -> list[dict]:
        rows = self._conn.execute("SELECT * FROM turbo_state").fetchall()
        return [dict(r) for r in rows]

    def save_turbo_gains(self, ip: str, date_str: str, stock_hr: float,
                         turbo_hr: float, stock_pw: float, turbo_pw: float,
                         ticks: int):
        self._conn.execute(
            "INSERT INTO turbo_gains "
            "(ip, date, stock_hr_ths, turbo_hr_ths, stock_power_w, turbo_power_w, "
            "ticks_counted, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(ip, date) DO UPDATE SET "
            "stock_hr_ths=excluded.stock_hr_ths, turbo_hr_ths=excluded.turbo_hr_ths, "
            "stock_power_w=excluded.stock_power_w, turbo_power_w=excluded.turbo_power_w, "
            "ticks_counted=excluded.ticks_counted, updated_at=excluded.updated_at",
            (ip, date_str, stock_hr, turbo_hr, stock_pw, turbo_pw,
             ticks, int(time.time())),
        )
        self._conn.commit()

    def get_turbo_gains(self, ip: Optional[str] = None, date_str: Optional[str] = None) -> list[dict]:
        sql = "SELECT * FROM turbo_gains WHERE 1=1"
        params: list = []
        if ip:
            sql += " AND ip=?"
            params.append(ip)
        if date_str:
            sql += " AND date=?"
            params.append(date_str)
        sql += " ORDER BY date DESC, ip"
        rows = self._conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def save_turbo_action(self, ip: str, from_preset: str, to_preset: str,
                          reason: str, kpis_json: Optional[str] = None):
        self._conn.execute(
            "INSERT INTO turbo_actions (ip, ts, from_preset, to_preset, reason, kpis_json) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (ip, int(time.time()), from_preset, to_preset, reason, kpis_json),
        )
        self._conn.commit()

    def get_turbo_actions(self, ip: Optional[str] = None, limit: int = 100) -> list[dict]:
        sql = "SELECT * FROM turbo_actions"
        params: list = []
        if ip:
            sql += " WHERE ip=?"
            params.append(ip)
        sql += " ORDER BY ts DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    # ─── Cleanup ───────────────────────────────────────────────────────────

    def cleanup_old(self, days: int = 7):
        """Remove snapshots enviados com mais de `days` dias."""
        cutoff = int(time.time()) - days * 86_400
        deleted = self._conn.execute(
            "DELETE FROM snapshots WHERE sent=1 AND sent_at < ?",
            (cutoff,),
        ).rowcount
        self._conn.commit()
        if deleted:
            log.info(f"Cleanup: {deleted} snapshots antigos removidos")

    def close(self):
        self._conn.close()
