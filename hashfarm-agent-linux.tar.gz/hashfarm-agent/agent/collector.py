"""
hashfarm-agent · collector.py · v1.0
Loop de coleta assíncrono.

Itera sobre todos os mineradores configurados em paralelo,
com semáforo para não sobrecarregar a rede local.
Grava no store local e emite eventos para o cloud connector.
"""

import asyncio
import logging
import time
from typing import Callable, Optional

import aiohttp

from .config import AgentConfig, MinerEntry
from .store import LocalStore
from .vnish import MinerConfig, MinerPoller, VnishClient

log = logging.getLogger("hashfarm.collector")


class Collector:
    """
    Coleta dados de todos os mineradores configurados.

    Uso:
        async with Collector(cfg, store) as col:
            col.on_snapshot = meu_callback
            await col.run_forever()
    """

    def __init__(self, cfg: AgentConfig, store: LocalStore):
        self.cfg = cfg
        self.store = store
        self.on_snapshot: Optional[Callable[[dict], None]] = None
        self._session: Optional[aiohttp.ClientSession] = None
        self._client: Optional[VnishClient] = None
        self._poller: Optional[MinerPoller] = None
        self._running = False
        # Semáforo: limita paralelismo para não saturar o switch local
        self._sem = asyncio.Semaphore(cfg.collector.parallel_limit)

    async def __aenter__(self):
        connector = aiohttp.TCPConnector(
            limit=50,
            limit_per_host=3,      # no máximo 3 conexões simultâneas por ASIC
            ttl_dns_cache=300,
            force_close=True,      # ASICs não gostam de keep-alive longo
        )
        self._session = aiohttp.ClientSession(connector=connector)
        self._client = VnishClient(self._session)
        self._poller = MinerPoller(self._client)
        return self

    async def __aexit__(self, *_):
        self._running = False
        if self._session:
            await self._session.close()

    def _miner_config(self, entry: MinerEntry) -> MinerConfig:
        return MinerConfig(
            ip=entry.ip,
            port=entry.port,
            user=entry.user,
            password=entry.password,
            api_key=entry.api_key,
        )

    async def _poll_one(self, entry: MinerEntry) -> dict:
        """Coleta dados de um minerador com semáforo e timeout."""
        async with self._sem:
            mc = self._miner_config(entry)
            try:
                raw = await self._poller.poll(mc)
                kpis = self._poller.extract_kpis(raw)

                # Injeta metadados de config (presets de OC)
                kpis["preset_day_w"] = entry.preset_day_w
                kpis["preset_night_w"] = entry.preset_night_w
                kpis["label"] = entry.label or entry.ip
                kpis["temp_warn"] = self.cfg.collector.temp_warn

                # Re-calcula alarmes com temp_warn correto do config
                kpis["alarms"] = self._poller._check_alarms(
                    kpis, temp_warn=self.cfg.collector.temp_warn
                )

                return kpis

            except Exception as e:
                log.error(f"[{entry.ip}] Erro inesperado no poll: {e}")
                return {
                    "ip": entry.ip,
                    "ts": int(time.time()),
                    "status": "offline",
                    "label": entry.label or entry.ip,
                    "alarms": ["offline"],
                    "error": str(e),
                }

    async def poll_all(self) -> list[dict]:
        """Coleta todos os mineradores em paralelo. Retorna lista de KPIs."""
        if not self.cfg.miners:
            return []

        t0 = time.time()
        tasks = [self._poll_one(m) for m in self.cfg.miners]
        results = await asyncio.gather(*tasks)
        elapsed = time.time() - t0

        mining = sum(1 for r in results if r.get("status") == "mining")
        offline = sum(1 for r in results if r.get("status") == "offline")
        alarms = sum(1 for r in results if r.get("alarms") and r["alarms"] != ["offline"])

        log.info(
            f"Poll completo em {elapsed:.1f}s | "
            f"{mining} minerando · {offline} offline · {alarms} em alarme"
        )

        return list(results)

    async def run_once(self) -> list[dict]:
        """Executa um ciclo de coleta, grava no store e emite callbacks."""
        snapshots = await self.poll_all()

        for kpis in snapshots:
            # Sempre grava local primeiro (offline-first)
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self.store.save_snapshot, kpis)

            # Notifica cloud connector (se conectado)
            if self.on_snapshot:
                try:
                    self.on_snapshot(kpis)
                except Exception as e:
                    log.debug(f"Callback on_snapshot erro: {e}")

        return snapshots

    async def run_forever(self):
        """Loop infinito de coleta. Para quando _running=False."""
        self._running = True
        interval = self.cfg.collector.interval

        log.info(
            f"Collector iniciado — {len(self.cfg.miners)} ASICs · "
            f"intervalo {interval}s"
        )

        while self._running:
            cycle_start = time.time()

            try:
                await self.run_once()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.error(f"Erro no ciclo de coleta: {e}")

            # Cleanup semanal (roda uma vez por dia aprox.)
            if int(time.time()) % 86_400 < interval:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(
                    None, self.store.cleanup_old, 7
                )

            # Aguarda o tempo restante do intervalo
            elapsed = time.time() - cycle_start
            wait = max(0, interval - elapsed)
            if wait > 0:
                await asyncio.sleep(wait)

        log.info("Collector encerrado")

    def stop(self):
        self._running = False
