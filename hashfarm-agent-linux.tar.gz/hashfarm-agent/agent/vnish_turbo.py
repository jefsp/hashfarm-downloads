"""
hashfarm-agent · vnish_turbo.py
TURBO para firmware Vnish: configura o preset_switcher nativo do firmware.

Quando o usuario habilita TURBO numa farm, para cada miner Vnish o agente:
  1. busca a lista de presets via GET /api/v1/autotune/presets
  2. detecta o preset stock (TH mais proximo do hr_stock, arredondando para baixo)
  3. monta o bloco preset_switcher com os parametros do perfil escolhido
  4. envia POST /api/v1/settings para que o firmware faca a auto-troca

Nao altera o comportamento de Whatsminer, Bitmain stock nem BrainOS.
"""

import re
import logging
from typing import Optional

log = logging.getLogger("hashfarm.vnish_turbo")

_TH_RE = re.compile(r"(\d+(?:[.,]\d+)?)\s*TH", re.IGNORECASE)
_W_RE = re.compile(r"(\d+)\s*[Ww]")

PROFILES = {
    "conservador": {
        "rise_temp": 70,
        "decrease_temp": 79,
        "initial_offset": 0,
        "top_offset": 1,
        "min_offset": -1,
        "check_minutes": 5,
        "ignore_fan_speed": True,
    },
    "normal": {
        "rise_temp": 75,
        "decrease_temp": 82,
        "initial_offset": 0,
        "top_offset": 1,
        "min_offset": -1,
        "check_minutes": 3,
        "ignore_fan_speed": True,
    },
    "arrojado": {
        "rise_temp": 76,
        "decrease_temp": 83,
        "initial_offset": 1,
        "top_offset": 2,
        "min_offset": -1,
        "check_minutes": 2,
        "ignore_fan_speed": True,
    },
}


def parse_preset_th(preset: dict) -> float:
    """Extrai TH do preset. Tenta `pretty` primeiro (ex: '3500 watt ~ 122 TH'), fallback para `name`."""
    for field in ("pretty", "name"):
        v = preset.get(field) or ""
        m = _TH_RE.search(v)
        if m:
            try:
                return float(m.group(1).replace(",", "."))
            except (TypeError, ValueError):
                continue
    return 0.0


def parse_preset_w(preset: dict) -> int:
    for field in ("name", "pretty"):
        v = preset.get(field) or ""
        m = _W_RE.search(v)
        if m:
            try:
                return int(m.group(1))
            except (TypeError, ValueError):
                continue
    return 0


def sort_presets(presets: list[dict]) -> list[dict]:
    """Ordena por TH (asc), com fallback para wattagem."""
    def key(p):
        th = parse_preset_th(p)
        w = parse_preset_w(p)
        return (th if th > 0 else w, w)
    return sorted(presets, key=key)


def find_stock_index(presets_sorted: list[dict], stock_th: float) -> int:
    """
    Acha o indice do preset mais proximo do stock_th, arredondando para BAIXO.
    Se nenhum preset tem TH <= stock_th, retorna o primeiro (idx=0).
    Se a lista esta vazia, retorna -1.
    """
    if not presets_sorted:
        return -1
    if stock_th <= 0:
        # Sem stock conhecido: assume meio da escada
        return len(presets_sorted) // 2

    candidate = -1
    for i, p in enumerate(presets_sorted):
        th = parse_preset_th(p)
        if th <= 0:
            continue
        # Tolerancia de 1 TH para considerar "exato"
        if abs(th - stock_th) <= 1.0:
            return i
        if th <= stock_th:
            candidate = i
        else:
            break

    if candidate >= 0:
        return candidate

    return 0


def clamp_index(idx: int, n: int) -> int:
    if n <= 0:
        return 0
    return max(0, min(idx, n - 1))


def build_payload(
    profile_name: str,
    presets_sorted: list[dict],
    stock_idx: int,
) -> Optional[dict]:
    """Monta o payload completo para POST /api/v1/settings."""
    prof = PROFILES.get(profile_name) or PROFILES["normal"]
    n = len(presets_sorted)
    if n == 0 or stock_idx < 0:
        return None

    stock_idx = clamp_index(stock_idx, n)
    initial_offset = int(prof.get("initial_offset", 0))
    initial_idx = clamp_index(stock_idx + initial_offset, n)
    top_idx = clamp_index(stock_idx + prof["top_offset"], n)
    min_idx = clamp_index(stock_idx + prof["min_offset"], n)

    if min_idx > top_idx:
        min_idx = top_idx
    if initial_idx > top_idx:
        initial_idx = top_idx
    if initial_idx < min_idx:
        initial_idx = min_idx

    stock_preset = presets_sorted[stock_idx]["name"]
    initial_preset = presets_sorted[initial_idx]["name"]
    top_preset = presets_sorted[top_idx]["name"]
    min_preset = presets_sorted[min_idx]["name"]

    return {
        "miner": {
            "overclock": {
                "preset": initial_preset,
                "preset_switcher": {
                    "enabled": True,
                    "decrease_temp": int(prof["decrease_temp"]),
                    "rise_temp": int(prof["rise_temp"]),
                    "top_preset": top_preset,
                    "min_preset": min_preset,
                    "check_time": int(prof["check_minutes"]) * 60,
                    "ignore_fan_speed": bool(prof["ignore_fan_speed"]),
                },
            }
        },
        "_meta": {
            "profile": profile_name,
            "stock_preset": stock_preset,
            "initial_preset": initial_preset,
            "top_preset": top_preset,
            "min_preset": min_preset,
            "stock_idx": stock_idx,
            "initial_idx": initial_idx,
            "top_idx": top_idx,
            "min_idx": min_idx,
        },
    }


def plan(
    profile_name: str,
    presets_raw: list[dict],
    stock_th: float,
) -> Optional[dict]:
    """
    Pipeline completa: sort + stock detection + payload.
    Retorna None se nao conseguiu (lista vazia ou sem TH parseaveis).
    """
    presets_sorted = sort_presets(presets_raw or [])
    if not presets_sorted:
        log.warning(f"[vnish_turbo] sem presets disponiveis para perfil '{profile_name}'")
        return None
    stock_idx = find_stock_index(presets_sorted, stock_th or 0.0)
    if stock_idx < 0:
        log.warning(f"[vnish_turbo] nao achou stock_idx (stock_th={stock_th})")
        return None
    return build_payload(profile_name, presets_sorted, stock_idx)
