"""
hashfarm-agent · vnish.py · v1.0
Cliente assíncrono para a API Vnish.

Portado da lógica do HashFarm Standalone (JS) para Python/asyncio.
Mantém cache de token por IP com TTL de 55 minutos.
Renovação automática em caso de 401.
"""

import asyncio
import time
import logging
from dataclasses import dataclass, field
from typing import Optional

import aiohttp

log = logging.getLogger("hashfarm.vnish")

# TTL do token em segundos (55 min, conservador)
TOKEN_TTL = 55 * 60
# Timeout padrão por request
REQUEST_TIMEOUT = 10


@dataclass
class TokenEntry:
    token: str
    expires_at: float  # unix timestamp


@dataclass
class MinerConfig:
    ip: str
    port: int = 80
    user: str = "admin"
    password: str = "admin"
    api_key: Optional[str] = None  # sobrepõe token se preenchido

    @property
    def base_url(self) -> str:
        return f"http://{self.ip}:{self.port}/api/v1"


class VnishClient:
    """
    Client assíncrono para a API Vnish.
    Uma instância por sessão aiohttp (compartilhar entre mineradores).
    """

    def __init__(self, session: aiohttp.ClientSession):
        self._session = session
        self._tokens: dict[str, TokenEntry] = {}
        self._auth_locks: dict[str, asyncio.Lock] = {}

    def _get_lock(self, ip: str) -> asyncio.Lock:
        """Lock por IP para evitar múltiplas autenticações simultâneas."""
        if ip not in self._auth_locks:
            self._auth_locks[ip] = asyncio.Lock()
        return self._auth_locks[ip]

    def _token_valid(self, ip: str) -> bool:
        entry = self._tokens.get(ip)
        if not entry:
            return False
        # Margem de 2 min antes de expirar
        return entry.expires_at > time.time() + 120

    def invalidate_token(self, ip: str):
        self._tokens.pop(ip, None)

    async def _authenticate(self, miner: MinerConfig) -> Optional[str]:
        """
        Obtém token via POST /api/v1/unlock.
        Lock por IP garante uma única autenticação simultânea.
        """
        async with self._get_lock(miner.ip):
            # Outro coroutine pode ter autenticado enquanto esperávamos
            if self._token_valid(miner.ip):
                return self._tokens[miner.ip].token

            url = f"{miner.base_url}/unlock"
            try:
                async with self._session.post(
                    url,
                    json={"pw": miner.password},
                    timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT),
                ) as resp:
                    if resp.status != 200:
                        log.warning(f"[{miner.ip}] Auth falhou: HTTP {resp.status}")
                        return None

                    ct = resp.headers.get("content-type", "")
                    if "html" in ct:
                        log.warning(f"[{miner.ip}] Auth: resposta HTML — firmware nao e Vnish")
                        return None

                    data = await resp.json()
                    token = data.get("token")
                    if not token:
                        log.warning(f"[{miner.ip}] Auth: resposta sem token: {data}")
                        return None

                    self._tokens[miner.ip] = TokenEntry(
                        token=token,
                        expires_at=time.time() + TOKEN_TTL,
                    )
                    log.debug(f"[{miner.ip}] Token obtido (TTL {TOKEN_TTL}s)")
                    return token

            except asyncio.TimeoutError:
                log.warning(f"[{miner.ip}] Auth timeout")
                return None
            except Exception as e:
                log.warning(f"[{miner.ip}] Auth erro: {e}")
                return None

    def _build_headers(self, miner: MinerConfig, token: Optional[str]) -> dict:
        headers = {"Content-Type": "application/json"}
        if miner.api_key:
            headers["x-api-key"] = miner.api_key
        elif token:
            headers["Authorization"] = f"Bearer {token}"
        return headers

    async def get(
        self,
        miner: MinerConfig,
        path: str,
        params: Optional[dict] = None,
        _retry: bool = True,
    ) -> Optional[dict]:
        """
        GET autenticado. Renova token automaticamente em caso de 401.
        Retorna None em qualquer erro (timeout, offline, etc).
        """
        # /info é público — não precisa de token
        needs_auth = not path.startswith("/info")

        token = None
        if needs_auth and not miner.api_key:
            token = self._tokens.get(miner.ip, TokenEntry("", 0)).token
            if not self._token_valid(miner.ip):
                token = await self._authenticate(miner)
                if not token:
                    return None

        url = f"{miner.base_url}{path}"
        headers = self._build_headers(miner, token)

        try:
            async with self._session.get(
                url,
                headers=headers,
                params=params,
                timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT),
            ) as resp:
                if resp.status == 401 and _retry:
                    log.debug(f"[{miner.ip}] 401 em {path}, renovando token…")
                    self.invalidate_token(miner.ip)
                    return await self.get(miner, path, params, _retry=False)

                if resp.status != 200:
                    log.debug(f"[{miner.ip}] GET {path} → HTTP {resp.status}")
                    return None

                ct = resp.headers.get("content-type", "")
                if "html" in ct:
                    return None

                return await resp.json(content_type=None)

        except asyncio.TimeoutError:
            log.debug(f"[{miner.ip}] Timeout em {path}")
            return None
        except aiohttp.ClientConnectorError:
            log.debug(f"[{miner.ip}] Conexão recusada")
            return None
        except Exception as e:
            log.debug(f"[{miner.ip}] GET {path} erro: {e}")
            return None

    async def post(
        self,
        miner: MinerConfig,
        path: str,
        body: Optional[dict] = None,
        _retry: bool = True,
    ) -> Optional[dict]:
        """POST autenticado para comandos (start/stop/restart)."""
        token = None
        if not miner.api_key:
            if not self._token_valid(miner.ip):
                token = await self._authenticate(miner)
                if not token:
                    raise RuntimeError(f"[{miner.ip}] Sem token para POST {path}")
            else:
                token = self._tokens[miner.ip].token

        url = f"{miner.base_url}{path}"
        headers = self._build_headers(miner, token)

        try:
            async with self._session.post(
                url,
                headers=headers,
                json=body or {},
                timeout=aiohttp.ClientTimeout(total=REQUEST_TIMEOUT),
            ) as resp:
                if resp.status == 401 and _retry:
                    self.invalidate_token(miner.ip)
                    return await self.post(miner, path, body, _retry=False)

                if resp.status not in (200, 201, 204):
                    body_txt = ""
                    try:
                        body_txt = (await resp.text())[:500]
                    except Exception:
                        pass
                    msg = f"HTTP {resp.status}"
                    if body_txt:
                        msg += f": {body_txt}"
                    raise RuntimeError(msg)

                try:
                    return await resp.json(content_type=None)
                except Exception:
                    return {"ok": True}

        except RuntimeError:
            raise
        except asyncio.TimeoutError:
            raise RuntimeError(f"[{miner.ip}] Timeout em POST {path}")
        except Exception as e:
            raise RuntimeError(f"[{miner.ip}] POST {path} erro: {e}")


class MinerPoller:
    """
    Coleta todos os dados de um minerador em paralelo.
    Equivalente ao fetchMiner() do standalone.
    """

    def __init__(self, client: VnishClient):
        self.client = client

    async def poll(self, miner: MinerConfig) -> dict:
        """
        Retorna dict com summary, info, metrics (24h), settings, status.
        Campos ausentes ficam None — nunca lança exceção.
        """
        summary, info, metrics, settings, status = await asyncio.gather(
            self.client.get(miner, "/summary"),
            self.client.get(miner, "/info"),
            self.client.get(
                miner,
                "/metrics",
                params={"time_slice": "86400", "step": "900"},
            ),
            self.client.get(miner, "/settings"),
            self.client.get(miner, "/status"),
            return_exceptions=False,
        )

        return {
            "ip": miner.ip,
            "ts": int(time.time()),
            "summary": summary,
            "info": info,
            "metrics": metrics,
            "settings": settings,
            "status": status,
        }

    def extract_kpis(self, raw: dict) -> dict:
        """
        Extrai KPIs normalizados do payload bruto.
        Sempre retorna o mesmo schema, com None para campos ausentes.
        Converte tudo para TH/s.
        """
        summary = raw.get("summary")
        info = raw.get("info")
        mi = summary.get("miner") if summary else None

        if not mi:
            return {
                "ip": raw["ip"],
                "ts": raw["ts"],
                "status": "offline",
                "hr_realtime_ths": None,
                "hr_stock_ths": None,
                "hr_average_ths": None,
                "chip_temp_max": None,
                "chip_temp_min": None,
                "pcb_temp_max": None,
                "fan_duty": None,
                "fans": [],
                "target_temp": None,
                "power_w": None,
                "efficiency_w_th": None,
                "hw_errors_pct": None,
                "pools": [],
                "chains": [],
                "model": info.get("miner") if info else None,
                "fw_version": info.get("fw_version") if info else None,
                "uptime": info.get("system", {}).get("uptime") if info else None,
                "miner_state": "offline",
                "failure_desc": None,
                "alarms": ["offline"],
            }

        measure = mi.get("hr_measure", "GH/s")
        div = 1000 if measure == "GH/s" else 1_000_000

        def to_ths(v):
            return round(v / div, 4) if v is not None else None

        # --- Status (MinerState enum API 1.3.3) ---
        miner_status_obj = mi.get("miner_status", {})
        state = miner_status_obj.get("miner_state", "").lower()
        failure_desc = miner_status_obj.get("description")
        status_map = {
            "mining": "mining",
            "auto-tuning": "mining",
            "initializing": "init",
            "starting": "init",
            "restarting": "init",
            "stopped": "idle",
            "shutting-down": "idle",
            "idle": "idle",
            "paused": "idle",
            "failure": "idle",
        }
        status = status_map.get(state, "offline")
        if status == "offline":
            hr_check = mi.get("hr_realtime") or mi.get("instant_hashrate") or 0
            if hr_check and hr_check / div > 0:
                status = "mining"

        # --- Temperatura ---
        chip = mi.get("chip_temp", {})
        pcb = mi.get("pcb_temp", {})

        # --- Fans ---
        cooling = mi.get("cooling", {})
        fans_raw = cooling.get("fans", [])
        fans = [
            {
                "id": f.get("id", i),
                "rpm": f.get("rpm", 0),
                "max_rpm": f.get("max_rpm", 6000),
                "status": f.get("status", "unknown"),
            }
            for i, f in enumerate(fans_raw)
        ]

        settings_root = raw.get("settings") or {}
        settings_miner = settings_root.get("miner") or {}
        settings_cooling = settings_miner.get("cooling") or {}

        # Vnish API: target temp está em cooling.settings.mode.param quando mode=auto
        # Ref: FanSettings -> mode: {name: "auto", param: <target_temp_celsius>}
        _fan_settings = cooling.get("settings") or {}
        _fan_mode = _fan_settings.get("mode") or {}
        _mode_name = _fan_mode.get("name", "")
        _mode_param = _fan_mode.get("param")

        # settings endpoint: miner.cooling.mode.param (ModeRaw schema)
        _sc_mode = settings_cooling.get("mode") or {}
        _sc_mode_name = _sc_mode.get("name", "") if isinstance(_sc_mode, dict) else ""
        _sc_param = _sc_mode.get("param") if isinstance(_sc_mode, dict) else None

        target_temp = None
        if _mode_name == "auto" and _mode_param is not None:
            target_temp = _mode_param
        elif _sc_mode_name == "auto" and _sc_param is not None:
            target_temp = _sc_param
        else:
            # fallbacks para outros firmwares compatíveis
            target_temp = (
                cooling.get("target_temperature")
                or cooling.get("target_temp")
                or cooling.get("target")
                or _mode_param  # mode=manual: param é duty%; ignora abaixo de 30
                or _sc_param
            )
        try:
            target_temp = float(target_temp) if target_temp is not None else None
            if target_temp is not None and not (30 <= target_temp <= 110):
                target_temp = None
        except (TypeError, ValueError):
            target_temp = None

        # --- Pools (UserPool + DevFee para auditoria de fee real) ---
        # IMPORTANTE: inclui DevFee pools para o frontend calcular o % real cobrado.
        # pool_type e diffa são obrigatórios para a aba Auditoria funcionar.
        pools = [
            {
                "url": p.get("url"),
                "user": p.get("user"),
                "status": p.get("status"),
                "accepted": p.get("accepted", 0),
                "rejected": p.get("rejected", 0),
                "ping": p.get("ping"),
                "pool_type": p.get("pool_type", "UserPool"),  # UserPool | DevFee
                "diffa": p.get("diffa", 0),                   # dificuldade acumulada
            }
            for p in mi.get("pools", [])
            # sem filtro — envia UserPool e DevFee
        ]

        # --- Chains ---
        chains = [
            {
                "id": c.get("id", i),
                "hashrate_ths": to_ths(c.get("hashrate_rt") or c.get("hashrate") or c.get("hashrate_ideal")),
                "temp_max": c.get("temp_max") or (c.get("chip_temp") or {}).get("max"),
                "state": (c.get("status") or {}).get("state", "unknown"),
            }
            for i, c in enumerate(mi.get("chains", []))
        ]

        # --- Find Miner (LED piscando) — vem em /status. v1.3.3+ renomeia para locate_miner ---
        status_pane = raw.get("status") or {}
        find_miner = bool(status_pane.get("locate_miner") or status_pane.get("find_miner", False))

        # --- Preset atual rodando no firmware ---
        overclock = mi.get("overclock") or {}
        if not overclock and info:
            overclock = info.get("overclock") or {}
        settings = raw.get("settings") or {}
        settings_oc = settings.get("miner", {}).get("overclock", {})
        current_preset = (
            overclock.get("preset")
            or overclock.get("current_preset")
            or overclock.get("globals", {}).get("preset")
            or settings_oc.get("preset")
            or settings_oc.get("current_preset")
            or None
        )
        if not current_preset:
            oc_keys = list(overclock.keys()) if overclock else []
            soc_keys = list(settings_oc.keys()) if settings_oc else []
            log.warning(f"[{raw['ip']}] preset=None | overclock keys={oc_keys} | settings_oc keys={soc_keys}")

        kpis = {
            "ip": raw["ip"],
            "ts": raw["ts"],
            "status": status,
            "hr_realtime_ths": to_ths(mi.get("hr_realtime") or mi.get("instant_hashrate")),
            "hr_stock_ths": to_ths(mi.get("hr_stock")) or self._stock_fallback(info, mi),
            "hr_average_ths": to_ths(mi.get("hr_average")),
            "chip_temp_max": chip.get("max"),
            "chip_temp_min": chip.get("min"),
            "pcb_temp_max": pcb.get("max"),
            "fan_duty": cooling.get("fan_duty"),
            "fans": fans,
            "target_temp": target_temp,
            "power_w": (mi.get("power_consumption") or mi.get("power")
                        or mi.get("power_usage") or mi.get("consumption")
                        or (mi.get("power_stats") or {}).get("approximated_consumption")),
            "efficiency_w_th": mi.get("power_efficiency"),
            "hw_errors_pct": mi.get("hw_errors_percent"),
            "devfee_pct": mi.get("devfee_percent"),
            "pools": pools,
            "chains": chains,
            "model": info.get("miner") if info else mi.get("miner_type"),
            "fw_version": info.get("fw_version") if info else None,
            "uptime": (info or {}).get("system", {}).get("uptime"),
            "current_preset": current_preset,
            "find_miner": find_miner,
            "miner_state": state,
            "failure_desc": failure_desc,
            "restart_count": mi.get("restart_count"),
            "uptime_s": miner_status_obj.get("miner_state_time"),
            "alarms": [],
        }

        kpis["alarms"] = self._check_alarms(kpis, temp_warn=85)
        return kpis

    @staticmethod
    def _stock_fallback(info, mi) -> Optional[float]:
        from .bitmain import _lookup_antminer_stock
        model = (info or {}).get("miner") or (mi or {}).get("miner_type")
        return _lookup_antminer_stock(model)

    def _check_alarms(self, kpis: dict, temp_warn: int = 85) -> list[str]:
        """Replica as 7 verificações de alarme do standalone."""
        alarms = []

        if kpis["status"] == "offline":
            alarms.append("offline")
            return alarms  # não faz sentido checar o resto

        # Estado de falha reportado pelo firmware (MinerState=failure)
        if kpis.get("miner_state") == "failure":
            desc = kpis.get("failure_desc")
            alarms.append(f"falha:{desc}" if desc else "falha")

        # Temperatura
        t_max = max(
            kpis["chip_temp_max"] or 0,
            kpis["pcb_temp_max"] or 0,
        )
        if t_max >= temp_warn:
            alarms.append(f"temp:{t_max}°C")

        # Fans
        for f in kpis["fans"]:
            if f["rpm"] == 0:
                alarms.append(f"fan{f['id']+1}:rpm_zero")
            if f["status"] == "lost":
                alarms.append(f"fan{f['id']+1}:lost")

        # HW Errors
        hw = kpis["hw_errors_pct"]
        if hw is not None and hw >= 2:
            alarms.append(f"hw_err:{hw:.1f}%")

        # Hashrate baixo (<70% do stock)
        hr = kpis["hr_realtime_ths"]
        hr_stock = kpis["hr_stock_ths"]
        if hr and hr_stock and hr_stock > 0 and (hr / hr_stock) < 0.70:
            alarms.append(f"hr_low:{hr/hr_stock*100:.0f}%")

        # Chains com falha
        bad_states = {"failure", "disconnected", "disabled", "dead"}
        for c in kpis["chains"]:
            state = c.get("state") or c.get("status", "unknown")
            cid   = c.get("id", c.get("index", 0))
            if state in bad_states:
                alarms.append(f"board{cid+1}:{state}")

        # Pools
        active_pools = [p for p in kpis["pools"] if p["status"] == "active"]
        if kpis["pools"] and not active_pools:
            alarms.append("pool:sem_ativo")
        for i, p in enumerate(kpis["pools"]):
            if p["status"] in ("offline", "rejecting"):
                alarms.append(f"pool{i+1}:{p['status']}")

        # Worker sem prefixo de conta (ex: "s19jxp01" em vez de "conta.s19jxp01").
        # Shares nao caem na conta certa -> a maquina aparece OFFLINE no pool
        # mesmo minerando. Ignora DevFee/Refund (worker sem ponto e' normal la).
        for p in kpis["pools"]:
            if str(p.get("pool_type", "UserPool")).lower() in ("devfee", "refund"):
                continue
            u = (p.get("user") or "").strip()
            if u and "." not in u:
                alarms.append("pool:worker_sem_conta")
                break

        return alarms
