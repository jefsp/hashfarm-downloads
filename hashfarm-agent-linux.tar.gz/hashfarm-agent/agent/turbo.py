"""
hashfarm-agent · turbo.py
TURBO AI GO2Mine — Motor de auto-tuning inteligente.
Monitora KPIs a cada tick (~30s) e ajusta presets para maximizar
hashrate mantendo seguranca termica. Suporta Vnish, BrainOS e Whatsminer.
Bitmain stock apenas monitoramento (alertas).
"""

import json
import logging
import re
import time
from dataclasses import dataclass, field
from datetime import date
from typing import Callable, Optional, Awaitable

log = logging.getLogger("hashfarm.turbo")

COOLDOWN_S = 180
PROFILES = {
    "conservador": {
        "temp_safe": 72, "temp_caution": 78, "temp_emergency": 88,
        "hw_err_caution": 1.5, "hw_err_emergency": 4.0,
        "temp_hard_limit": 95,
        "max_oc_steps": 1,
        "safe_ticks_to_up": 12,
        "unsafe_ticks_to_down": 2,
    },
    "normal": {
        "temp_safe": 76, "temp_caution": 80, "temp_emergency": 90,
        "hw_err_caution": 2.0, "hw_err_emergency": 5.0,
        "temp_hard_limit": 95,
        "max_oc_steps": 2,
        "safe_ticks_to_up": 10,
        "unsafe_ticks_to_down": 2,
    },
    "arrojado": {
        "temp_safe": 79, "temp_caution": 83, "temp_emergency": 90,
        "hw_err_caution": 2.5, "hw_err_emergency": 5.0,
        "temp_hard_limit": 91,
        "max_oc_steps": 2,
        "safe_ticks_to_up": 8,
        "unsafe_ticks_to_down": 3,
    },
}

WM_POWER_LADDER = ["Low", "Normal", "High"]
HARD_TEMP_LIMIT = 95
HARD_HW_ERR_LIMIT = 8.0
MAX_OC_FROM_STOCK = 2
_WATT_RE = re.compile(r"(\d+)\s*[Ww]?")


def _parse_wattage(preset_name: str) -> int:
    name = preset_name.strip()
    if name.isdigit():
        return int(name)
    m = _WATT_RE.search(name)
    return int(m.group(1)) if m else 0


def _sort_presets(presets: list[str]) -> list[str]:
    return sorted(presets, key=lambda p: (_parse_wattage(p), p))


def _chain_alive(c: dict) -> bool:
    state_v = (c.get("state") or c.get("status") or "").lower()
    if state_v in ("dead", "failure", "disconnected", "lost", "error", "off"):
        return False
    hr = c.get("hashrate_ths") or c.get("hr_ths") or 0
    if hr <= 0:
        return False
    return True


def _effective_stock_ths(hr_stock_ths: float, chains: list) -> float:
    if not hr_stock_ths or hr_stock_ths <= 0:
        return 0.0
    if not chains:
        return hr_stock_ths
    total = len(chains)
    alive = sum(1 for c in chains if _chain_alive(c))
    if alive <= 0 or alive >= total:
        return hr_stock_ths
    return hr_stock_ths * (alive / total)


@dataclass
class TurboDecision:
    action: str = "hold"
    from_preset: str = ""
    to_preset: str = ""
    reason: str = ""
    state: str = "stable"

    def to_dict(self) -> dict:
        return {
            "action": self.action,
            "from_preset": self.from_preset,
            "to_preset": self.to_preset,
            "reason": self.reason,
            "state": self.state,
        }


@dataclass
class MinerTurboState:
    ip: str = ""
    firmware: str = ""
    current_preset: str = ""
    base_preset: str = ""
    stock_preset: str = ""
    turbo_offset: int = 0
    last_change_ts: float = 0.0
    safe_ticks: int = 0
    unsafe_ticks: int = 0
    stock_hr_ths: float = 0.0
    hr_accumulator: float = 0.0
    power_accumulator: float = 0.0
    ticks_today: int = 0
    today: str = ""
    win_hr_acc: float = 0.0
    win_power_acc: float = 0.0
    win_ticks: int = 0
    turbo_floor: str = ""
    turbo_owns_preset: bool = False


class TurboEngine:
    def __init__(self, store=None):
        self._store = store
        self._states: dict[str, MinerTurboState] = {}
        self._config: Optional[dict] = None
        self._available_presets: dict[str, list[str]] = {}
        self._preset_fetch_ts: dict[str, float] = {}
        self._last_report_ts: float = 0.0
        self._restore_from_store()

    def _restore_from_store(self):
        if not self._store:
            return
        try:
            today_str = str(date.today())
            rows = self._store.get_turbo_gains(date_str=today_str)
            n = 0
            for row in rows:
                ip = row.get("ip")
                if not ip:
                    continue
                state = MinerTurboState(ip=ip, today=today_str)
                ticks = int(row.get("ticks_counted") or 0)
                avg_hr = float(row.get("turbo_hr_ths") or 0.0)
                avg_pw = float(row.get("turbo_power_w") or 0.0)
                stock = float(row.get("stock_hr_ths") or 0.0)
                state.stock_hr_ths = stock
                state.ticks_today = ticks
                state.hr_accumulator = avg_hr * ticks
                state.power_accumulator = avg_pw * ticks
                self._states[ip] = state
                n += 1
            if n:
                log.info(f"[turbo] estado restaurado de {n} miner(s) (acumuladores do dia {today_str})")
        except Exception as e:
            log.debug(f"[turbo] restore falhou: {e}")

    def set_config(self, config: dict):
        self._config = config
        excl = config.get("excluded_ips") or []
        if not isinstance(excl, (list, tuple, set)):
            excl = []
        log.info(f"[turbo] config: enabled={config.get('enabled')} profile={config.get('profile', 'normal')} excluded_ips={list(excl)}")

    def is_excluded(self, ip: str) -> bool:
        if not self._config:
            return False
        excl = self._config.get("excluded_ips") or []
        if not isinstance(excl, (list, tuple, set)):
            return False
        return ip in excl

    def get_restore_list(self) -> list[tuple[str, str, str]]:
        result = []
        for ip, state in self._states.items():
            if state.base_preset and state.current_preset != state.base_preset:
                result.append((ip, state.firmware, state.base_preset))
        return result

    def clear_states(self):
        self._states.clear()

    @property
    def enabled(self) -> bool:
        return bool(self._config and self._config.get("enabled"))

    @property
    def _profile(self) -> dict:
        name = (self._config or {}).get("profile", "normal")
        return PROFILES.get(name, PROFILES["normal"])

    def set_presets(self, ip: str, presets: list[str]):
        sorted_p = _sort_presets([p for p in presets if p and p != "__disabled__"])
        if sorted_p:
            self._available_presets[ip] = sorted_p
            self._preset_fetch_ts[ip] = time.time()
            log.info(f"[{ip}] turbo presets: {sorted_p}")

    def infer_preset_from_power(self, ip: str, power_w: float) -> Optional[str]:
        presets = self._available_presets.get(ip, [])
        if not presets or not power_w or power_w <= 0:
            return None
        best = None
        best_diff = float("inf")
        for p in presets:
            w = _parse_wattage(p)
            if w <= 0:
                continue
            diff = abs(w - power_w)
            if diff < best_diff:
                best_diff = diff
                best = p
        if best:
            log.info(f"[{ip}] inferred preset from power {power_w:.0f}W → {best}")
        return best

    def infer_preset_from_hashrate(self, ip: str, hr_ths: float, hr_stock_ths: float) -> Optional[str]:
        presets = self._available_presets.get(ip, [])
        if not presets or not hr_ths or hr_ths <= 0 or not hr_stock_ths or hr_stock_ths <= 0:
            return None
        wattages = [_parse_wattage(p) for p in presets]
        valid_w = [w for w in wattages if w > 0]
        if not valid_w:
            return None
        median_w = sorted(valid_w)[len(valid_w) // 2]
        ratio = hr_ths / hr_stock_ths
        estimated_w = median_w * ratio
        best = None
        best_diff = float("inf")
        for p in presets:
            w = _parse_wattage(p)
            if w <= 0:
                continue
            diff = abs(w - estimated_w)
            if diff < best_diff:
                best_diff = diff
                best = p
        if best:
            log.info(f"[{ip}] inferred preset from hashrate {hr_ths:.1f}/{hr_stock_ths:.1f} TH/s (ratio={ratio:.2f}, est={estimated_w:.0f}W) → {best}")
        return best

    def _get_state(self, ip: str) -> MinerTurboState:
        today = str(date.today())
        state = self._states.get(ip)
        if not state:
            state = MinerTurboState(ip=ip, today=today)
            self._states[ip] = state
        if state.today != today:
            if self._store and state.ticks_today > 0:
                avg_hr = state.hr_accumulator / state.ticks_today if state.ticks_today else 0
                avg_pw = state.power_accumulator / state.ticks_today if state.ticks_today else 0
                self._store.save_turbo_gains(
                    ip, state.today, state.stock_hr_ths, avg_hr, avg_pw, avg_pw, state.ticks_today
                )
            state.hr_accumulator = 0.0
            state.power_accumulator = 0.0
            state.ticks_today = 0
            state.today = today
        return state

    def _get_preset_index(self, ip: str, preset: str) -> int:
        presets = self._available_presets.get(ip, [])
        for i, p in enumerate(presets):
            if p == preset:
                return i
        return -1

    def _get_preset_at(self, ip: str, index: int) -> Optional[str]:
        presets = self._available_presets.get(ip, [])
        if 0 <= index < len(presets):
            return presets[index]
        return None

    def _estimate_stock_preset(self, ip: str, state: MinerTurboState, power_w: float) -> Optional[str]:
        presets = self._available_presets.get(ip, [])
        if not presets:
            return None
        if state.win_ticks < 20:
            return None
        current_w = _parse_wattage(state.current_preset)
        hr_real = state.win_hr_acc / state.win_ticks if state.win_ticks > 0 else 0
        hr_stock = state.stock_hr_ths
        if hr_real <= 0 or hr_stock <= 0:
            return None
        if hr_real < hr_stock * 0.5:
            log.info(f"[{ip}] stock estimate SKIPPED: hr_real={hr_real:.1f} < 50% stock={hr_stock:.1f} (maquina degradada ou manual-low)")
            return None
        if current_w > 0:
            stock_w = current_w * (hr_stock / hr_real)
        elif power_w > 0:
            stock_w = power_w * (hr_stock / hr_real)
        else:
            return None
        max_reasonable_w = max(_parse_wattage(p) for p in presets)
        if stock_w > max_reasonable_w * 1.1:
            log.warning(f"[{ip}] stock estimate REJECTED: {stock_w:.0f}W > max preset {max_reasonable_w}W")
            return None
        best = None
        best_diff = float("inf")
        for p in presets:
            w = _parse_wattage(p)
            if w <= 0:
                continue
            if abs(w - stock_w) < best_diff:
                best_diff = abs(w - stock_w)
                best = p
        if best and best != state.stock_preset:
            log.info(f"[{ip}] stock preset estimated: {best} (stock_w={stock_w:.0f}W, hr={hr_real:.1f}/{hr_stock:.1f})")
        return best

    def _wm_index(self, mode: str) -> int:
        try:
            return WM_POWER_LADDER.index(mode)
        except ValueError:
            return 1

    async def tick(
        self,
        ip: str,
        kpis: dict,
        firmware: str,
        apply_fn: Callable[..., Awaitable[bool]],
    ) -> TurboDecision:
        if not self.enabled:
            return TurboDecision(state="disabled")
        if self.is_excluded(ip):
            return TurboDecision(state="excluded", reason="miner_excluded_by_user")

        prof = self._profile
        state = self._get_state(ip)
        state.firmware = firmware

        chip_temp = kpis.get("chip_temp_max") or 0
        hw_err = kpis.get("hw_errors_pct") or 0.0
        fan_duty = kpis.get("fan_duty") or 0
        hr_real = kpis.get("hr_realtime_ths") or 0.0
        hr_stock_raw = kpis.get("hr_stock_ths") or 0.0
        chains = kpis.get("chains") or []
        hr_stock = _effective_stock_ths(hr_stock_raw, chains)
        power_w = kpis.get("power_w") or 0
        current_preset = kpis.get("current_preset") or ""
        if current_preset and current_preset.lower() in ("disabled", "off", "none", "__disabled__", "null"):
            log.info(f"[{ip}] turbo skip: current_preset='{current_preset}' (overclock desativado no firmware)")
            return TurboDecision(state="oc_disabled", reason=f"firmware_preset={current_preset}")
        fans = kpis.get("fans") or []

        if hr_stock > 0:
            if state.stock_hr_ths and abs(hr_stock - state.stock_hr_ths) / state.stock_hr_ths > 0.05:
                log.info(f"[{ip}] effective stock changed: {state.stock_hr_ths:.1f} → {hr_stock:.1f} TH/s "
                         f"(raw={hr_stock_raw:.1f}, chains={sum(1 for c in chains if _chain_alive(c))}/{len(chains)})")
            state.stock_hr_ths = hr_stock

        state.hr_accumulator += hr_real
        state.power_accumulator += power_w
        state.ticks_today += 1
        state.win_hr_acc += hr_real
        state.win_power_acc += power_w
        state.win_ticks += 1

        if self._store and state.ticks_today % 10 == 0:
            self._store.save_turbo_gains(
                ip, state.today, state.stock_hr_ths,
                state.hr_accumulator / state.ticks_today if state.ticks_today else 0,
                0, state.power_accumulator / state.ticks_today if state.ticks_today else 0,
                state.ticks_today,
            )

        if state.win_ticks >= 3 and state.stock_hr_ths > 0:
            sp = self._estimate_stock_preset(ip, state, power_w)
            if sp:
                state.stock_preset = sp

        if current_preset and state.current_preset != current_preset:
            external_change = time.time() - state.last_change_ts > 10
            if state.current_preset and external_change:
                old_w = _parse_wattage(state.current_preset)
                new_w = _parse_wattage(current_preset)
                significant = old_w <= 0 or new_w <= 0 or abs(new_w - old_w) / max(old_w, 1) > 0.10
                if significant:
                    log.info(f"[{ip}] external preset change: {state.current_preset}({old_w}W) → {current_preset}({new_w}W) — turbo releases ownership")
                    state.base_preset = current_preset
                    state.turbo_offset = 0
                    state.safe_ticks = 0
                    state.unsafe_ticks = 0
                    state.turbo_owns_preset = False
                    state.turbo_floor = ""
            state.current_preset = current_preset
            state.win_hr_acc = 0.0
            state.win_power_acc = 0.0
            state.win_ticks = 0
            if not state.base_preset:
                state.base_preset = current_preset
            if not state.turbo_floor:
                state.turbo_floor = current_preset

        now = time.time()

        if firmware != "whatsminer" and state.current_preset and state.stock_preset and state.turbo_owns_preset:
            presets = self._available_presets.get(ip, [])
            if presets:
                cur_idx = self._get_preset_index(ip, state.current_preset)
                stock_idx = self._get_preset_index(ip, state.stock_preset)
                ceiling = stock_idx + MAX_OC_FROM_STOCK
                if cur_idx >= 0 and stock_idx >= 0 and cur_idx > ceiling:
                    clamp_idx = min(ceiling, len(presets) - 1)
                    clamp_preset = presets[clamp_idx]
                    log.warning(f"[{ip}] SAFETY CLAMP (turbo-owned): {state.current_preset}(idx={cur_idx}) > stock({state.stock_preset})+{MAX_OC_FROM_STOCK} → forcing {clamp_preset}")
                    ok = await self._apply(ip, firmware, clamp_preset, apply_fn)
                    if ok:
                        d = TurboDecision("down", state.current_preset, clamp_preset, f"safety_clamp stock={state.stock_preset}+{MAX_OC_FROM_STOCK}", "clamp")
                        state.current_preset = clamp_preset
                        state.turbo_floor = clamp_preset
                        state.last_change_ts = now
                        state.safe_ticks = 0
                        self._log_action(ip, d)
                        return d

        hard_temp = prof.get("temp_hard_limit", HARD_TEMP_LIMIT)
        if chip_temp >= hard_temp or hw_err >= HARD_HW_ERR_LIMIT:
            log.error(f"[{ip}] HARD LIMIT: chip={chip_temp}°C hw={hw_err:.1f}% — EMERGENCIA IMEDIATA")
            new_preset = self._step_down(ip, firmware, state, steps=3)
            if new_preset and new_preset != state.current_preset:
                ok = await self._apply(ip, firmware, new_preset, apply_fn)
                if ok:
                    d = TurboDecision("down", state.current_preset, new_preset, f"HARD_LIMIT chip={chip_temp} hw={hw_err:.1f}%", "emergency")
                    state.current_preset = new_preset
                    state.last_change_ts = now
                    self._log_action(ip, d)
                    return d
            return TurboDecision(state="emergency")

        is_emergency = (
            chip_temp >= prof["temp_emergency"]
            or hw_err >= prof["hw_err_emergency"]
        )
        is_caution = (
            chip_temp >= prof["temp_caution"]
            or hw_err >= prof["hw_err_caution"]
        )
        is_safe = (
            chip_temp <= prof["temp_safe"]
            and hw_err < 0.5
        )

        decision = TurboDecision(from_preset=state.current_preset)

        if is_emergency:
            state.safe_ticks = 0
            state.unsafe_ticks += 1
            if now - state.last_change_ts >= COOLDOWN_S:
                new_preset = self._step_down(ip, firmware, state, steps=2)
                if new_preset and new_preset != state.current_preset:
                    reason = f"emergency chip={chip_temp} hw={hw_err:.1f}%"
                    ok = await self._apply(ip, firmware, new_preset, apply_fn)
                    if ok:
                        decision = TurboDecision("down", state.current_preset, new_preset, reason, "emergency")
                        state.current_preset = new_preset
                        state.last_change_ts = now
                        self._log_action(ip, decision)
                    return decision
            decision.state = "emergency"
            return decision

        if is_caution:
            state.safe_ticks = 0
            state.unsafe_ticks += 1
            if state.unsafe_ticks >= prof["unsafe_ticks_to_down"]:
                if now - state.last_change_ts >= COOLDOWN_S:
                    new_preset = self._step_down(ip, firmware, state, steps=1)
                    if new_preset and new_preset != state.current_preset:
                        reason = f"caution chip={chip_temp} hw={hw_err:.1f}%"
                        ok = await self._apply(ip, firmware, new_preset, apply_fn)
                        if ok:
                            decision = TurboDecision("down", state.current_preset, new_preset, reason, "caution")
                            state.current_preset = new_preset
                            state.last_change_ts = now
                            state.unsafe_ticks = 0
                            self._log_action(ip, decision)
                        return decision
            decision.state = "caution"
            return decision

        if is_safe or not (is_caution or is_emergency):
            state.unsafe_ticks = 0
            state.safe_ticks += 1
            ticks_needed = prof["safe_ticks_to_up"] if is_safe else prof["safe_ticks_to_up"] * 2
            if state.safe_ticks >= ticks_needed:
                if now - state.last_change_ts >= COOLDOWN_S:
                    if hr_real > 0 and hr_stock > 0 and hr_real < hr_stock * 0.97:
                        new_preset = self._jump_to_stock(ip, firmware, state, hr_real, hr_stock)
                    else:
                        new_preset = self._step_up(ip, firmware, state, prof["max_oc_steps"])
                    if new_preset and new_preset != state.current_preset:
                        reason = f"overclock chip={chip_temp} hw={hw_err:.1f}% safe_ticks={state.safe_ticks}"
                        ok = await self._apply(ip, firmware, new_preset, apply_fn)
                        if ok:
                            decision = TurboDecision("up", state.current_preset, new_preset, reason, "overclock")
                            state.current_preset = new_preset
                            state.last_change_ts = now
                            state.safe_ticks = 0
                            self._log_action(ip, decision)
                        return decision
                    else:
                        log.info(f"[{ip}] overclock blocked: new_preset={new_preset} current={state.current_preset} base={state.base_preset} presets={len(self._available_presets.get(ip, []))}")
            decision.state = "safe" if is_safe else "stable"
            return decision

    def _step_down(self, ip: str, firmware: str, state: MinerTurboState, steps: int = 1) -> Optional[str]:
        if firmware == "whatsminer":
            idx = self._wm_index(state.current_preset)
            new_idx = max(0, idx - steps)
            return WM_POWER_LADDER[new_idx]
        presets = self._available_presets.get(ip, [])
        if not presets:
            return None
        idx = self._get_preset_index(ip, state.current_preset)
        if idx < 0:
            return presets[0]
        new_idx = max(0, idx - steps)
        state.turbo_offset = new_idx - self._get_preset_index(ip, state.base_preset)
        return presets[new_idx]

    def _jump_to_stock(self, ip: str, firmware: str, state: MinerTurboState,
                       hr_real: float, hr_stock: float) -> Optional[str]:
        if firmware == "whatsminer":
            return WM_POWER_LADDER[-1]
        presets = self._available_presets.get(ip, [])
        if not presets:
            return None
        stock_idx = self._get_preset_index(ip, state.stock_preset) if state.stock_preset else -1
        if stock_idx < 0:
            return None
        ceiling = min(stock_idx + MAX_OC_FROM_STOCK, len(presets) - 1)
        cur_idx = self._get_preset_index(ip, state.current_preset)
        if cur_idx < stock_idx + 1:
            target_idx = min(stock_idx + 1, ceiling)
        else:
            target_idx = min(cur_idx + 1, ceiling)
        if target_idx <= cur_idx:
            log.info(f"[{ip}] jump_to_stock: at ceiling (cur={state.current_preset} idx={cur_idx} ceiling={ceiling})")
            return None
        log.info(f"[{ip}] jump to stock+1: {state.current_preset}(idx={cur_idx}) → {presets[target_idx]} "
                 f"(stock={state.stock_preset}(idx={stock_idx}) ceiling={ceiling} hr={hr_real:.1f}/{hr_stock:.1f})")
        return presets[target_idx]

    def _step_up(self, ip: str, firmware: str, state: MinerTurboState, max_oc: int) -> Optional[str]:
        if firmware == "whatsminer":
            idx = self._wm_index(state.current_preset)
            new_idx = min(len(WM_POWER_LADDER) - 1, idx + 1)
            return WM_POWER_LADDER[new_idx]
        presets = self._available_presets.get(ip, [])
        if not presets:
            return None
        idx = self._get_preset_index(ip, state.current_preset)
        if idx < 0:
            log.warning(f"[{ip}] step_up: current preset {state.current_preset} not in list")
            return None
        stock_idx = self._get_preset_index(ip, state.stock_preset) if state.stock_preset else -1
        if stock_idx < 0:
            log.info(f"[{ip}] step_up BLOCKED: stock_preset unknown (sem overclock sem referencia de fabrica)")
            return None
        ceiling = min(stock_idx + MAX_OC_FROM_STOCK, len(presets) - 1)
        if idx >= ceiling:
            log.info(f"[{ip}] step_up: at ceiling idx={idx} ceiling={ceiling} stock={state.stock_preset}")
            return None
        floor_idx = self._get_preset_index(ip, state.turbo_floor) if state.turbo_floor else idx
        if floor_idx >= 0 and (idx + 1 - floor_idx) > MAX_OC_FROM_STOCK:
            log.info(f"[{ip}] step_up BLOCKED: max {MAX_OC_FROM_STOCK} steps from turbo_floor={state.turbo_floor}")
            return None
        new_idx = idx + 1
        state.turbo_offset = new_idx - self._get_preset_index(ip, state.base_preset) if state.base_preset else 0
        return presets[new_idx]

    async def _apply(self, ip: str, firmware: str, preset: str, apply_fn) -> bool:
        try:
            ok = await apply_fn(ip, preset)
            if ok:
                log.info(f"[{ip}] turbo applied: {preset}")
                st = self._states.get(ip)
                if st:
                    st.turbo_owns_preset = True
                    if not st.turbo_floor:
                        st.turbo_floor = preset
                if self._store:
                    self._store.save_turbo_state(
                        ip, preset,
                        self._states.get(ip, MinerTurboState()).base_preset,
                        self._states.get(ip, MinerTurboState()).safe_ticks,
                        self._states.get(ip, MinerTurboState()).unsafe_ticks,
                    )
            return bool(ok)
        except Exception as e:
            log.warning(f"[{ip}] turbo apply failed: {e}")
            return False

    def _log_action(self, ip: str, decision: TurboDecision):
        log.info(f"[{ip}] TURBO {decision.action}: {decision.from_preset} → {decision.to_preset} ({decision.reason})")
        if self._store:
            self._store.save_turbo_action(
                ip, decision.from_preset, decision.to_preset, decision.reason
            )

    def track_only_stats(self, ip: str, kpis: dict, firmware: str):
        """Acumula estatisticas (hr/power/ticks) sem aplicar decisoes.
        Usado para Vnish, onde o firmware nativo gerencia auto-troca via preset_switcher.
        Mantem dados para reports diarios e ganho %.
        """
        if not self.enabled:
            return
        state = self._get_state(ip)
        state.firmware = firmware
        hr_real = kpis.get("hr_realtime_ths") or 0.0
        hr_stock = kpis.get("hr_stock_ths") or 0.0
        chains = kpis.get("chains") or []
        eff_stock = _effective_stock_ths(hr_stock, chains)
        power_w = kpis.get("power_w") or 0
        current_preset = kpis.get("current_preset") or ""
        if eff_stock > 0:
            state.stock_hr_ths = eff_stock
        state.hr_accumulator += hr_real
        state.power_accumulator += power_w
        state.ticks_today += 1
        state.win_hr_acc += hr_real
        state.win_power_acc += power_w
        state.win_ticks += 1
        if current_preset and state.current_preset != current_preset:
            state.current_preset = current_preset
            if not state.base_preset:
                state.base_preset = current_preset
        if self._store and state.ticks_today % 10 == 0:
            self._store.save_turbo_gains(
                ip, state.today, state.stock_hr_ths,
                state.hr_accumulator / state.ticks_today if state.ticks_today else 0,
                0, state.power_accumulator / state.ticks_today if state.ticks_today else 0,
                state.ticks_today,
            )

    def monitor_only(self, ip: str, kpis: dict) -> Optional[dict]:
        prof = self._profile
        chip_temp = kpis.get("chip_temp_max") or 0
        hw_err = kpis.get("hw_errors_pct") or 0.0
        fans = kpis.get("fans") or []
        fan_dead = any(
            f.get("rpm", 1) == 0 and f.get("status", "").lower() in ("lost", "dead", "")
            for f in fans
        )

        state = self._get_state(ip)
        hr_real = kpis.get("hr_realtime_ths") or 0.0
        hr_stock = kpis.get("hr_stock_ths") or 0.0
        power_w = kpis.get("power_w") or 0
        if hr_stock > 0:
            state.stock_hr_ths = hr_stock
        state.hr_accumulator += hr_real
        state.power_accumulator += power_w
        state.ticks_today += 1

        alerts = []
        if chip_temp >= prof["temp_emergency"]:
            alerts.append(f"temp_critica:{chip_temp}°C")
        elif chip_temp >= prof["temp_caution"]:
            alerts.append(f"temp_alta:{chip_temp}°C")
        if hw_err >= prof["hw_err_emergency"]:
            alerts.append(f"hw_err:{hw_err:.1f}%")
        if fan_dead:
            alerts.append("fan_morto")

        if alerts:
            return {"ip": ip, "firmware": "bitmain_stock", "alerts": alerts, "state": "alert"}
        return None

    def get_report(self) -> list[dict]:
        rows = []
        for ip, state in self._states.items():
            if state.ticks_today <= 0:
                continue
            avg_hr_day = state.hr_accumulator / state.ticks_today if state.ticks_today > 0 else 0
            if avg_hr_day <= 0 or state.stock_hr_ths <= 0:
                continue
            gain_pct = (avg_hr_day / state.stock_hr_ths - 1) * 100 if state.stock_hr_ths > 0 else 0
            rows.append({
                "ip": ip,
                "firmware": state.firmware,
                "current_preset": state.current_preset,
                "base_preset": state.base_preset,
                "stock_preset": state.stock_preset,
                "stock_hr_ths": round(state.stock_hr_ths, 2),
                "turbo_hr_ths": round(avg_hr_day, 2),
                "gain_pct": round(gain_pct, 2),
                "offset": state.turbo_offset,
                "ticks": state.ticks_today,
                "safe_ticks": state.safe_ticks,
                "unsafe_ticks": state.unsafe_ticks,
                "state": "active",
            })
        return rows
