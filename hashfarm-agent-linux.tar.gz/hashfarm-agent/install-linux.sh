#!/usr/bin/env bash
# ============================================================
#  go2mine — hashfarm-agent  |  Linux Installer
#  Suporte: Ubuntu 20+, Debian 11+, Raspberry Pi OS (Bullseye+)
#  Uso: sudo bash install-linux.sh [--key SUA_AGENT_KEY]
# ============================================================
set -euo pipefail

# ── Cores ────────────────────────────────────────────────────
RESET='\033[0m'; BOLD='\033[1m'
GREEN='\033[0;32m'; CYAN='\033[0;36m'
YELLOW='\033[1;33m'; RED='\033[0;31m'

ok()   { echo -e "${GREEN}✔${RESET}  $*"; }
info() { echo -e "${CYAN}→${RESET}  $*"; }
warn() { echo -e "${YELLOW}⚠${RESET}  $*"; }
die()  { echo -e "${RED}✖${RESET}  $*" >&2; exit 1; }
hdr()  { echo -e "\n${BOLD}${CYAN}$*${RESET}"; }

# ── Configurações ────────────────────────────────────────────
INSTALL_DIR="/opt/hashfarm-agent"
SERVICE_NAME="hashfarm-agent"
SERVICE_USER="hashfarm"
DASHBOARD_URL="https://app.go2mine.com"
AGENT_KEY=""

# ── Argumentos ──────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case $1 in
    --key) AGENT_KEY="$2"; shift 2 ;;
    --dir) INSTALL_DIR="$2"; shift 2 ;;
    *) die "Argumento desconhecido: $1" ;;
  esac
done

# ── Banner ───────────────────────────────────────────────────
echo -e "${BOLD}"
echo "  ██████   ██████  ██████  ███    ███ ██ ███    ██ ███████"
echo " ██       ██  ████      ██ ████  ████ ██ ████   ██ ██     "
echo " ██   ███ ██ ██ ██  █████  ██ ████ ██ ██ ██ ██  ██ █████  "
echo " ██    ██ ████  ██ ██      ██  ██  ██ ██ ██  ██ ██ ██     "
echo "  ██████   ██████  ███████ ██      ██ ██ ██   ████ ███████"
echo -e "${RESET}"
SCRIPT_DIR_TMP="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AGENT_VERSION=$(grep '__version__' "$SCRIPT_DIR_TMP/agent/__init__.py" 2>/dev/null | sed 's/.*"\(.*\)"/\1/')
echo -e "  ${CYAN}hashfarm-agent v${AGENT_VERSION} — instalador Linux${RESET}"
echo -e "  ${CYAN}${DASHBOARD_URL}${RESET}\n"

# ── Root ─────────────────────────────────────────────────────
[[ $EUID -ne 0 ]] && die "Execute como root: sudo bash $0"

# ── Python 3.9+ ──────────────────────────────────────────────
hdr "1/6  Verificando Python"
PYTHON=""
for cmd in python3.12 python3.11 python3.10 python3.9 python3; do
  if command -v "$cmd" &>/dev/null; then
    VER=$("$cmd" -c "import sys; print(sys.version_info[:2])")
    if "$cmd" -c "import sys; assert sys.version_info >= (3,9)" 2>/dev/null; then
      PYTHON="$cmd"
      ok "Encontrado: $cmd ($VER)"
      break
    fi
  fi
done

if [[ -z "$PYTHON" ]]; then
  warn "Python 3.9+ não encontrado. Tentando instalar via apt..."
  apt-get update -qq && apt-get install -y python3 python3-venv python3-pip
  PYTHON="python3"
  ok "Python instalado: $($PYTHON --version)"
fi

# ── Dependências de sistema ───────────────────────────────────
hdr "2/6  Instalando dependências do sistema"
apt-get update -qq 2>/dev/null || true
apt-get install -y -qq python3-venv python3-pip curl 2>/dev/null || true
ok "Dependências OK"

# ── Usuário de serviço ────────────────────────────────────────
hdr "3/6  Configurando usuário do serviço"
if ! id "$SERVICE_USER" &>/dev/null; then
  useradd --system --no-create-home --shell /usr/sbin/nologin "$SERVICE_USER"
  ok "Usuário '$SERVICE_USER' criado"
else
  ok "Usuário '$SERVICE_USER' já existe"
fi

# ── Instalação dos arquivos ───────────────────────────────────
hdr "4/6  Copiando arquivos para $INSTALL_DIR"

# Descobre onde está o script (os arquivos do agente estão no mesmo diretório)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR/agent" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/requirements.txt" "$INSTALL_DIR/"
[[ -f "$SCRIPT_DIR/pyproject.toml" ]] && cp "$SCRIPT_DIR/pyproject.toml" "$INSTALL_DIR/" || true
for sh in install-linux.sh uninstall-linux.sh update-linux.sh restart-linux.sh; do
  [[ -f "$SCRIPT_DIR/$sh" ]] && cp "$SCRIPT_DIR/$sh" "$INSTALL_DIR/"
done
ok "Arquivos copiados"

# Cria virtualenv e instala dependências
info "Criando virtualenv e instalando dependências Python..."
"$PYTHON" -m venv "$INSTALL_DIR/venv"
"$INSTALL_DIR/venv/bin/pip" install --quiet --upgrade pip
"$INSTALL_DIR/venv/bin/pip" install --quiet -r "$INSTALL_DIR/requirements.txt"
ok "Dependências Python instaladas"

# Config
if [[ ! -f "$INSTALL_DIR/config.toml" ]]; then
  cp "$SCRIPT_DIR/config.template.toml" "$INSTALL_DIR/config.toml"
  ok "config.toml criado a partir do template"
else
  ok "config.toml já existe — mantido sem alterações"
fi

# Permissões
chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
chmod 640 "$INSTALL_DIR/config.toml"
ok "Permissões definidas"

# ── Agent Key ─────────────────────────────────────────────────
if [[ -z "$AGENT_KEY" ]]; then
  echo ""
  echo -e "  ${YELLOW}Você precisa de uma Agent Key do dashboard go2mine.${RESET}"
  echo -e "  Acesse: ${CYAN}${DASHBOARD_URL}${RESET} → Configurações → Chaves do Agente"
  echo ""
  read -rp "  Cole sua Agent Key aqui (ou ENTER para pular): " AGENT_KEY
fi

if [[ -n "$AGENT_KEY" ]]; then
  sed -i "s|agent_key.*=.*|agent_key = \"${AGENT_KEY}\"|" "$INSTALL_DIR/config.toml"
  ok "Agent Key configurada"
else
  warn "Agent Key não configurada. Edite $INSTALL_DIR/config.toml antes de iniciar o serviço."
fi

# ── Serviço systemd ───────────────────────────────────────────
hdr "5/6  Registrando serviço systemd"

cat > /etc/systemd/system/${SERVICE_NAME}.service << EOF
[Unit]
Description=go2mine hashfarm-agent — ASIC Mining Monitor
Documentation=${DASHBOARD_URL}
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/venv/bin/python -m agent.main
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=${SERVICE_NAME}

# Segurança
PrivateTmp=true
NoNewPrivileges=true
ProtectSystem=strict
ReadWritePaths=${INSTALL_DIR}

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
ok "Serviço systemd registrado e habilitado"

# ── Inicia o serviço ──────────────────────────────────────────
hdr "6/6  Iniciando o agente"

if [[ -n "$AGENT_KEY" ]]; then
  systemctl start "$SERVICE_NAME"
  sleep 2
  if ! systemctl is-active --quiet "$SERVICE_NAME"; then
    warn "Serviço não está ativo — verifique: journalctl -u ${SERVICE_NAME} -n 20"
  fi

  echo ""
  hdr "Aguardando conexão do agente ao dashboard..."
  TIMEOUT=60
  INTERVAL=2
  ELAPSED=0
  ONLINE=0
  LAST_LOGGED=-1
  while [[ $ELAPSED -lt $TIMEOUT ]]; do
    RESP=$(curl -fsS --max-time 5 "${DASHBOARD_URL}/api/v1/farms/validate-key?key=${AGENT_KEY}" 2>/dev/null || true)
    if [[ "$RESP" == *'"agent_connected":true'* ]]; then
      ok "Agente ONLINE! Conectado ao dashboard em ${ELAPSED}s."
      ONLINE=1
      break
    fi
    sleep $INTERVAL
    ELAPSED=$((ELAPSED + INTERVAL))
    BUCKET=$((ELAPSED / 10))
    if [[ $BUCKET -gt $LAST_LOGGED ]]; then
      LAST_LOGGED=$BUCKET
      echo "  ... ainda aguardando (${ELAPSED}/${TIMEOUT}s)"
    fi
  done

  if [[ $ONLINE -eq 0 ]]; then
    warn "Agente não apareceu online em ${TIMEOUT}s. Verifique:"
    echo "    1. Firewall/proxy: agente precisa acessar ${DASHBOARD_URL} (443)"
    echo "    2. Log do serviço:  journalctl -u ${SERVICE_NAME} -n 30"
    echo "    3. Reiniciar:       sudo systemctl restart ${SERVICE_NAME}"
  fi
else
  warn "Agente NÃO iniciado — configure a Agent Key primeiro."
  echo ""
  echo "  Após configurar o config.toml, execute:"
  echo -e "  ${CYAN}sudo systemctl start ${SERVICE_NAME}${RESET}"
fi

# ── Resumo ───────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}══════════════════════════════════════════${RESET}"
echo -e "${BOLD}  Instalação concluída!  (v${AGENT_VERSION})${RESET}"
echo -e "${BOLD}${GREEN}══════════════════════════════════════════${RESET}"
echo ""
echo -e "  ${BOLD}Diretório:${RESET}    $INSTALL_DIR"
echo -e "  ${BOLD}Config:${RESET}       $INSTALL_DIR/config.toml"
echo -e "  ${BOLD}Logs:${RESET}         journalctl -u $SERVICE_NAME -f"
echo -e "  ${BOLD}Status:${RESET}       systemctl status $SERVICE_NAME"
echo -e "  ${BOLD}Parar:${RESET}        sudo systemctl stop $SERVICE_NAME"
echo -e "  ${BOLD}Dashboard:${RESET}    $DASHBOARD_URL"
echo ""
echo -e "  ${CYAN}Próximos passos:${RESET}"
echo -e "  1. Edite $INSTALL_DIR/config.toml e adicione seus mineradores"
echo -e "  2. Acesse ${DASHBOARD_URL} e faça login"
echo -e "  3. Seus ASICs aparecerão automaticamente no dashboard"
echo ""
