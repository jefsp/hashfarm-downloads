#!/usr/bin/env bash
# go2mine hashfarm-agent — Reiniciar agente Linux
# Uso: sudo bash restart-linux.sh
set -euo pipefail

SERVICE_NAME="hashfarm-agent"

RESET='\033[0m'; BOLD='\033[1m'
GREEN='\033[0;32m'; CYAN='\033[0;36m'; RED='\033[0;31m'; YELLOW='\033[1;33m'
ok()   { echo -e "${GREEN}✔${RESET}  $*"; }
info() { echo -e "${CYAN}→${RESET}  $*"; }
warn() { echo -e "${YELLOW}⚠${RESET}  $*"; }
die()  { echo -e "${RED}✖${RESET}  $*" >&2; exit 1; }

[[ $EUID -ne 0 ]] && die "Execute como root: sudo bash $0"

echo -e "\n${BOLD}  go2mine hashfarm-agent — Reiniciar${RESET}\n"

info "Parando o agente..."
systemctl stop "$SERVICE_NAME" 2>/dev/null || true
ok "Agente parado"

info "Iniciando o agente..."
systemctl start "$SERVICE_NAME"
sleep 2

if systemctl is-active --quiet "$SERVICE_NAME"; then
    ok "Agente reiniciado com sucesso!"
else
    warn "Verifique o status: journalctl -u $SERVICE_NAME -n 20"
fi

INSTALL_DIR=$(grep -oP '(?<=WorkingDirectory=).*' /etc/systemd/system/${SERVICE_NAME}.service 2>/dev/null || echo "/opt/hashfarm-agent")
VERSION=$(grep '__version__' "$INSTALL_DIR/agent/__init__.py" 2>/dev/null | grep -o '[0-9]\+\.[0-9]\+\.[0-9]\+' || echo "desconhecida")

echo ""
echo -e "${BOLD}  Versao: v${VERSION}${RESET}"
echo -e "  Acesse https://app.go2mine.com para confirmar"
echo -e "  que o agente esta online."
echo ""
