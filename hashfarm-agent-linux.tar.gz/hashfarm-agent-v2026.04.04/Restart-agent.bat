@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~s0\"' -Verb RunAs"
    exit /b
)
echo Reiniciando agente go2mine...
echo.
powershell -NonInteractive -WindowStyle Hidden -Command "$log='C:\hashfarm-agent\restart.log'; $ts=[datetime]::Now.ToString('yyyy-MM-dd HH:mm:ss'); Add-Content $log \"$ts [INFO] Reiniciando agente...\""
schtasks /End /TN "go2mine hashfarm-agent" >nul 2>&1
timeout /t 2 /nobreak >nul
schtasks /Run /TN "go2mine hashfarm-agent"
if %errorlevel% neq 0 (
    echo.
    echo [ERRO] Nao foi possivel reiniciar. O agente pode nao estar instalado.
    echo Tente rodar Install-agent.bat primeiro.
    powershell -NonInteractive -WindowStyle Hidden -Command "$log='C:\hashfarm-agent\restart.log'; $ts=[datetime]::Now.ToString('yyyy-MM-dd HH:mm:ss'); Add-Content $log \"$ts [ERRO] Falha ao iniciar tarefa agendada.\""
) else (
    echo.
    echo Agente reiniciado com sucesso!
    powershell -NonInteractive -WindowStyle Hidden -Command "$log='C:\hashfarm-agent\restart.log'; $ts=[datetime]::Now.ToString('yyyy-MM-dd HH:mm:ss'); Add-Content $log \"$ts [OK] Agente reiniciado com sucesso.\""
)
pause
