"""
hashfarm-agent · whatsminer.py · v1.0
Cliente assíncrono para a API Whatsminer (MicroBT).

Suporta dois protocolos:
  - TCP port 4028: todos os modelos (M20, M30, M50, M60...)
  - HTTP port 80:  modelos mais novos com webserver ativo

Autenticação:
  - M20/M30 mais antigos: sem autenticação no TCP
  - M30S+/M50+: token via comando "get_token" no TCP, depois assina com MD5
  - Não implementamos AES (M50+ firmware recente) nesta versão

O método extract_kpis() retorna o mesmo schema do VnishClient.extract_kpis()
para que o restante do agente não precise saber qual firmware está rodando.
"""

import asyncio
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("hashfarm.whatsminer")

TCP_PORT     = 4028
TCP_TIMEOUT  = 10
TOKEN_TTL    = 30 * 60  # 30 min


@dataclass
class WhatsminerConfig:
    ip: str
    port: int = TCP_PORT
    password: str = "admin"


@dataclass
class _TokenEntry:
    token: str
    expires_at: float


class WhatsminerClient:
    """
    Cliente TCP assíncrono para a API Whatsminer.
    Uma instância por sessão (compartilhada entre mineradores).
    """

    def __init__(self):
        self._tokens: dict[str, _TokenEntry] = {}
        self._locks:  dict[str, asyncio.Lock] = {}

    def _lock(self, ip: str) -> asyncio.Lock:
        if ip not in self._locks:
            self._locks[ip] = asyncio.Lock()
        return self._locks[ip]

    def _token_valid(self, ip: str) -> bool:
        e = self._tokens.get(ip)
        return bool(e and e.expires_at > time.time() + 60)

    # ── TCP helpers ──────────────────────────────────────────────────────────

    async def _tcp_send(self, ip: str, port: int, payload: dict) -> Optional[dict]:
        """Abre conexão TCP, envia JSON, lê resposta e fecha."""
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(ip, port), timeout=TCP_TIMEOUT
            )
            data = json.dumps(payload).encode()
            writer.write(data)
            await writer.drain()

            buf = b""
            while True:
                chunk = await asyncio.wait_for(reader.read(4096), timeout=TCP_TIMEOUT)
                if not chunk:
                    break
                buf += chunk
                # Whatsminer termina a resposta com \x00
                if b"\x00" in buf:
                    buf = buf.rstrip(b"\x00")
                    break

            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass

            return json.loads(buf.decode(errors="replace"))

        except asyncio.TimeoutError:
            log.debug(f"[{ip}] TCP timeout")
            return None
        except ConnectionRefusedError:
            log.debug(f"[{ip}] TCP conexão recusada")
            return None
        except Exception as e:
            log.debug(f"[{ip}] TCP erro: {e}")
            return None

    # ── Autenticação ─────────────────────────────────────────────────────────

    async def _get_token(self, cfg: WhatsminerConfig) -> Optional[str]:
        """
        Obtém token de sessão via comando get_token.
        Modelos mais antigos retornam token vazio — isso é normal.
        """
        async with self._lock(cfg.ip):
            if self._token_valid(cfg.ip):
                return self._tokens[cfg.ip].token

            resp = await self._tcp_send(cfg.ip, cfg.port, {"cmd": "get_token"})
            if not resp:
                return None

            msg = resp.get("Msg", {})
            if isinstance(msg, str):
                # Firmware antigo: sem autenticação necessária
                token = ""
            else:
                token = msg.get("token", "")

            self._tokens[cfg.ip] = _TokenEntry(token, time.time() + TOKEN_TTL)
            log.debug(f"[{cfg.ip}] Token obtido: {'(vazio)' if not token else token[:8]+'...'}")
            return token

    def _sign(self, token: str, password: str) -> str:
        """Assina o comando com MD5(token + password)."""
        return hashlib.md5(f"{token}{password}".encode()).hexdigest()

    # ── Comandos públicos ────────────────────────────────────────────────────

    async def send(self, cfg: WhatsminerConfig, cmd: str, extra: Optional[dict] = None) -> Optional[dict]:
        """
        Envia comando autenticado.
        Modelos sem token funcionam com envio direto.
        """
        token = await self._get_token(cfg)
        if token is None:
            return None

        payload: dict = {"cmd": cmd}
        if extra:
            payload.update(extra)

        if token:
            payload["token"] = self._sign(token, cfg.password)

        resp = await self._tcp_send(cfg.ip, cfg.port, payload)

        # Token expirado → invalida e tenta de novo uma vez
        if resp and resp.get("STATUS", [{}])[0].get("Code") in (14, 23):
            self._tokens.pop(cfg.ip, None)
            token = await self._get_token(cfg)
            if token:
                payload["token"] = self._sign(token, cfg.password)
                resp = await self._tcp_send(cfg.ip, cfg.port, payload)

        return resp


class WhatsminerPoller:
    """
    Coleta dados de um Whatsminer via TCP e normaliza para o schema padrão.
    """

    def __init__(self, client: WhatsminerClient):
        self.client = client

    async def poll(self, cfg: WhatsminerConfig) -> dict:
        """Coleta summary, pools e devs em paralelo."""
        summary_task = self.client.send(cfg, "summary")
        pools_task   = self.client.send(cfg, "pools")
        devs_task    = self.client.send(cfg, "devs")

        summary, pools, devs = await asyncio.gather(
            summary_task, pools_task, devs_task, return_exceptions=False
        )

        return {
            "ip":      cfg.ip,
            "ts":      int(time.time()),
            "summary": summary,
            "pools":   pools,
            "devs":    devs,
        }

    def extract_kpis(self, raw: dict) -> dict:
        """
        Converte resposta Whatsminer para o schema padrão do HashFarm.
        Mesmo contrato do VnishClient.extract_kpis().
        """
        ip  = raw["ip"]
        ts  = raw["ts"]
        _offline = {
            "ip": ip, "ts": ts, "status": "offline",
            "hr_realtime_ths": None, "hr_stock_ths": None, "hr_average_ths": None,
            "chip_temp_max": None, "chip_temp_min": None, "pcb_temp_max": None,
            "fan_duty": None, "fans": [], "power_w": None,
            "efficiency_w_th": None, "hw_errors_pct": None,
            "pools": [], "chains": [], "model": None,
            "fw_version": None, "uptime": None,
            "alarms": ["offline"], "firmware": "whatsminer",
        }

        summary = raw.get("summary")
        if not summary:
            return _offline

        # A resposta TCP tem formato: {"STATUS":[...], "SUMMARY":[{...}], "id":1}
        s_list = summary.get("SUMMARY", [])
        if not s_list:
            return _offline
        s = s_list[0]

        # ── Hashrate ────────────────────────────────────────────────────────
        # Whatsminer reporta em GH/s (MHS 5s, MHS av, GHS 5s, GHS av...)
        def _to_ths(val_ghs: Optional[float]) -> Optional[float]:
            return round(val_ghs / 1000, 4) if val_ghs is not None else None

        hr_rt  = _to_ths(s.get("GHS 5s") or s.get("MHS 5s") and s.get("MHS 5s") / 1000)
        hr_avg = _to_ths(s.get("GHS av") or s.get("MHS av") and s.get("MHS av") / 1000)

        # ── Temperatura ─────────────────────────────────────────────────────
        temp_max = s.get("Temperature") or s.get("Temp") or None

        # ── Fan ─────────────────────────────────────────────────────────────
        fan1 = s.get("Fan Speed In",  s.get("Fan1 Speed", 0))
        fan2 = s.get("Fan Speed Out", s.get("Fan2 Speed", 0))
        fans = []
        if fan1: fans.append({"id": 1, "rpm": int(fan1), "status": "ok"})
        if fan2: fans.append({"id": 2, "rpm": int(fan2), "status": "ok"})
        # Duty estimado pela velocidade máxima padrão (6000 RPM)
        max_rpm = max((f["rpm"] for f in fans), default=0)
        fan_duty = round(max_rpm / 6000 * 100) if max_rpm else None

        # ── Status ──────────────────────────────────────────────────────────
        elapsed = s.get("Elapsed", 0)
        status = "mining" if (hr_rt and hr_rt > 0) else ("init" if elapsed < 120 else "idle")

        # ── HW Errors ───────────────────────────────────────────────────────
        hw_err = s.get("Hardware Errors")
        accepted = s.get("Accepted", 1)
        hw_errors_pct = round(hw_err / max(accepted, 1) * 100, 2) if hw_err is not None else None

        # ── Pools ────────────────────────────────────────────────────────────
        pools_data = raw.get("pools", {})
        pools_list = pools_data.get("POOLS", []) if pools_data else []
        pools_norm = []
        for p in pools_list:
            pools_norm.append({
                "url":        p.get("URL", ""),
                "user":       p.get("User", ""),
                "status":     "active" if p.get("Stratum Active") else "backup",
                "accepted":   p.get("Accepted", 0),
                "rejected":   p.get("Rejected", 0),
                "pool_type":  "UserPool",
            })

        # ── Power ────────────────────────────────────────────────────────────
        power_w = s.get("Power") or s.get("Power Use") or None

        return {
            "ip":              ip,
            "ts":              ts,
            "status":          status,
            "hr_realtime_ths": hr_rt,
            "hr_stock_ths":    None,       # Whatsminer não expõe stock via API
            "hr_average_ths":  hr_avg,
            "chip_temp_max":   temp_max,
            "chip_temp_min":   None,
            "pcb_temp_max":    None,
            "fan_duty":        fan_duty,
            "fans":            fans,
            "power_w":         power_w,
            "efficiency_w_th": round(power_w / hr_rt, 2) if (power_w and hr_rt) else None,
            "hw_errors_pct":   hw_errors_pct,
            "pools":           pools_norm,
            "chains":          [],         # populado na Etapa 2 via "devs"
            "model":           s.get("Type") or s.get("model"),
            "fw_version":      s.get("CompileTime") or s.get("fw_version"),
            "uptime":          elapsed,
            "alarms":          [],
            "firmware":        "whatsminer",
        }
