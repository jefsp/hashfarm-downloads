@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)
echo Reiniciando agente go2mine...
schtasks /End /TN "go2mine hashfarm-agent" >nul 2>&1
timeout /t 2 /nobreak >nul
schtasks /Run /TN "go2mine hashfarm-agent"
echo Agente reiniciado com sucesso!
timeout /t 3 /nobreak >nul
