import asyncio
import json
import logging
import os
import time
from pathlib import Path

log = logging.getLogger("hashfarm.pool_guard")


def _flag(name: str) -> bool:
    return os.environ.get(name, "0").strip().lower() in ("1", "true", "yes", "on")


_RESTORE_COOLDOWN = 180


def _is_devfee(p: dict) -> bool:
    return str(p.get("pool_type", "UserPool")).lower() in ("devfee", "refund")


def _valid_worker(user: str) -> bool:
    u = (user or "").strip()
    return bool(u) and "." in u


class PoolGuard:
    def __init__(self, store_path: str | None = None):
        self.enabled = _flag("POOL_GUARD_ENABLED")
        self.dry_run = _flag("POOL_GUARD_DRYRUN")
        self.path = Path(store_path or os.environ.get("POOL_GUARD_FILE", "pool_guard.json"))
        self._mem: dict[str, dict] = {}
        self._last_restore: dict[str, float] = {}
        self._load()
        if self.enabled:
            log.info(f"PoolGuard ATIVO (dry_run={self.dry_run}) store={self.path} conhecidas={len(self._mem)}")

    def _load(self):
        try:
            if self.path.exists():
                self._mem = json.loads(self.path.read_text())
        except Exception as e:
            log.warning(f"PoolGuard load falhou: {e}")
            self._mem = {}

    def _save(self):
        try:
            self.path.write_text(json.dumps(self._mem))
        except Exception as e:
            log.warning(f"PoolGuard save falhou: {e}")

    @staticmethod
    def _user_pools(pools) -> list[dict]:
        out = []
        for p in (pools or []):
            if _is_devfee(p):
                continue
            url = (p.get("url") or "").strip()
            user = (p.get("user") or "").strip()
            if url and user:
                out.append({"url": url, "user": user, "pass": (p.get("pass") or p.get("password") or "x")})
        return out

    async def observe(self, miner, firmware, pools, pool_manager, miner_kw_fn):
        if not self.enabled:
            return
        ip = getattr(miner, "ip", miner)
        try:
            ups = self._user_pools(pools)
            if ups:
                good = [p for p in ups if _valid_worker(p["user"])]
                if good and self._mem.get(ip, {}).get("pools") != good:
                    self._mem[ip] = {"pools": good, "fw": firmware, "ts": int(time.time())}
                    self._save()
                    log.info(f"[{ip}] PoolGuard aprendeu/atualizou pool ({len(good)}) worker={good[0]['user']}")
                return

            saved = self._mem.get(ip, {}).get("pools")
            if not saved:
                return
            now = time.time()
            if now - self._last_restore.get(ip, 0) < _RESTORE_COOLDOWN:
                return
            self._last_restore[ip] = now
            worker = saved[0]["user"]
            if self.dry_run:
                log.warning(f"[{ip}] PoolGuard DRY-RUN: restauraria pool (fw={firmware}) worker={worker}")
                return
            log.warning(f"[{ip}] PoolGuard: SEM pool -> restaurando (fw={firmware}) worker={worker}")
            # Stock: cgminer addpool e' RUNTIME (nao persiste, a maquina reverte).
            # set_miner_conf.cgi grava na config E reinicia o cgminer -> persiste.
            if firmware == "bitmain_stock" and hasattr(miner, "ip"):
                ok = await self._restore_stock(miner, saved)
            else:
                ok = await pool_manager.restore_pools(ip, firmware, saved, **miner_kw_fn(ip))
            log.warning(f"[{ip}] PoolGuard restore -> {ok}")
        except Exception as e:
            log.debug(f"[{ip}] PoolGuard observe erro: {e}")

    async def _restore_stock(self, miner, saved) -> bool:
        from .bitmain import _http_request_with_auth
        import json as _json
        ip = miner.ip
        user = getattr(miner, "user", None) or "root"
        pw = getattr(miner, "password", None) or "root"
        st, txt = await _http_request_with_auth("GET", ip, "/cgi-bin/get_miner_conf.cgi", user, pw, timeout=8)
        if st != 200 or not txt:
            log.warning(f"[{ip}] PoolGuard stock: get_miner_conf status={st}")
            return False
        try:
            cfg = _json.loads(txt)
        except Exception as e:
            log.warning(f"[{ip}] PoolGuard stock: parse config falhou: {e}")
            return False

        def _norm(u):
            u = (u or "").strip()
            if not u:
                return u
            return u if u.startswith("stratum") else "stratum+tcp://" + u

        pools3 = [{"url": _norm(p.get("url")), "user": p.get("user", ""), "pass": p.get("pass") or "x"}
                  for p in saved[:3]]
        while len(pools3) < 3:
            pools3.append({"url": "", "user": "", "pass": ""})
        cfg["pools"] = pools3
        body = _json.dumps(cfg).encode()
        st2, txt2 = await _http_request_with_auth(
            "POST", ip, "/cgi-bin/set_miner_conf.cgi", user, pw,
            data=body, headers={"Content-Type": "application/json"}, timeout=15)
        ok = st2 == 200 and "M000" in (txt2 or "")
        log.warning(f"[{ip}] PoolGuard stock set_miner_conf status={st2} ok={ok}")
        return ok
