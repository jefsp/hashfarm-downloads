"""
hashfarm-agent · main.py · v1.2
Entry point. Orquestra collector standalone (sem cloud) e
CloudConnector (on-demand quando há sessão ativa).

Modo de operação:
  - Se cloud.agent_key estiver configurado → usa CloudConnector (on-demand)
  - Se não → modo standalone, coleta local e grava no SQLite
"""

import asyncio
import logging
import os
import signal
import socket
import sys

from .config import load_config
from .store import LocalStore

_LOCK_PORT = 47832
_lock_socket: socket.socket | None = None


def _acquire_instance_lock() -> bool:
    global _lock_socket
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
    try:
        s.bind(("127.0.0.1", _LOCK_PORT))
        _lock_socket = s
        return True
    except OSError:
        s.close()
        return False


def _release_instance_lock():
    global _lock_socket
    if _lock_socket:
        _lock_socket.close()
        _lock_socket = None


def _restart_self():
    import platform as _pf
    if _pf.system() == "Windows":
        os.execv(sys.executable, [sys.executable, "-m", "agent.main"])
    else:
        os.execv(sys.executable, [sys.executable, "-m", "agent.main"])


def setup_logging(level: str):
    import os
    from logging.handlers import RotatingFileHandler
    fmt = "%(asctime)s [%(levelname)s] %(name)s - %(message)s"
    log_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    log_path = os.path.join(log_dir, "agent.log")
    file_handler = RotatingFileHandler(log_path, maxBytes=2*1024*1024, backupCount=3, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter(fmt))
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(logging.Formatter(fmt))
    logging.basicConfig(
        level=getattr(logging, level, logging.INFO),
        handlers=[file_handler, stream_handler],
    )
    logging.getLogger("aiohttp").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    logging.getLogger("websockets").setLevel(logging.WARNING)


async def main():
    if not _acquire_instance_lock():
        print("Outra instância já está em execução. Saindo.")
        sys.exit(0)

    from .updater import check_rollback, apply_pending_update, confirm_update_success

    if check_rollback():
        _release_instance_lock()
        _restart_self()
        return

    if apply_pending_update():
        _release_instance_lock()
        _restart_self()
        return

    cfg = load_config()
    setup_logging(cfg.log_level)

    log = logging.getLogger("hashfarm.main")
    from . import __version__
    log.info(f"HashFarm Agent v{__version__} iniciando…")

    if not cfg.miners:
        log.warning("Nenhum minerador em config.toml nem no cache local. Aguardando miners_updated do servidor.")

    store = LocalStore(path=cfg.store.path, max_queue=cfg.store.max_queue)

    loop = asyncio.get_event_loop()
    stop_event = asyncio.Event()

    def _shutdown():
        log.info("Encerrando…")
        stop_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _shutdown)
        except (NotImplementedError, RuntimeError):
            # Windows não suporta add_signal_handler — usa signal.signal como fallback
            signal.signal(sig, lambda *_: stop_event.set())

    asyncio.create_task(confirm_update_success())

    tasks = []

    if cfg.cloud.agent_key:
        log.info(f"Modo cloud → {cfg.cloud.url}")
        from .cloud import CloudConnector
        connector = CloudConnector(cfg, store)
        tasks.append(asyncio.create_task(connector.run_forever(), name="cloud"))

    else:
        log.info("Modo standalone (sem cloud.agent_key configurado)")
        from .collector import Collector

        async def _run_standalone():
            async with Collector(cfg, store) as col:
                col.on_snapshot = lambda kpis: log.debug(
                    f"  {kpis.get('label', kpis['ip'])} [{kpis.get('status')}] "
                    f"hr={kpis.get('hr_realtime_ths')} TH/s"
                )
                await col.run_forever()

        tasks.append(asyncio.create_task(_run_standalone(), name="standalone"))

    await stop_event.wait()

    for t in tasks:
        t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)

    store.close()
    log.info("Agente encerrado.")


def run():
    asyncio.run(main())


if __name__ == "__main__":
    run()
