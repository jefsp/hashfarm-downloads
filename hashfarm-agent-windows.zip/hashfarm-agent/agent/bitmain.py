"""
hashfarm-agent · bitmain.py
Suporte ao firmware stock do Bitmain Antminer via CGMiner API (TCP 4028).

IMPORTANTE: CGMiner usa {"command": "..."}, Whatsminer usa {"cmd": "..."}.
Implementamos um cliente próprio para não confundir os dois protocolos.
"""
import asyncio
import hashlib
import json
import logging
import re
import time
import uuid
from typing import Optional

import aiohttp

log = logging.getLogger("hashfarm.bitmain")

TCP_PORT    = 4028
TCP_TIMEOUT = 5

_ANTMINER_STOCK: dict[str, float] = {
    "S9i": 14.0, "S9j": 14.5, "S9": 13.5,
    "S17+": 73.0, "S17 Pro": 53.0, "S17e": 64.0, "S17": 56.0,
    "S19 XP": 140.0, "S19k Pro": 120.0, "S19j Pro": 100.0,
    "S19j": 90.0, "S19 Pro": 110.0, "S19": 95.0,
    "S21 Pro": 234.0, "S21": 200.0,
    "T19": 84.0, "T21": 162.0,
    "KS5 Pro": 21.0, "KS5L": 12.0, "KS5M": 15.0, "KS5": 20.0,
    "KS3M": 6.0, "KS3": 9.4,
}


def _lookup_antminer_stock(model: Optional[str]) -> Optional[float]:
    if not model:
        return None
    m = model.upper()
    for key in sorted(_ANTMINER_STOCK, key=len, reverse=True):
        if key.upper() in m:
            return _ANTMINER_STOCK[key]
    return None


def _digest_auth_header(www_auth: str, user: str, pw: str, method: str, path: str) -> Optional[str]:
    realm = re.search(r'realm="([^"]+)"', www_auth)
    nonce = re.search(r'nonce="([^"]+)"', www_auth)
    qop = re.search(r'qop="?([^",\s]+)"?', www_auth)
    if not (realm and nonce):
        return None
    realm_v = realm.group(1)
    nonce_v = nonce.group(1)
    qop_v = qop.group(1) if qop else ""
    ha1 = hashlib.md5(f"{user}:{realm_v}:{pw}".encode()).hexdigest()
    ha2 = hashlib.md5(f"{method}:{path}".encode()).hexdigest()
    cnonce = uuid.uuid4().hex[:16]
    nc = "00000001"
    if qop_v:
        resp_h = hashlib.md5(f"{ha1}:{nonce_v}:{nc}:{cnonce}:{qop_v}:{ha2}".encode()).hexdigest()
        return (
            f'Digest username="{user}", realm="{realm_v}", '
            f'nonce="{nonce_v}", uri="{path}", qop={qop_v}, '
            f'nc={nc}, cnonce="{cnonce}", response="{resp_h}"'
        )
    resp_h = hashlib.md5(f"{ha1}:{nonce_v}:{ha2}".encode()).hexdigest()
    return (
        f'Digest username="{user}", realm="{realm_v}", '
        f'nonce="{nonce_v}", uri="{path}", response="{resp_h}"'
    )


async def _http_request_with_auth(
    method: str, ip: str, path: str, user: str, pw: str,
    *, data=None, headers: Optional[dict] = None, timeout: int = 5,
) -> tuple[int, str]:
    """HTTP com Basic + fallback Digest. Retorna (status, body)."""
    url = f"http://{ip}{path}"
    cli_timeout = aiohttp.ClientTimeout(total=timeout)
    try:
        auth = aiohttp.BasicAuth(user, pw)
        async with aiohttp.ClientSession(timeout=cli_timeout) as s:
            async with s.request(method, url, data=data, auth=auth, headers=headers) as r:
                txt = await r.text()
                if r.status not in (401,):
                    return r.status, txt
    except Exception as e:
        log.debug(f"[{ip}] http {method} {path} basic erro: {e}")

    try:
        connector = aiohttp.TCPConnector(force_close=True)
        async with aiohttp.ClientSession(timeout=cli_timeout, connector=connector) as s:
            async with s.request(method, url, data=data, headers=headers) as r1:
                if r1.status != 401:
                    return r1.status, await r1.text()
                ha = r1.headers.get("WWW-Authenticate", "")
                if "Digest" not in ha:
                    return r1.status, await r1.text()
                hdr = _digest_auth_header(ha, user, pw, method, path)
                if not hdr:
                    return r1.status, await r1.text()
                merged = dict(headers or {})
                merged["Authorization"] = hdr
                async with s.request(method, url, data=data, headers=merged) as r2:
                    return r2.status, await r2.text()
    except Exception as e:
        log.debug(f"[{ip}] http {method} {path} digest erro: {e}")
        return 0, ""


async def query_blink_status(ip: str, user: str, pw: str, timeout: int = 4) -> Optional[bool]:
    """Le o estado atual do LED locator do Antminer Stock.
    Endpoint conhecido: GET /cgi-bin/get_blink_status.cgi -> {"blink": true|false}
    Retorna None se a leitura falhar.
    """
    status, body = await _http_request_with_auth(
        "GET", ip, "/cgi-bin/get_blink_status.cgi",
        user or "root", pw or "root", timeout=timeout,
    )
    if status not in (200, 204) or not body:
        return None
    try:
        d = json.loads(body)
        v = d.get("blink") if isinstance(d, dict) else None
        if isinstance(v, bool):
            return v
        if isinstance(v, str):
            return v.strip().lower() in ("true", "1", "yes", "on")
        if isinstance(v, (int, float)):
            return bool(v)
    except Exception:
        bl = body.strip().lower()
        if "true" in bl or '"blink":1' in bl:
            return True
        if "false" in bl or '"blink":0' in bl:
            return False
    return None


async def cgminer_send(ip: str, port: int, command: str, timeout: int = TCP_TIMEOUT) -> Optional[dict]:
    """Envia comando CGMiner ({"command": "..."}) via TCP e retorna resposta JSON."""
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(ip, port), timeout=timeout
        )
        writer.write(json.dumps({"command": command}).encode())
        await writer.drain()

        buf = b""
        while True:
            chunk = await asyncio.wait_for(reader.read(4096), timeout=timeout)
            if not chunk:
                break
            buf += chunk
            if b"\x00" in buf:
                buf = buf.rstrip(b"\x00")
                break

        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass

        return json.loads(buf.decode(errors="replace"))

    except asyncio.TimeoutError:
        log.debug(f"[{ip}] CGMiner TCP timeout")
        return None
    except ConnectionRefusedError:
        log.debug(f"[{ip}] CGMiner TCP recusado")
        return None
    except Exception as e:
        log.debug(f"[{ip}] CGMiner TCP erro: {e}")
        return None


class BitmainStockPoller:
    async def poll(self, ip: str, port: int = TCP_PORT) -> dict:
        multi = await cgminer_send(ip, port, "summary+devs+pools+version+stats", timeout=8)
        if multi and ("SUMMARY" in multi or "summary" in multi):
            return self._parse_multi(ip, multi)

        summary, pools, devs, version, stats = await asyncio.gather(
            cgminer_send(ip, port, "summary"),
            cgminer_send(ip, port, "pools"),
            cgminer_send(ip, port, "devs"),
            cgminer_send(ip, port, "version"),
            cgminer_send(ip, port, "stats"),
        )
        return {
            "ip": ip, "ts": int(time.time()),
            "summary": summary, "pools": pools,
            "devs": devs, "version": version, "stats": stats,
        }

    def _parse_multi(self, ip: str, data: dict) -> dict:
        def _get(key):
            for k in [key, key.lower(), key.upper()]:
                if k in data:
                    v = data[k]
                    return v[0] if isinstance(v, list) and len(v) == 1 else v
            return None

        summary = _get("summary")
        if isinstance(summary, list):
            summary = {"SUMMARY": summary}
        elif isinstance(summary, dict) and "SUMMARY" not in summary:
            summary = {"SUMMARY": [summary]}

        pools = _get("pools")
        if isinstance(pools, list):
            pools = {"POOLS": pools}

        devs = _get("devs")
        if isinstance(devs, list):
            devs = {"DEVS": devs}

        version = _get("version")
        if isinstance(version, list):
            version = {"VERSION": version}

        stats = _get("stats")
        if isinstance(stats, list):
            stats = {"STATS": stats}

        if summary is None and "SUMMARY" in data:
            summary = {"SUMMARY": data["SUMMARY"]}
        if pools is None and "POOLS" in data:
            pools = {"POOLS": data["POOLS"]}
        if devs is None and "DEVS" in data:
            devs = {"DEVS": data["DEVS"]}
        if version is None and "VERSION" in data:
            version = {"VERSION": data["VERSION"]}
        if stats is None and "STATS" in data:
            stats = {"STATS": data["STATS"]}

        return {
            "ip": ip, "ts": int(time.time()),
            "summary": summary, "pools": pools,
            "devs": devs, "version": version, "stats": stats,
        }

    def extract_kpis(self, raw: dict) -> dict:
        ip = raw["ip"]
        ts = raw["ts"]
        _offline = {
            "ip": ip, "ts": ts, "status": "offline",
            "hr_realtime_ths": None, "hr_stock_ths": None, "hr_average_ths": None,
            "chip_temp_max": None, "chip_temp_min": None, "pcb_temp_max": None,
            "fan_duty": None, "fans": [], "target_temp": None, "power_w": None,
            "efficiency_w_th": None, "hw_errors_pct": None,
            "pools": [], "chains": [], "model": None,
            "fw_version": None, "uptime": None,
            "alarms": ["offline"], "firmware": "bitmain_stock",
        }

        summary = raw.get("summary")
        if not summary:
            return _offline
        s_list = summary.get("SUMMARY", [])
        if not s_list:
            return _offline
        s = s_list[0]

        def _to_ths(val, unit="GH"):
            if val is None:
                return None
            try:
                val = float(val)
            except (ValueError, TypeError):
                return None
            return round(val / 1_000_000, 4) if unit == "MH" else round(val / 1000, 4)

        hr_rt  = _to_ths(s.get("GHS 5s")) or _to_ths(s.get("MHS 5s"), "MH")
        hr_avg = _to_ths(s.get("GHS av")) or _to_ths(s.get("MHS av"), "MH")
        elapsed = s.get("Elapsed", 0)
        status = "mining" if (hr_rt and hr_rt > 0) else ("init" if elapsed < 120 else "idle")

        ver_data = raw.get("version") or {}
        ver_list = ver_data.get("VERSION", [])
        ver = ver_list[0] if ver_list else {}
        model = ver.get("Type") or ver.get("Model")
        fw_version_str = ver.get("Miner") or ver.get("CompileTime")

        stock_ths = hr_avg if (hr_avg and hr_avg > 0) else (hr_rt if (hr_rt and hr_rt > 0) else _lookup_antminer_stock(model))

        stats_data = raw.get("stats") or {}
        stats_list = stats_data.get("STATS", [])
        temps = []
        board_temps: dict[int, float] = {}
        fans_map: dict[int, int] = {}
        fan_duty_raw = None
        target_temp_raw = None
        hot_temp_raw = None
        for st in stats_list:
            for k, v in st.items():
                kl = k.lower()
                if kl in ("temp_ctrl_target", "temp_target", "target_temp",
                         "target_temperature", "temp1_target"):
                    try:
                        tv = float(v)
                        if 30 <= tv <= 110:
                            target_temp_raw = tv
                    except (TypeError, ValueError):
                        pass
                    continue
                if kl in ("hot_temp", "hot_temperature", "temp_ctrl_hot"):
                    try:
                        hv = float(v)
                        if 30 <= hv <= 130:
                            hot_temp_raw = hv
                    except (TypeError, ValueError):
                        pass
                    continue
                if not isinstance(v, (int, float)) or v <= 0:
                    continue
                is_temp = kl.startswith("temp") or "_temp" in kl or "thermal" in kl
                if is_temp and 20 <= v <= 130:
                    temps.append(float(v))
                    try:
                        parts = kl.split("_")
                        idx = int(parts[-1]) - 1
                        if 0 <= idx < 10:
                            board_temps[idx] = max(board_temps.get(idx, 0.0), float(v))
                    except (ValueError, IndexError):
                        pass
                elif kl in ("fan_duty", "fanduty"):
                    fan_duty_raw = int(v)
                elif kl.startswith("fan") and kl[3:].isdigit():
                    fid = int(kl[3:])
                    fans_map[fid] = int(v)

        temp_max = max(temps) if temps else None
        temp_min = min(temps) if temps else None
        fans = [{"id": fid, "rpm": rpm, "status": "ok"} for fid, rpm in sorted(fans_map.items())][:4]
        max_rpm = max((f["rpm"] for f in fans), default=0)
        if fan_duty_raw is not None:
            fan_duty = fan_duty_raw
        else:
            ref_rpm = 6600 if max_rpm > 6000 else 6000
            fan_duty = round(max_rpm / ref_rpm * 100) if max_rpm else None

        hw_err = s.get("Hardware Errors")
        accepted = s.get("Accepted", 1)
        hw_errors_pct = round(hw_err / max(accepted, 1) * 100, 2) if hw_err is not None else None

        pools_raw = (raw.get("pools") or {}).get("POOLS", [])
        pools_norm = [{
            "url": p.get("URL", ""), "user": p.get("User", ""),
            "status": "active" if p.get("Stratum Active") else "backup",
            "accepted": p.get("Accepted", 0), "rejected": p.get("Rejected", 0),
            "diffa": p.get("Difficulty Accepted", 0),
            "pool_type": "UserPool",
        } for p in pools_raw]

        devs_list = (raw.get("devs") or {}).get("DEVS", [])
        chains = []
        for d in devs_list:
            hr_c = _to_ths(d.get("GHS 5s")) or _to_ths(d.get("MHS 5s"), "MH")
            board_idx = len(chains)
            chains.append({
                "index": d.get("ASC", board_idx),
                "hashrate_ths": hr_c,
                "temp_max": board_temps.get(board_idx) or None,
                "hw_errors": d.get("Hardware Errors", 0), "hw_err_pct": 0,
                "status": "ok" if hr_c and hr_c > 0 else "dead",
            })

        log.info(
            f"[{ip}] Bitmain: model={model} hr_rt={hr_rt} hr_avg={hr_avg} "
            f"stock={stock_ths} temp={temp_max} fans={[f['rpm'] for f in fans]} elapsed={elapsed}s chains={len(chains)}"
        )

        firmware_kind = "braiins" if any(
            k in (fw_version_str or "").lower()
            for k in ("braiins", "bosminer", "bos+", "bos_", "braiinos")
        ) else "bitmain_stock"

        return {
            "ip": ip, "ts": ts, "status": status,
            "hr_realtime_ths": hr_rt, "hr_stock_ths": stock_ths, "hr_average_ths": hr_avg,
            "chip_temp_max": temp_max, "chip_temp_min": temp_min, "pcb_temp_max": None,
            "fan_duty": fan_duty, "fans": fans,
            "target_temp": target_temp_raw, "hot_temp": hot_temp_raw,
            "power_w": None,
            "efficiency_w_th": None, "hw_errors_pct": hw_errors_pct,
            "pools": pools_norm, "chains": chains,
            "model": model, "fw_version": fw_version_str, "uptime": elapsed,
            "alarms": [], "firmware": firmware_kind,
        }
