"""
hashfarm-agent · bitmain.py
Suporte ao firmware stock do Bitmain Antminer via CGMiner API (TCP 4028).

IMPORTANTE: CGMiner usa {"command": "..."}, Whatsminer usa {"cmd": "..."}.
Implementamos um cliente próprio para não confundir os dois protocolos.
"""
import asyncio
import json
import logging
import time
from typing import Optional

log = logging.getLogger("hashfarm.bitmain")

TCP_PORT    = 4028
TCP_TIMEOUT = 5

_ANTMINER_STOCK: dict[str, float] = {
    "S9i": 14.0, "S9j": 14.5, "S9": 13.5,
    "S17+": 73.0, "S17 Pro": 53.0, "S17e": 64.0, "S17": 56.0,
    "S19 XP": 140.0, "S19k Pro": 120.0, "S19j Pro": 100.0,
    "S19j": 90.0, "S19 Pro": 110.0, "S19": 95.0,
    "S21 Pro": 234.0, "S21": 200.0,
    "T19": 84.0, "T21": 162.0,
    "KS5 Pro": 21.0, "KS5L": 12.0, "KS5M": 15.0, "KS5": 20.0,
    "KS3M": 6.0, "KS3": 9.4,
}


def _lookup_antminer_stock(model: Optional[str]) -> Optional[float]:
    if not model:
        return None
    m = model.upper()
    for key in sorted(_ANTMINER_STOCK, key=len, reverse=True):
        if key.upper() in m:
            return _ANTMINER_STOCK[key]
    return None


async def cgminer_send(ip: str, port: int, command: str, timeout: int = TCP_TIMEOUT) -> Optional[dict]:
    """Envia comando CGMiner ({"command": "..."}) via TCP e retorna resposta JSON."""
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(ip, port), timeout=timeout
        )
        writer.write(json.dumps({"command": command}).encode())
        await writer.drain()

        buf = b""
        while True:
            chunk = await asyncio.wait_for(reader.read(4096), timeout=timeout)
            if not chunk:
                break
            buf += chunk
            if b"\x00" in buf:
                buf = buf.rstrip(b"\x00")
                break

        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass

        return json.loads(buf.decode(errors="replace"))

    except asyncio.TimeoutError:
        log.debug(f"[{ip}] CGMiner TCP timeout")
        return None
    except ConnectionRefusedError:
        log.debug(f"[{ip}] CGMiner TCP recusado")
        return None
    except Exception as e:
        log.debug(f"[{ip}] CGMiner TCP erro: {e}")
        return None


class BitmainStockPoller:
    async def poll(self, ip: str, port: int = TCP_PORT) -> dict:
        multi = await cgminer_send(ip, port, "summary+devs+pools+version+stats", timeout=8)
        if multi and ("SUMMARY" in multi or "summary" in multi):
            return self._parse_multi(ip, multi)

        summary, pools, devs, version, stats = await asyncio.gather(
            cgminer_send(ip, port, "summary"),
            cgminer_send(ip, port, "pools"),
            cgminer_send(ip, port, "devs"),
            cgminer_send(ip, port, "version"),
            cgminer_send(ip, port, "stats"),
        )
        return {
            "ip": ip, "ts": int(time.time()),
            "summary": summary, "pools": pools,
            "devs": devs, "version": version, "stats": stats,
        }

    def _parse_multi(self, ip: str, data: dict) -> dict:
        def _get(key):
            for k in [key, key.lower(), key.upper()]:
                if k in data:
                    v = data[k]
                    return v[0] if isinstance(v, list) and len(v) == 1 else v
            return None

        summary = _get("summary")
        if isinstance(summary, list):
            summary = {"SUMMARY": summary}
        elif isinstance(summary, dict) and "SUMMARY" not in summary:
            summary = {"SUMMARY": [summary]}

        pools = _get("pools")
        if isinstance(pools, list):
            pools = {"POOLS": pools}

        devs = _get("devs")
        if isinstance(devs, list):
            devs = {"DEVS": devs}

        version = _get("version")
        if isinstance(version, list):
            version = {"VERSION": version}

        stats = _get("stats")
        if isinstance(stats, list):
            stats = {"STATS": stats}

        if summary is None and "SUMMARY" in data:
            summary = {"SUMMARY": data["SUMMARY"]}
        if pools is None and "POOLS" in data:
            pools = {"POOLS": data["POOLS"]}
        if devs is None and "DEVS" in data:
            devs = {"DEVS": data["DEVS"]}
        if version is None and "VERSION" in data:
            version = {"VERSION": data["VERSION"]}
        if stats is None and "STATS" in data:
            stats = {"STATS": data["STATS"]}

        return {
            "ip": ip, "ts": int(time.time()),
            "summary": summary, "pools": pools,
            "devs": devs, "version": version, "stats": stats,
        }

    def extract_kpis(self, raw: dict) -> dict:
        ip = raw["ip"]
        ts = raw["ts"]
        _offline = {
            "ip": ip, "ts": ts, "status": "offline",
            "hr_realtime_ths": None, "hr_stock_ths": None, "hr_average_ths": None,
            "chip_temp_max": None, "chip_temp_min": None, "pcb_temp_max": None,
            "fan_duty": None, "fans": [], "target_temp": None, "power_w": None,
            "efficiency_w_th": None, "hw_errors_pct": None,
            "pools": [], "chains": [], "model": None,
            "fw_version": None, "uptime": None,
            "alarms": ["offline"], "firmware": "bitmain_stock",
        }

        summary = raw.get("summary")
        if not summary:
            return _offline
        s_list = summary.get("SUMMARY", [])
        if not s_list:
            return _offline
        s = s_list[0]

        def _to_ths(val, unit="GH"):
            if val is None:
                return None
            try:
                val = float(val)
            except (ValueError, TypeError):
                return None
            return round(val / 1_000_000, 4) if unit == "MH" else round(val / 1000, 4)

        hr_rt  = _to_ths(s.get("GHS 5s")) or _to_ths(s.get("MHS 5s"), "MH")
        hr_avg = _to_ths(s.get("GHS av")) or _to_ths(s.get("MHS av"), "MH")
        elapsed = s.get("Elapsed", 0)
        status = "mining" if (hr_rt and hr_rt > 0) else ("init" if elapsed < 120 else "idle")

        ver_data = raw.get("version") or {}
        ver_list = ver_data.get("VERSION", [])
        ver = ver_list[0] if ver_list else {}
        model = ver.get("Type") or ver.get("Model")
        fw_version_str = ver.get("Miner") or ver.get("CompileTime")

        stock_ths = _lookup_antminer_stock(model)

        stats_data = raw.get("stats") or {}
        stats_list = stats_data.get("STATS", [])
        temps = []
        fans_map: dict[int, int] = {}
        fan_duty_raw = None
        target_temp_raw = None
        hot_temp_raw = None
        for st in stats_list:
            for k, v in st.items():
                kl = k.lower()
                if kl in ("temp_ctrl_target", "temp_target", "target_temp",
                         "target_temperature", "temp1_target"):
                    try:
                        tv = float(v)
                        if 30 <= tv <= 110:
                            target_temp_raw = tv
                    except (TypeError, ValueError):
                        pass
                    continue
                if kl in ("hot_temp", "hot_temperature", "temp_ctrl_hot"):
                    try:
                        hv = float(v)
                        if 30 <= hv <= 130:
                            hot_temp_raw = hv
                    except (TypeError, ValueError):
                        pass
                    continue
                if not isinstance(v, (int, float)) or v <= 0:
                    continue
                if kl.startswith("temp") and v < 200:
                    temps.append(float(v))
                elif kl in ("fan_duty", "fanduty"):
                    fan_duty_raw = int(v)
                elif kl.startswith("fan") and kl[3:].isdigit():
                    fid = int(kl[3:])
                    fans_map[fid] = int(v)

        temp_max = max(temps) if temps else None
        temp_min = min(temps) if temps else None
        fans = [{"id": fid, "rpm": rpm, "status": "ok"} for fid, rpm in sorted(fans_map.items())][:4]
        max_rpm = max((f["rpm"] for f in fans), default=0)
        if fan_duty_raw is not None:
            fan_duty = fan_duty_raw
        else:
            ref_rpm = 6600 if max_rpm > 6000 else 6000
            fan_duty = round(max_rpm / ref_rpm * 100) if max_rpm else None

        hw_err = s.get("Hardware Errors")
        accepted = s.get("Accepted", 1)
        hw_errors_pct = round(hw_err / max(accepted, 1) * 100, 2) if hw_err is not None else None

        pools_raw = (raw.get("pools") or {}).get("POOLS", [])
        pools_norm = [{
            "url": p.get("URL", ""), "user": p.get("User", ""),
            "status": "active" if p.get("Stratum Active") else "backup",
            "accepted": p.get("Accepted", 0), "rejected": p.get("Rejected", 0),
            "diffa": p.get("Difficulty Accepted", 0),
            "pool_type": "UserPool",
        } for p in pools_raw]

        devs_list = (raw.get("devs") or {}).get("DEVS", [])
        chains = []
        for d in devs_list:
            hr_c = _to_ths(d.get("GHS 5s")) or _to_ths(d.get("MHS 5s"), "MH")
            chains.append({
                "index": d.get("ASC", len(chains)),
                "hr_ths": hr_c, "chip_temp": None, "pcb_temp": None,
                "hw_errors": d.get("Hardware Errors", 0), "hw_err_pct": 0,
                "status": "ok" if hr_c and hr_c > 0 else "dead",
            })

        log.info(
            f"[{ip}] Bitmain: model={model} hr_rt={hr_rt} hr_avg={hr_avg} "
            f"stock={stock_ths} temp={temp_max} fans={[f['rpm'] for f in fans]} elapsed={elapsed}s chains={len(chains)}"
        )

        firmware_kind = "braiins" if any(
            k in (fw_version_str or "").lower()
            for k in ("braiins", "bosminer", "bos+", "bos_", "braiinos")
        ) else "bitmain_stock"

        return {
            "ip": ip, "ts": ts, "status": status,
            "hr_realtime_ths": hr_rt, "hr_stock_ths": stock_ths, "hr_average_ths": hr_avg,
            "chip_temp_max": temp_max, "chip_temp_min": temp_min, "pcb_temp_max": None,
            "fan_duty": fan_duty, "fans": fans,
            "target_temp": target_temp_raw, "hot_temp": hot_temp_raw,
            "power_w": None,
            "efficiency_w_th": None, "hw_errors_pct": hw_errors_pct,
            "pools": pools_norm, "chains": chains,
            "model": model, "fw_version": fw_version_str, "uptime": elapsed,
            "alarms": [], "firmware": firmware_kind,
        }
