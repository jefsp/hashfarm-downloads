"""
hashfarm-agent · devfee_tracker.py
Motor de billing proporcional continuo.
A cada ciclo de polling (~30s), decide se o miner deve estar
minerando no pool do usuario, da go2mine ou do representante.
"""

import logging
import time
from datetime import date
from typing import Optional

from .pool_manager import PoolManager, PoolTarget

log = logging.getLogger("hashfarm.devfee")


class MinerCycleState:
    __slots__ = (
        "date", "total_cycles", "devfee_cycles",
        "go2mine_cycles", "rep_cycles", "current_mode",
        "user_pools_saved",
    )

    def __init__(self):
        self.date: str = str(date.today())
        self.total_cycles: int = 0
        self.devfee_cycles: int = 0
        self.go2mine_cycles: int = 0
        self.rep_cycles: int = 0
        self.current_mode: str = "user"
        self.user_pools_saved: bool = False


class DevFeeTracker:
    def __init__(self, pool_manager: PoolManager, store=None):
        self._pm = pool_manager
        self._store = store
        self._states: dict[str, MinerCycleState] = {}
        self._billing_config: Optional[dict] = None

    def set_config(self, config: dict):
        self._billing_config = config
        log.info(f"[devfee] config atualizada: pct={config.get('user_devfee_pct')} enabled={config.get('enabled')}")

    @property
    def enabled(self) -> bool:
        return bool(self._billing_config and self._billing_config.get("enabled"))

    def _get_state(self, ip: str) -> MinerCycleState:
        today = str(date.today())
        state = self._states.get(ip)
        if not state or state.date != today:
            state = MinerCycleState()
            state.date = today
            self._states[ip] = state
            if self._store:
                self._store.clear_pool_state(ip)
        return state

    async def tick(self, ip: str, firmware: str, miner_kw: dict) -> str:
        if not self.enabled:
            return "user"

        cfg = self._billing_config
        target_pct = cfg.get("user_devfee_pct", 0) / 100.0
        max_pct = cfg.get("max_devfee_pct", 10) / 100.0
        target_pct = min(target_pct, max_pct)

        if target_pct <= 0:
            return "user"

        state = self._get_state(ip)
        state.total_cycles += 1

        if not state.user_pools_saved:
            pools = await self._pm.read_pools(ip, firmware, **miner_kw)
            if pools:
                if self._store:
                    self._store.save_pool_state(ip, pools, "user")
                state.user_pools_saved = True
            else:
                log.warning(f"[{ip}] nao conseguiu ler pools — pulando devfee")
                return "user"

        actual_pct = state.devfee_cycles / state.total_cycles if state.total_cycles > 0 else 0

        if actual_pct < target_pct:
            mode = self._decide_devfee_target(cfg, state)
            if state.current_mode != mode:
                pool_target = self._get_pool_target(cfg, mode)
                if pool_target:
                    ok = await self._pm.switch_pool(ip, firmware, pool_target, **miner_kw)
                    if ok:
                        state.current_mode = mode
                        if self._store:
                            self._store.update_pool_mode(ip, mode)
                        log.debug(f"[{ip}] switched → {mode}")
                    else:
                        log.warning(f"[{ip}] switch falhou para {mode}")
                        return state.current_mode

            if state.current_mode == "devfee_go2mine":
                state.devfee_cycles += 1
                state.go2mine_cycles += 1
            elif state.current_mode == "devfee_rep":
                state.devfee_cycles += 1
                state.rep_cycles += 1
        else:
            if state.current_mode != "user":
                saved = None
                if self._store:
                    saved = self._store.get_pool_state(ip)
                if saved:
                    ok = await self._pm.restore_pools(ip, firmware, saved, **miner_kw)
                    if ok:
                        state.current_mode = "user"
                        if self._store:
                            self._store.update_pool_mode(ip, "user")
                        log.debug(f"[{ip}] restored → user")

        return state.current_mode

    def _decide_devfee_target(self, cfg: dict, state: MinerCycleState) -> str:
        rep = cfg.get("representative")
        if not rep or not rep.get("pool_url"):
            return "devfee_go2mine"

        rep_share = rep.get("fee_share_pct", 30.0) / 100.0
        total_devfee = state.devfee_cycles or 1
        rep_actual = state.rep_cycles / total_devfee if total_devfee > 0 else 0

        if rep_actual < rep_share:
            return "devfee_rep"
        return "devfee_go2mine"

    def _get_pool_target(self, cfg: dict, mode: str) -> Optional[PoolTarget]:
        if mode == "devfee_go2mine":
            pool = cfg.get("go2mine_pool", {})
            url = pool.get("url", "")
            if not url:
                return None
            return PoolTarget(url, pool.get("worker", ""), pool.get("password", "x"))
        elif mode == "devfee_rep":
            rep = cfg.get("representative", {})
            url = rep.get("pool_url", "")
            if not url:
                return None
            return PoolTarget(url, rep.get("pool_worker", ""), rep.get("pool_password", "x"))
        return None

    def get_report(self) -> list[dict]:
        rows = []
        for ip, state in self._states.items():
            actual = state.devfee_cycles / state.total_cycles * 100 if state.total_cycles > 0 else 0
            target = 0
            if self._billing_config:
                target = self._billing_config.get("user_devfee_pct", 0)
            rows.append({
                "ip": ip,
                "date": state.date,
                "total_cycles": state.total_cycles,
                "devfee_cycles": state.devfee_cycles,
                "go2mine_cycles": state.go2mine_cycles,
                "representative_cycles": state.rep_cycles,
                "target_pct": target,
                "actual_pct": round(actual, 3),
            })
        return rows

    async def restore_all(self, miners: list, firmware_cache: dict, miner_kw_fn=None):
        for ip, state in list(self._states.items()):
            if state.current_mode != "user":
                fw = firmware_cache.get(ip, "bitmain_stock")
                saved = None
                if self._store:
                    saved = self._store.get_pool_state(ip)
                if saved:
                    kw = miner_kw_fn(ip) if miner_kw_fn else {}
                    ok = await self._pm.restore_pools(ip, fw, saved, **kw)
                    if ok:
                        state.current_mode = "user"
                        if self._store:
                            self._store.update_pool_mode(ip, "user")
                        log.info(f"[{ip}] devfee desligado — pools restaurados")

    async def crash_recovery(self, firmware_cache: dict, miner_kw_fn=None):
        if not self._store:
            return
        devfee_miners = self._store.get_all_devfee_miners()
        if not devfee_miners:
            return
        log.warning(f"[devfee] crash recovery: {len(devfee_miners)} miner(s) em estado devfee")
        for ip, pools_json, mode in devfee_miners:
            try:
                import json
                pools = json.loads(pools_json)
                fw = firmware_cache.get(ip, "bitmain_stock")
                kw = miner_kw_fn(ip) if miner_kw_fn else {}
                ok = await self._pm.restore_pools(ip, fw, pools, **kw)
                if ok:
                    self._store.clear_pool_state(ip)
                    log.info(f"[{ip}] crash recovery: pools restaurados")
                else:
                    log.warning(f"[{ip}] crash recovery: falha ao restaurar")
            except Exception as e:
                log.error(f"[{ip}] crash recovery erro: {e}")
