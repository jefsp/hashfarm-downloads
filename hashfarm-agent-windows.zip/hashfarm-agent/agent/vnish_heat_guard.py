import json
import logging
import time
from pathlib import Path

log = logging.getLogger("hashfarm.heat_guard")

WARN_TEMP = 83
HOT_TEMP = 86
TRIP_TEMP = 90
SLOPE_FLOOR_TEMP = 79
PROJECTION_MIN = 2.0
ACTION_COOLDOWN = 90
OVERHEAT_COOLDOWN = 120
OVERHEAT_MIN_STOPPED = 60
OVERHEAT_STEPS = 2
CAP_SECONDS = 4 * 3600
LADDER_TTL = 3600
SAMPLE_MAX_AGE = 300
WARMUP_SECONDS = 420
THROTTLE_TEMP = 80
THROTTLE_STEP = 15
THROTTLE_MIN = 70
HEADROOM_TEMP = 77
HEADROOM_FAN = 80
HEADROOM_SECONDS = 900
UNTHROTTLE_FAN = 65
CATCHUP_FAN = 65
CATCHUP_TEMP = 76
CATCHUP_SECONDS = 180
TUNING_STUCK_SECONDS = 900
JUMP_COOLDOWN_SECONDS = 4 * 3600
JUMP_MIN_STEPS = 2
CATCHUP_MIN_CAP_AGE = 2 * 3600
SLOW_RESTARTS_PER_MIN = 3


def hottest_board(snap: dict) -> tuple[int, float] | None:
    best = None
    for i, c in enumerate(snap.get("chains") or []):
        t = c.get("temp_max")
        if isinstance(t, (int, float)) and t > 0 and (best is None or t > best[1]):
            best = (int(c.get("id") or i + 1), float(t))
    return best


def board_label(snap: dict) -> str:
    hb = hottest_board(snap)
    return f"placa {hb[0]} {hb[1]:.0f}C" if hb else ""


def overheated_board(snap: dict) -> int | None:
    for i, c in enumerate(snap.get("chains") or []):
        if "overheat" in (c.get("desc") or "").lower():
            return int(c.get("id") or i + 1)
    hb = hottest_board(snap)
    return hb[0] if hb else None


def is_overheat(snap: dict) -> bool:
    if (snap.get("miner_state") or "").lower() != "failure":
        return False
    return "overheat" in (snap.get("failure_desc") or "").lower()


class HeatGuard:
    def __init__(self, store_path: str = "heat_guard.json"):
        self._path = Path(store_path)
        self._ladder: dict[str, list[str]] = {}
        self._ladder_ts: dict[str, float] = {}
        self._sample: dict[str, tuple[float, float]] = {}
        self._last_action: dict[str, float] = {}
        self._cap: dict[str, tuple[str, float]] = {}
        self._orig_top: dict[str, str] = {}
        self._cool_since: dict[str, float] = {}
        self._disabled: dict[str, list[int]] = {}
        self._stock: dict[str, str] = {}
        self._last_jump: dict[str, float] = {}
        self._load()

    def _load(self):
        try:
            if self._path.exists():
                data = json.loads(self._path.read_text(encoding="utf-8"))
                now = time.time()
                self._cap = {ip: (c[0], float(c[1])) for ip, c in (data.get("cap") or {}).items() if float(c[1]) > now}
                self._orig_top = dict(data.get("orig_top") or {})
                self._disabled = {ip: list(v) for ip, v in (data.get("disabled_boards") or {}).items()}
                self._last_jump = {ip: float(v) for ip, v in (data.get("last_jump") or {}).items()}
                if self._cap:
                    log.info(f"heat guard: {len(self._cap)} teto(s) termico(s) restaurado(s) do disco")
        except Exception as e:
            log.warning(f"heat guard: falha lendo {self._path}: {e}")

    def _save(self):
        try:
            self._path.write_text(json.dumps({"cap": self._cap, "orig_top": self._orig_top,
                                              "disabled_boards": self._disabled,
                                              "last_jump": self._last_jump}), encoding="utf-8")
        except Exception as e:
            log.warning(f"heat guard: falha salvando {self._path}: {e}")

    def needs_ladder(self, ip: str) -> bool:
        return ip not in self._ladder or time.time() - self._ladder_ts.get(ip, 0) > LADDER_TTL

    def set_ladder(self, ip: str, names: list[str], stock: str | None = None):
        if names:
            self._ladder[ip] = names
            self._ladder_ts[ip] = time.time()
        if stock:
            self._stock[ip] = stock

    def remember_top(self, ip: str, top: str):
        if top and ip not in self._orig_top:
            self._orig_top[ip] = top
            self._save()

    def expired_caps(self) -> list[tuple[str, str]]:
        now = time.time()
        out = []
        for ip, (_, until) in list(self._cap.items()):
            if now >= until:
                self._cap.pop(ip, None)
                orig = self._orig_top.pop(ip, "")
                if orig:
                    out.append((ip, orig))
        if out:
            self._save()
        return out

    def clamp(self, ip: str, name: str) -> str:
        cap = self._cap.get(ip)
        ladder = self._ladder.get(ip) or []
        if not cap or time.time() >= cap[1] or cap[0] not in ladder or name not in ladder:
            return name
        return cap[0] if ladder.index(name) > ladder.index(cap[0]) else name

    def forget(self, ip: str):
        had = self._cap.pop(ip, None) or self._orig_top.pop(ip, None)
        self._orig_top.pop(ip, None)
        self._sample.pop(ip, None)
        if had:
            self._save()

    def decide(self, ip: str, snap: dict, allow_restart: bool = True, prof: dict | None = None) -> dict | None:
        prof = prof or {}
        raise_fan = prof.get("guard_raise_fan", HEADROOM_FAN)
        unthrottle_fan = prof.get("guard_unthrottle_fan", UNTHROTTLE_FAN)
        raise_s = prof.get("guard_raise_s", HEADROOM_SECONDS)
        fast_fan = prof.get("guard_fast_fan", 0)
        fast_s = prof.get("guard_fast_raise_s", raise_s)
        ladder = self._ladder.get(ip)
        cur = snap.get("current_preset") or ""
        if not ladder or cur not in ladder:
            return None
        idx = ladder.index(cur)
        now = time.time()
        last = self._last_action.get(ip, 0)

        if is_overheat(snap):
            stopped = snap.get("uptime_s") or 0
            if now - last < OVERHEAT_COOLDOWN or stopped < OVERHEAT_MIN_STOPPED:
                return None
            if idx == 0:
                return self._disable_board(ip, snap, cur, now, f"superaqueceu no menor preset {cur}")
            return self._act(ip, ladder, idx, OVERHEAT_STEPS, True,
                             f"overheat_stop ({snap.get('failure_desc')})", now,
                             int(snap.get("throttled") or 100))

        if (snap.get("status") or "") != "mining":
            return None
        temp = snap.get("chip_temp_max") or 0
        if temp <= 0:
            return None

        slope = 0.0
        prev = self._sample.get(ip)
        if prev and 0 < now - prev[0] <= SAMPLE_MAX_AGE:
            slope = (temp - prev[1]) / ((now - prev[0]) / 60.0)
        self._sample[ip] = (now, temp)

        throttled = int(snap.get("throttled") or 100)
        where = board_label(snap)
        tag = f" · {where}" if where else ""

        cap = self._cap.get(ip)
        if cap and cap[0] in ladder and idx > ladder.index(cap[0]) and now - last >= ACTION_COOLDOWN:
            return self._act(ip, ladder, idx, idx - ladder.index(cap[0]), False,
                             f"acima do teto termico {cap[0]}{tag}", now, throttled)

        warming_up = (snap.get("uptime_s") or 0) < WARMUP_SECONDS
        fan = snap.get("fan_duty")
        headroom = (not warming_up and temp <= HEADROOM_TEMP
                    and isinstance(fan, (int, float)) and 0 < fan <= raise_fan)
        if headroom:
            self._cool_since.setdefault(ip, now)
        else:
            self._cool_since.pop(ip, None)

        if now - last < ACTION_COOLDOWN:
            return None
        projected = temp if warming_up else temp + max(slope, 0) * PROJECTION_MIN
        if temp >= HOT_TEMP or (temp >= SLOPE_FLOOR_TEMP and projected >= TRIP_TEMP):
            if idx == 0:
                return self._disable_board(ip, snap, cur, now, f"chip {temp}C no menor preset {cur}")
            return self._act(ip, ladder, idx, 2, False,
                             f"chip {temp}C subindo {slope:+.1f}C/min (proj {projected:.0f}C){tag}", now, throttled)
        if temp >= WARN_TEMP:
            return self._act(ip, ladder, idx, 1, False, f"chip {temp}C{tag}", now, throttled)
        if temp >= THROTTLE_TEMP and throttled > THROTTLE_MIN and not warming_up:
            pct = max(THROTTLE_MIN, throttled - THROTTLE_STEP)
            self._last_action[ip] = now
            return {"kind": "throttle", "percent": pct, "from": cur, "to": cur,
                    "reason": f"throttle {throttled}%->{pct}% sem parar · chip {temp}C{tag}"}
        since = self._cool_since.get(ip)
        cap = self._cap.get(ip)
        stock = self._stock.get(ip)
        jump_to = None
        if stock in ladder:
            jump_to = stock
            if cap and cap[0] in ladder and ladder.index(cap[0]) < ladder.index(stock):
                jump_to = cap[0]
        if (jump_to and since is not None and throttled >= 100
                and ladder.index(jump_to) - idx >= JUMP_MIN_STEPS
                and now - self._last_jump.get(ip, 0) >= JUMP_COOLDOWN_SECONDS
                and (snap.get("miner_state") or "").lower() == "auto-tuning"
                and (snap.get("uptime_s") or 0) >= TUNING_STUCK_SECONDS
                and fan <= CATCHUP_FAN and temp <= CATCHUP_TEMP and now - since >= CATCHUP_SECONDS):
            if not allow_restart:
                return None
            self._last_jump[ip] = now
            if jump_to == stock and not (cap and cap[0] in ladder and ladder.index(cap[0]) < ladder.index(stock)):
                self._cap.pop(ip, None)
                self._orig_top.pop(ip, None)
            self._save()
            self._cool_since[ip] = now
            self._last_action[ip] = now
            alvo = "stock" if jump_to == stock else "teto seguro"
            return {"kind": "jump", "from": cur, "to": jump_to,
                    "reason": f"preso calibrando {cur} ha {int((snap.get('uptime_s') or 0) // 60)}min com folga · direto ao {alvo} {jump_to} · chip {temp}C fan {fan:.0f}%"}
        cap_age = (CAP_SECONDS - (cap[1] - now)) if cap else 0
        if (since is not None and throttled >= 100 and cap and cap[0] in ladder and stock in ladder
                and cap_age >= CATCHUP_MIN_CAP_AGE
                and ladder.index(cap[0]) < ladder.index(stock) and fan <= CATCHUP_FAN and temp <= CATCHUP_TEMP
                and now - since >= CATCHUP_SECONDS):
            orig = self._orig_top.get(ip) or ""
            self._cool_since[ip] = now
            self._last_action[ip] = now
            if orig in ladder and ladder.index(orig) <= ladder.index(stock):
                self._cap.pop(ip, None)
                self._orig_top.pop(ip, None)
                self._save()
                return {"kind": "release", "from": cur, "to": cur, "top": None,
                        "reason": f"recuperacao ate o stock: teto liberado (teto do perfil) · chip {temp}C fan {fan:.0f}%"}
            self._cap[ip] = (stock, now + CAP_SECONDS)
            self._save()
            return {"kind": "raise", "from": cur, "to": cur, "top": stock,
                    "reason": f"recuperacao ate o stock: teto {cap[0]}->{stock} (switcher sobe 1 preset/3min) · chip {temp}C fan {fan:.0f}%"}
        need = fast_s if fast_fan and fan <= fast_fan else raise_s
        if since is None or now - since < need:
            return None
        room = f"folga {need // 60}min · chip {temp}C fan {fan:.0f}%"
        if throttled < 100:
            if fan > unthrottle_fan or not allow_restart:
                return None
            self._cool_since[ip] = now
            self._last_action[ip] = now
            return {"kind": "unthrottle", "from": cur, "to": cur,
                    "reason": f"throttle {throttled}%->100% · {room}"}
        if cap and cap_age < CATCHUP_MIN_CAP_AGE:
            return None
        self._cool_since[ip] = now
        cap = self._cap.get(ip)
        if cap and cap[0] in ladder:
            ci = ladder.index(cap[0])
            orig = self._orig_top.get(ip) or ""
            self._last_action[ip] = now
            if orig not in ladder or ci + 1 >= ladder.index(orig):
                self._cap.pop(ip, None)
                self._orig_top.pop(ip, None)
                self._save()
                return {"kind": "release", "from": cur, "to": cur, "top": None,
                        "reason": f"teto liberado (teto do perfil) · {room}"}
            new = ladder[ci + 1]
            self._cap[ip] = (new, now + CAP_SECONDS)
            self._save()
            return {"kind": "raise", "from": cur, "to": cur, "top": new,
                    "reason": f"teto {cap[0]}->{new} · {room}"}
        return None

    def _disable_board(self, ip, snap, cur, now, why) -> dict | None:
        chains = snap.get("chains") or []
        already = set(self._disabled.get(ip, []))
        active = [int(c.get("id") or i + 1) for i, c in enumerate(chains) if int(c.get("id") or i + 1) not in already]
        board = overheated_board(snap)
        if board is None or board in already or len(active) <= 1:
            return None
        self._last_action[ip] = now
        self._disabled.setdefault(ip, []).append(board)
        self._save()
        return {"kind": "disable_board", "board": board, "remaining": len(active) - 1,
                "from": cur, "to": cur, "reason": f"placa {board} desligada · {why}"}

    def disabled_boards(self, ip: str) -> list[int]:
        return list(self._disabled.get(ip, []))

    def _act(self, ip, ladder, idx, steps, restart, reason, now, throttled: int = 100) -> dict | None:
        target_idx = max(0, idx - max(steps, 1))
        if target_idx == idx:
            return None
        target = ladder[target_idx]
        self._last_action[ip] = now
        cap = self._cap.get(ip)
        if not cap or cap[0] not in ladder or ladder.index(cap[0]) > target_idx:
            cap_name = target
        else:
            cap_name = cap[0]
        self._cap[ip] = (cap_name, now + CAP_SECONDS)
        self._sample.pop(ip, None)
        self._cool_since.pop(ip, None)
        self._save()
        reset = throttled < 100
        return {"kind": "preset", "from": ladder[idx], "to": target, "cap": cap_name,
                "restart": restart or reset, "reset_throttle": reset, "reason": reason}
