import logging
import time

log = logging.getLogger("hashfarm.heat_guard")

WARN_TEMP = 83
HOT_TEMP = 86
TRIP_TEMP = 90
SLOPE_FLOOR_TEMP = 79
PROJECTION_MIN = 2.0
ACTION_COOLDOWN = 90
OVERHEAT_COOLDOWN = 120
OVERHEAT_MIN_STOPPED = 60
OVERHEAT_STEPS = 2
CAP_SECONDS = 4 * 3600
LADDER_TTL = 3600
SAMPLE_MAX_AGE = 300


def is_overheat(snap: dict) -> bool:
    if (snap.get("miner_state") or "").lower() != "failure":
        return False
    return "overheat" in (snap.get("failure_desc") or "").lower()


class HeatGuard:
    def __init__(self):
        self._ladder: dict[str, list[str]] = {}
        self._ladder_ts: dict[str, float] = {}
        self._sample: dict[str, tuple[float, float]] = {}
        self._last_action: dict[str, float] = {}
        self._cap: dict[str, tuple[str, float]] = {}
        self._orig_top: dict[str, str] = {}

    def needs_ladder(self, ip: str) -> bool:
        return ip not in self._ladder or time.time() - self._ladder_ts.get(ip, 0) > LADDER_TTL

    def set_ladder(self, ip: str, names: list[str]):
        if names:
            self._ladder[ip] = names
            self._ladder_ts[ip] = time.time()

    def remember_top(self, ip: str, top: str):
        if top and ip not in self._orig_top:
            self._orig_top[ip] = top

    def expired_caps(self) -> list[tuple[str, str]]:
        now = time.time()
        out = []
        for ip, (_, until) in list(self._cap.items()):
            if now >= until:
                self._cap.pop(ip, None)
                orig = self._orig_top.pop(ip, "")
                if orig:
                    out.append((ip, orig))
        return out

    def forget(self, ip: str):
        self._cap.pop(ip, None)
        self._orig_top.pop(ip, None)
        self._sample.pop(ip, None)

    def decide(self, ip: str, snap: dict) -> dict | None:
        ladder = self._ladder.get(ip)
        cur = snap.get("current_preset") or ""
        if not ladder or cur not in ladder:
            return None
        idx = ladder.index(cur)
        now = time.time()
        last = self._last_action.get(ip, 0)

        if is_overheat(snap):
            stopped = snap.get("uptime_s") or 0
            if now - last < OVERHEAT_COOLDOWN or stopped < OVERHEAT_MIN_STOPPED:
                return None
            return self._act(ip, ladder, idx, OVERHEAT_STEPS, True,
                             f"overheat_stop ({snap.get('failure_desc')})", now)

        if (snap.get("status") or "") != "mining":
            return None
        temp = snap.get("chip_temp_max") or 0
        if temp <= 0:
            return None

        slope = 0.0
        prev = self._sample.get(ip)
        if prev and 0 < now - prev[0] <= SAMPLE_MAX_AGE:
            slope = (temp - prev[1]) / ((now - prev[0]) / 60.0)
        self._sample[ip] = (now, temp)

        cap = self._cap.get(ip)
        if cap and cap[0] in ladder and idx > ladder.index(cap[0]) and now - last >= ACTION_COOLDOWN:
            return self._act(ip, ladder, idx, idx - ladder.index(cap[0]), False, f"acima do teto termico {cap[0]}", now)

        if now - last < ACTION_COOLDOWN:
            return None
        projected = temp + max(slope, 0) * PROJECTION_MIN
        if temp >= HOT_TEMP or (temp >= SLOPE_FLOOR_TEMP and projected >= TRIP_TEMP):
            return self._act(ip, ladder, idx, 2, False,
                             f"chip {temp}C subindo {slope:+.1f}C/min (proj {projected:.0f}C)", now)
        if temp >= WARN_TEMP:
            return self._act(ip, ladder, idx, 1, False, f"chip {temp}C", now)
        return None

    def _act(self, ip, ladder, idx, steps, restart, reason, now) -> dict | None:
        target_idx = max(0, idx - max(steps, 1))
        if target_idx == idx:
            return None
        target = ladder[target_idx]
        self._last_action[ip] = now
        cap = self._cap.get(ip)
        if not cap or cap[0] not in ladder or ladder.index(cap[0]) > target_idx:
            cap_name = target
        else:
            cap_name = cap[0]
        self._cap[ip] = (cap_name, now + CAP_SECONDS)
        self._sample.pop(ip, None)
        return {"from": ladder[idx], "to": target, "cap": cap_name, "restart": restart, "reason": reason}
