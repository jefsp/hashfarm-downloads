"""
hashfarm-agent · scanner.py
Escaneia a rede local em busca de ASICs (Vnish, Whatsminer, Bitmain/BrainOS).
"""
import asyncio
import json
import logging
import socket
from typing import Optional

import aiohttp

log = logging.getLogger("hashfarm.scanner")

SCAN_TIMEOUT = 2.5
SCAN_CONCURRENCY = 30
TCP_PORT = 4028


def get_local_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    finally:
        s.close()


def get_all_local_prefixes() -> list[str]:
    """Retorna os prefixos /24 de todas as interfaces IPv4 ativas (não-loopback).
    Funciona em Linux e Windows sem dependências externas."""
    prefixes = []
    seen = set()
    try:
        addrs = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)
        for *_, sockaddr in addrs:
            ip = sockaddr[0]
            if ip.startswith("127.") or ip.startswith("169.254."):
                continue
            prefix = ".".join(ip.split(".")[:3])
            if prefix not in seen:
                seen.add(prefix)
                prefixes.append(prefix)
    except Exception:
        pass
    if not prefixes:
        local = get_local_ip()
        prefixes.append(".".join(local.split(".")[:3]))
    return prefixes


async def _query_4028(ip: str, payload: dict, retry: bool = True) -> tuple[Optional[dict], str]:
    """Retorna (dados, motivo). motivo: ok | vazio | timeout | recusada | erro."""
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(ip, TCP_PORT), timeout=SCAN_TIMEOUT
        )
    except (ConnectionRefusedError, ConnectionResetError):
        if retry:
            await asyncio.sleep(0.8)
            return await _query_4028(ip, payload, retry=False)
        return None, "recusada"
    except asyncio.TimeoutError:
        return None, "timeout"
    except Exception:
        return None, "erro"
    try:
        writer.write(json.dumps(payload).encode())
        await writer.drain()

        buf = b""
        try:
            while True:
                chunk = await asyncio.wait_for(reader.read(4096), timeout=SCAN_TIMEOUT)
                if not chunk:
                    break
                buf += chunk
                if b"\x00" in buf:
                    buf = buf.rstrip(b"\x00")
                    break
        except asyncio.TimeoutError:
            pass

        if not buf:
            return None, "vazio"
        return json.loads(buf.decode(errors="replace")), "ok"
    except Exception:
        return None, "erro"
    finally:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass


async def _tcp_probe(ip: str, port: int = TCP_PORT) -> Optional[dict]:
    data, _ = await _query_4028(ip, {"command": "version"})
    return data


async def _http_probe(ip: str) -> Optional[dict]:
    try:
        timeout = aiohttp.ClientTimeout(total=SCAN_TIMEOUT)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(f"http://{ip}/api/v1/info") as resp:
                if resp.status == 200:
                    return await resp.json()
    except Exception:
        pass
    return None


def _classify_tcp(data: dict) -> Optional[dict]:
    status_list = data.get("STATUS", [])
    desc = ""
    if status_list:
        desc = (status_list[0].get("Description", "") if isinstance(status_list[0], dict) else "").lower()

    if "microbt" in desc or "whatsminer" in desc:
        model = ""
        summary = data.get("SUMMARY", [])
        if summary and isinstance(summary[0], dict):
            model = summary[0].get("Type", "") or ""
        return {"firmware": "whatsminer", "model": model or "Whatsminer"}

    ver_list = data.get("VERSION", [])
    ver = ver_list[0] if ver_list and isinstance(ver_list[0], dict) else {}
    model = ver.get("Type", "") or ver.get("Model", "") or ""

    cgm = ver.get("CGMiner", "") or ver.get("Miner", "") or ""
    ver_str = json.dumps(data).lower()
    is_braiins = any(k in ver_str for k in ("braiins", "bosminer", "bos+", "bos_", "braiinos"))

    if "antminer" in model.lower():
        return {"firmware": "braiins" if is_braiins else "bitmain_stock", "model": model}

    if is_braiins:
        return {"firmware": "braiins", "model": model or "BrainOS"}

    if ver or status_list:
        return {"firmware": "bitmain_stock", "model": model or cgm or "CGMiner"}

    return None


async def _wm_probe(ip: str) -> Optional[dict]:
    data, _ = await _query_4028(ip, {"cmd": "summary"})
    if isinstance(data, dict) and data.get("SUMMARY"):
        return data
    return None


async def _probe_ip(ip: str, local_ip: str) -> Optional[dict]:
    if ip == local_ip:
        return None

    # Porta 4028 em SERIE: cgminer/btminer atende 1 conexao por vez — duas sondas
    # simultaneas se derrubavam e a maquina sumia do scan de forma intermitente.
    http_task = asyncio.create_task(_http_probe(ip))
    tcp_data, tcp_why = await _query_4028(ip, {"command": "version"})
    cls = _classify_tcp(tcp_data) if tcp_data else None
    wm_data = None
    # Timeout de conexao = IP vazio; sondar de novo so gastaria mais 2.5s a toa
    if (cls is None and tcp_why != "timeout") or (cls and cls.get("firmware") == "whatsminer"):
        wm_data = await _wm_probe(ip)
    http_data = await http_task

    if http_data and isinstance(http_data, dict):
        miner = http_data.get("miner", "") or http_data.get("model", "")
        fw_ver = http_data.get("fw_version", "") or http_data.get("firmware", "")
        if miner or fw_ver:
            return {"ip": ip, "model": miner or "Vnish", "firmware": "vnish", "fw_version": fw_ver}

    if wm_data and isinstance(wm_data, dict) and wm_data.get("SUMMARY"):
        summary = wm_data["SUMMARY"]
        s0 = summary[0] if isinstance(summary, list) and summary else summary
        model = (s0.get("Type", "") or s0.get("Model", "") or "") if isinstance(s0, dict) else ""
        return {"ip": ip, "model": model or "Whatsminer", "firmware": "whatsminer", "fw_version": ""}

    if cls:
        return {"ip": ip, "model": cls["model"], "firmware": cls["firmware"], "fw_version": ""}

    return None


async def scan_subnet(prefix: str, progress_cb=None) -> list[dict]:
    """Escaneia um /24 em 2 passadas (a 2ª só nos IPs sem resposta — perda de
    pacote/ARP em switch carregado). progress_cb(done, total, found_count, prefix)."""
    local_ip = get_local_ip()
    sem = asyncio.Semaphore(SCAN_CONCURRENCY)
    found = []
    done = {"n": 0}
    total = {"n": 254}

    async def probe_with_sem(ip):
        async with sem:
            r = await _probe_ip(ip, local_ip)
        done["n"] += 1
        if r:
            found.append(r)
        return r

    async def sweep(ips):
        return await asyncio.gather(*[probe_with_sem(ip) for ip in ips])

    async def emit_progress():
        if not progress_cb:
            return
        try:
            while done["n"] < total["n"]:
                await asyncio.sleep(0.8)
                try:
                    await progress_cb(done["n"], total["n"], len(found), prefix)
                except Exception:
                    pass
        except asyncio.CancelledError:
            pass

    progress_task = asyncio.create_task(emit_progress())
    try:
        ips = [f"{prefix}.{i}" for i in range(1, 255)]
        results = await sweep(ips)
        retry_ips = [ip for ip, r in zip(ips, results) if r is None]
        # 2ª passada só se a subnet tem vida (senão dobra o tempo em rede vazia)
        if found and retry_ips:
            log.info(f"Scan {prefix}.0/24: 2a passada em {len(retry_ips)} IPs sem resposta")
            total["n"] += len(retry_ips)
            await sweep(retry_ips)
    finally:
        progress_task.cancel()
        try:
            await progress_task
        except Exception:
            pass

    found.sort(key=lambda x: tuple(int(p) for p in x["ip"].split(".")))
    log.info(f"Scan {prefix}.0/24: {len(found)} ASICs encontradas")
    if progress_cb:
        try:
            await progress_cb(total["n"], total["n"], len(found), prefix)
        except Exception:
            pass
    return found
