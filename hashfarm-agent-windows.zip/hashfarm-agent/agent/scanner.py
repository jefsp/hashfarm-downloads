"""
hashfarm-agent · scanner.py
Escaneia a rede local em busca de ASICs (Vnish, Whatsminer, Bitmain/BrainOS).
"""
import asyncio
import json
import logging
import socket
from typing import Optional

import aiohttp

log = logging.getLogger("hashfarm.scanner")

SCAN_TIMEOUT = 3
SCAN_CONCURRENCY = 50
TCP_PORT = 4028


def get_local_ip() -> str:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    finally:
        s.close()


def get_all_local_prefixes() -> list[str]:
    """Retorna os prefixos /24 de todas as interfaces IPv4 ativas (não-loopback).
    Funciona em Linux e Windows sem dependências externas."""
    prefixes = []
    seen = set()
    try:
        addrs = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)
        for *_, sockaddr in addrs:
            ip = sockaddr[0]
            if ip.startswith("127.") or ip.startswith("169.254."):
                continue
            prefix = ".".join(ip.split(".")[:3])
            if prefix not in seen:
                seen.add(prefix)
                prefixes.append(prefix)
    except Exception:
        pass
    if not prefixes:
        local = get_local_ip()
        prefixes.append(".".join(local.split(".")[:3]))
    return prefixes


async def _tcp_probe(ip: str, port: int = TCP_PORT) -> Optional[dict]:
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(ip, port), timeout=SCAN_TIMEOUT
        )
        writer.write(json.dumps({"command": "version"}).encode())
        await writer.drain()

        buf = b""
        try:
            while True:
                chunk = await asyncio.wait_for(reader.read(4096), timeout=SCAN_TIMEOUT)
                if not chunk:
                    break
                buf += chunk
                if b"\x00" in buf:
                    buf = buf.rstrip(b"\x00")
                    break
        except asyncio.TimeoutError:
            pass

        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass

        if not buf:
            return None
        data = json.loads(buf.decode(errors="replace"))
        return data
    except Exception:
        return None


async def _http_probe(ip: str) -> Optional[dict]:
    try:
        timeout = aiohttp.ClientTimeout(total=SCAN_TIMEOUT)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(f"http://{ip}/api/v1/info") as resp:
                if resp.status == 200:
                    return await resp.json()
    except Exception:
        pass
    return None


def _classify_tcp(data: dict) -> Optional[dict]:
    status_list = data.get("STATUS", [])
    desc = ""
    if status_list:
        desc = (status_list[0].get("Description", "") if isinstance(status_list[0], dict) else "").lower()

    if "microbt" in desc or "whatsminer" in desc:
        model = ""
        summary = data.get("SUMMARY", [])
        if summary and isinstance(summary[0], dict):
            model = summary[0].get("Type", "") or ""
        return {"firmware": "whatsminer", "model": model or "Whatsminer"}

    ver_list = data.get("VERSION", [])
    ver = ver_list[0] if ver_list and isinstance(ver_list[0], dict) else {}
    model = ver.get("Type", "") or ver.get("Model", "") or ""

    cgm = ver.get("CGMiner", "") or ver.get("Miner", "") or ""
    ver_str = json.dumps(data).lower()
    is_braiins = any(k in ver_str for k in ("braiins", "bosminer", "bos+", "bos_", "braiinos"))

    if "antminer" in model.lower():
        return {"firmware": "braiins" if is_braiins else "bitmain_stock", "model": model}

    if is_braiins:
        return {"firmware": "braiins", "model": model or "BrainOS"}

    if ver or status_list:
        return {"firmware": "bitmain_stock", "model": model or cgm or "CGMiner"}

    return None


async def _wm_probe(ip: str) -> Optional[dict]:
    try:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(ip, TCP_PORT), timeout=SCAN_TIMEOUT
        )
        writer.write(json.dumps({"cmd": "summary"}).encode())
        await writer.drain()

        buf = b""
        try:
            while True:
                chunk = await asyncio.wait_for(reader.read(4096), timeout=SCAN_TIMEOUT)
                if not chunk:
                    break
                buf += chunk
                if b"\x00" in buf:
                    buf = buf.rstrip(b"\x00")
                    break
        except asyncio.TimeoutError:
            pass

        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass

        if not buf:
            return None
        data = json.loads(buf.decode(errors="replace"))
        if isinstance(data, dict) and data.get("SUMMARY"):
            return data
    except Exception:
        pass
    return None


async def _probe_ip(ip: str, local_ip: str) -> Optional[dict]:
    if ip == local_ip:
        return None

    tcp_task = asyncio.create_task(_tcp_probe(ip))
    http_task = asyncio.create_task(_http_probe(ip))
    wm_task = asyncio.create_task(_wm_probe(ip))

    tcp_data, http_data, wm_data = await asyncio.gather(tcp_task, http_task, wm_task)

    if http_data and isinstance(http_data, dict):
        miner = http_data.get("miner", "") or http_data.get("model", "")
        fw_ver = http_data.get("fw_version", "") or http_data.get("firmware", "")
        if miner or fw_ver:
            return {"ip": ip, "model": miner or "Vnish", "firmware": "vnish", "fw_version": fw_ver}

    if wm_data and isinstance(wm_data, dict) and wm_data.get("SUMMARY"):
        summary = wm_data["SUMMARY"]
        s0 = summary[0] if isinstance(summary, list) and summary else summary
        model = (s0.get("Type", "") or s0.get("Model", "") or "") if isinstance(s0, dict) else ""
        return {"ip": ip, "model": model or "Whatsminer", "firmware": "whatsminer", "fw_version": ""}

    if tcp_data:
        result = _classify_tcp(tcp_data)
        if result:
            return {"ip": ip, "model": result["model"], "firmware": result["firmware"], "fw_version": ""}

    return None


async def scan_subnet(prefix: str, progress_cb=None) -> list[dict]:
    """Escaneia um /24. progress_cb(done, total, found_count, prefix) é chamado periodicamente."""
    local_ip = get_local_ip()
    sem = asyncio.Semaphore(SCAN_CONCURRENCY)
    found = []
    total = 254
    done = {"n": 0}

    async def probe_with_sem(ip):
        async with sem:
            r = await _probe_ip(ip, local_ip)
        done["n"] += 1
        if r:
            found.append(r)
        return r

    tasks = [probe_with_sem(f"{prefix}.{i}") for i in range(1, 255)]

    async def emit_progress():
        if not progress_cb:
            return
        try:
            while done["n"] < total:
                await asyncio.sleep(0.8)
                try:
                    await progress_cb(done["n"], total, len(found), prefix)
                except Exception:
                    pass
        except asyncio.CancelledError:
            pass

    progress_task = asyncio.create_task(emit_progress())
    try:
        results = await asyncio.gather(*tasks)
    finally:
        progress_task.cancel()
        try:
            await progress_task
        except Exception:
            pass

    found.sort(key=lambda x: tuple(int(p) for p in x["ip"].split(".")))
    log.info(f"Scan {prefix}.0/24: {len(found)} ASICs encontradas")
    if progress_cb:
        try:
            await progress_cb(total, total, len(found), prefix)
        except Exception:
            pass
    return found
