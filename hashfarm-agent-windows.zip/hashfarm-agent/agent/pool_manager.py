"""
hashfarm-agent · pool_manager.py
Gerencia pool switching por firmware (Bitmain, Whatsminer, Vnish).
Salva/restaura pools originais do usuario.
"""

import asyncio
import json
import logging
from typing import Optional

from .bitmain import cgminer_send
from .whatsminer import WhatsminerClient, WhatsminerConfig
from .vnish import VnishClient, MinerConfig as VnishMinerConfig

log = logging.getLogger("hashfarm.pool_mgr")


class PoolTarget:
    def __init__(self, url: str, worker: str, password: str = "x"):
        self.url = url
        self.worker = worker
        self.password = password

    def __repr__(self):
        return f"PoolTarget({self.url}, {self.worker})"


class PoolManager:
    def __init__(
        self,
        vnish_client: Optional[VnishClient] = None,
        wm_client: Optional[WhatsminerClient] = None,
    ):
        self._vnish = vnish_client
        self._wm = wm_client

    async def verify_pool_active(self, ip: str, firmware: str, target_url: str, **kw) -> bool:
        try:
            if firmware == "vnish":
                mc = self._vnish_mc(ip, kw)
                data = await self._vnish.get(mc, "/summary")
                if not data:
                    return False
                miner_data = data.get("miner", data)
                pools = miner_data.get("pools", [])
                for p in pools:
                    if p.get("pool_type", "").lower() == "devfee":
                        continue
                    url = (p.get("url", "") or "").lower()
                    target_clean = target_url.lower().replace("stratum+tcp://", "").replace("stratum2+tcp://", "")
                    if target_clean in url and p.get("status", "").lower() in ("active", "alive"):
                        accepted = p.get("accepted", 0) or p.get("diffa", 0) or 0
                        if accepted > 0:
                            log.info(f"[{ip}] pool {target_url} ATIVA (accepted={accepted})")
                            return True
                        else:
                            log.warning(f"[{ip}] pool {target_url} conectada mas sem shares aceitas")
                            return False
                log.warning(f"[{ip}] pool {target_url} NAO encontrada entre pools ativas")
                return False
            return True
        except Exception as e:
            log.warning(f"[{ip}] verify_pool_active erro: {e}")
            return False

    async def read_pools(self, ip: str, firmware: str, **kw) -> Optional[list[dict]]:
        try:
            if firmware == "vnish":
                return await self._read_vnish(ip, kw)
            elif firmware == "whatsminer":
                return await self._read_whatsminer(ip, kw)
            elif firmware in ("bitmain_stock", "braiins"):
                return await self._read_cgminer(ip)
            else:
                log.warning(f"[{ip}] read_pools: firmware desconhecido {firmware}")
                return None
        except Exception as e:
            log.error(f"[{ip}] read_pools erro: {e}")
            return None

    async def switch_pool(self, ip: str, firmware: str, target: PoolTarget, **kw) -> bool:
        try:
            if firmware == "vnish":
                return await self._switch_vnish(ip, target, kw)
            elif firmware == "whatsminer":
                return await self._switch_whatsminer(ip, target, kw)
            elif firmware in ("bitmain_stock", "braiins"):
                return await self._switch_cgminer(ip, target)
            else:
                log.warning(f"[{ip}] switch_pool: firmware desconhecido {firmware}")
                return False
        except Exception as e:
            log.error(f"[{ip}] switch_pool erro: {e}")
            return False

    async def restore_pools(self, ip: str, firmware: str, saved_pools: list[dict], **kw) -> bool:
        try:
            if firmware == "vnish":
                return await self._restore_vnish(ip, saved_pools, kw)
            elif firmware == "whatsminer":
                return await self._restore_whatsminer(ip, saved_pools, kw)
            elif firmware in ("bitmain_stock", "braiins"):
                return await self._restore_cgminer(ip, saved_pools)
            else:
                log.warning(f"[{ip}] restore_pools: firmware desconhecido {firmware}")
                return False
        except Exception as e:
            log.error(f"[{ip}] restore_pools erro: {e}")
            return False

    # ── CGMiner (Bitmain Stock / BraiinsOS) ────────────────────────────────

    async def _read_cgminer(self, ip: str) -> Optional[list[dict]]:
        log.info(f"[{ip}] cgminer read_pools...")
        data = await cgminer_send(ip, 4028, "pools", timeout=5)
        if not data:
            log.warning(f"[{ip}] cgminer read_pools: sem resposta")
            return None
        pools_raw = data.get("POOLS", [])
        return [
            {
                "url": p.get("URL", ""),
                "user": p.get("User", ""),
                "pass": p.get("Pass", "x") if p.get("Pass") else "x",
                "status": p.get("Status", ""),
                "pool_idx": p.get("POOL", i),
            }
            for i, p in enumerate(pools_raw)
        ]

    async def _switch_cgminer(self, ip: str, target: PoolTarget) -> bool:
        add_cmd = f"addpool|{target.url},{target.worker},{target.password}"
        log.info(f"[{ip}] cgminer addpool: {target.url} worker={target.worker}")
        result = await cgminer_send(ip, 4028, add_cmd, timeout=5)
        if not result:
            log.warning(f"[{ip}] cgminer addpool falhou — sem resposta")
            return False

        await asyncio.sleep(0.5)
        pools = await cgminer_send(ip, 4028, "pools", timeout=5)
        if not pools:
            return False

        pool_list = pools.get("POOLS", [])
        target_idx = None
        for p in pool_list:
            if target.url in (p.get("URL", "") or "") and target.worker in (p.get("User", "") or ""):
                target_idx = p.get("POOL")
                break

        if target_idx is None:
            target_idx = len(pool_list) - 1

        switch_result = await cgminer_send(ip, 4028, f"switchpool|{target_idx}", timeout=5)
        if switch_result:
            log.info(f"[{ip}] cgminer switchpool → pool {target_idx}")
            return True
        return False

    async def _restore_cgminer(self, ip: str, saved_pools: list[dict]) -> bool:
        if not saved_pools:
            return False
        current = await cgminer_send(ip, 4028, "pools", timeout=5)
        if not current:
            return False
        current_pools = current.get("POOLS", [])

        user_pool = saved_pools[0]
        user_idx = None
        for p in current_pools:
            if user_pool["url"] in (p.get("URL", "") or "") and user_pool["user"] in (p.get("User", "") or ""):
                user_idx = p.get("POOL")
                break

        if user_idx is not None:
            await cgminer_send(ip, 4028, f"switchpool|{user_idx}", timeout=5)
            log.info(f"[{ip}] cgminer restored → pool {user_idx}")
        else:
            add_cmd = f"addpool|{user_pool['url']},{user_pool['user']},{user_pool.get('pass', 'x')}"
            await cgminer_send(ip, 4028, add_cmd, timeout=5)
            await asyncio.sleep(0.5)
            pools2 = await cgminer_send(ip, 4028, "pools", timeout=5)
            if pools2:
                new_pools = pools2.get("POOLS", [])
                new_idx = len(new_pools) - 1
                await cgminer_send(ip, 4028, f"switchpool|{new_idx}", timeout=5)
            log.info(f"[{ip}] cgminer restored via addpool+switchpool")

        for p in current_pools:
            url = p.get("URL", "")
            user = p.get("User", "")
            is_user_pool = any(
                s["url"] in url and s["user"] in user
                for s in saved_pools
            )
            if not is_user_pool:
                idx = p.get("POOL")
                await cgminer_send(ip, 4028, f"removepool|{idx}", timeout=3)

        return True

    # ── Whatsminer ──────────────────────────────────────────────────────────

    async def _read_whatsminer(self, ip: str, kw: dict) -> Optional[list[dict]]:
        password = kw.get("password", "admin")
        cfg = WhatsminerConfig(ip=ip, password=password)
        data = await self._wm.send(cfg, "pools")
        if not data:
            return None
        pools_raw = data.get("POOLS", [])
        return [
            {
                "url": p.get("URL", ""),
                "user": p.get("User", ""),
                "pass": p.get("Pass", "x") if p.get("Pass") else "x",
                "status": p.get("Status", ""),
                "pool_idx": p.get("POOL", i),
            }
            for i, p in enumerate(pools_raw)
        ]

    async def _switch_whatsminer(self, ip: str, target: PoolTarget, kw: dict) -> bool:
        password = kw.get("password", "admin")
        cfg = WhatsminerConfig(ip=ip, password=password)
        log.info(f"[{ip}] whatsminer switch → {target.url} worker={target.worker}")

        current = await self._wm.send(cfg, "pools")
        if not current:
            log.warning(f"[{ip}] whatsminer read pools falhou")
            return False
        current_pools = current.get("POOLS", [])

        p1_url = target.url
        p1_worker = target.worker
        p1_pass = target.password

        p2_url = current_pools[0].get("URL", "") if len(current_pools) > 0 else ""
        p2_worker = current_pools[0].get("User", "") if len(current_pools) > 0 else ""
        p2_pass = "x"

        p3_url = current_pools[1].get("URL", "") if len(current_pools) > 1 else p2_url
        p3_worker = current_pools[1].get("User", "") if len(current_pools) > 1 else p2_worker
        p3_pass = "x"

        result = await self._wm.send(cfg, "update_pools", {
            "pool1": p1_url, "worker1": p1_worker, "passwd1": p1_pass,
            "pool2": p2_url, "worker2": p2_worker, "passwd2": p2_pass,
            "pool3": p3_url, "worker3": p3_worker, "passwd3": p3_pass,
        })
        if result:
            log.info(f"[{ip}] whatsminer update_pools → devfee pool1={target.url}")
            return True
        return False

    async def _restore_whatsminer(self, ip: str, saved_pools: list[dict], kw: dict) -> bool:
        if not saved_pools:
            return False
        password = kw.get("password", "admin")
        cfg = WhatsminerConfig(ip=ip, password=password)

        params = {}
        for i, p in enumerate(saved_pools[:3], 1):
            params[f"pool{i}"] = p["url"]
            params[f"worker{i}"] = p["user"]
            params[f"passwd{i}"] = p.get("pass", "x")

        if len(saved_pools) < 3:
            for i in range(len(saved_pools) + 1, 4):
                params[f"pool{i}"] = saved_pools[0]["url"]
                params[f"worker{i}"] = saved_pools[0]["user"]
                params[f"passwd{i}"] = saved_pools[0].get("pass", "x")

        result = await self._wm.send(cfg, "update_pools", params)
        if result:
            log.info(f"[{ip}] whatsminer pools restaurados")
            return True
        return False

    # ── Vnish ──────────────────────────────────────────────────────────────

    def _vnish_mc(self, ip: str, kw: dict) -> VnishMinerConfig:
        return VnishMinerConfig(
            ip=ip,
            port=kw.get("port", 80),
            user=kw.get("user", "admin"),
            password=kw.get("password", "admin"),
            api_key=kw.get("api_key"),
        )

    async def _read_vnish(self, ip: str, kw: dict) -> Optional[list[dict]]:
        mc = self._vnish_mc(ip, kw)
        data = await self._vnish.get(mc, "/summary")
        if not data:
            log.warning(f"[{ip}] vnish /summary retornou None — read_pools falhou")
            return None
        miner_data = data.get("miner", data)
        pools_raw = miner_data.get("pools", [])
        if not pools_raw:
            top_keys = list(data.keys())[:10]
            miner_keys = list(miner_data.keys())[:15] if isinstance(miner_data, dict) else []
            log.warning(f"[{ip}] vnish /summary sem pools | top_keys={top_keys} miner_keys={miner_keys}")
            return None
        result = [
            {
                "url": p.get("url", ""),
                "user": p.get("user", ""),
                "pass": p.get("pass", "x") if p.get("pass") else "x",
                "status": p.get("status", ""),
                "pool_idx": i,
            }
            for i, p in enumerate(pools_raw)
            if p.get("pool_type", "").lower() != "devfee"
        ]
        log.info(f"[{ip}] vnish read_pools: {len(result)} user pool(s) | pool1={result[0]['url'] if result else 'vazio'} worker={result[0]['user'] if result else 'vazio'}")
        return result

    async def _switch_vnish(self, ip: str, target: PoolTarget, kw: dict) -> bool:
        mc = self._vnish_mc(ip, kw)
        log.info(f"[{ip}] vnish switch → {target.url} worker={target.worker}")

        current = await self._vnish.get(mc, "/summary")
        if not current:
            log.warning(f"[{ip}] vnish switch: /summary falhou — nao consigo ler pools atuais")
            return False
        miner_data = current.get("miner", current)
        current_pools = [
            p for p in miner_data.get("pools", [])
            if p.get("pool_type", "").lower() != "devfee"
        ]

        new_pools = [
            {"url": target.url, "user": target.worker, "pass": target.password},
        ]
        for p in current_pools:
            new_pools.append({"url": p.get("url", ""), "user": p.get("user", ""), "pass": p.get("pass") or "x"})

        try:
            await self._vnish.post(mc, "/settings", {
                "miner": {"pools": {"list": new_pools[:3]}}
            })
            log.info(f"[{ip}] vnish POST /settings OK → pool1={target.url} ({len(new_pools[:3])} pool(s) enviadas)")
        except Exception as e:
            log.error(f"[{ip}] vnish switch POST /settings FALHOU: {e}")
            return False

        await asyncio.sleep(1)
        try:
            verify = await self._vnish.get(mc, "/summary")
            if verify:
                vd = verify.get("miner", verify)
                vp = [p for p in vd.get("pools", []) if p.get("pool_type", "").lower() != "devfee"]
                target_clean = target.url.lower().replace("stratum+tcp://", "").replace("stratum2+tcp://", "").split("/")[0]
                actual_url = (vp[0].get("url", "") if vp else "").lower()
                if vp and target_clean in actual_url:
                    log.info(f"[{ip}] vnish switch VERIFICADO → pool1={vp[0].get('url','')}")
                    return True
                else:
                    log.warning(f"[{ip}] vnish switch NAO VERIFICADO — esperado={target_clean} actual={actual_url}")
                    return True
        except Exception as e:
            log.warning(f"[{ip}] vnish verificacao pos-switch erro: {e}")

        return True

    async def _restore_vnish(self, ip: str, saved_pools: list[dict], kw: dict) -> bool:
        if not saved_pools:
            return False
        mc = self._vnish_mc(ip, kw)
        pool_list = [
            {"url": p["url"], "user": p["user"], "pass": p.get("pass", "x")}
            for p in saved_pools[:3]
        ]
        try:
            await self._vnish.post(mc, "/settings", {
                "miner": {"pools": {"list": pool_list}}
            })
        except Exception as e:
            log.error(f"[{ip}] vnish restore falhou: {e}")
            return False

        await asyncio.sleep(1)
        try:
            verify = await self._vnish.get(mc, "/summary")
            if verify:
                vd = verify.get("miner", verify)
                vp = [p for p in vd.get("pools", []) if p.get("pool_type", "").lower() != "devfee"]
                expected_url = saved_pools[0]["url"].lower().replace("stratum+tcp://", "").replace("stratum2+tcp://", "")
                actual_url = (vp[0].get("url", "") if vp else "").lower()
                if expected_url in actual_url:
                    log.info(f"[{ip}] vnish restore VERIFICADO → pool1={actual_url}")
                else:
                    log.warning(f"[{ip}] vnish restore NAO VERIFICADO — esperado={expected_url} actual={actual_url}")
        except Exception as e:
            log.warning(f"[{ip}] vnish verificacao pos-restore erro: {e}")

        log.info(f"[{ip}] vnish pools restaurados")
        return True
