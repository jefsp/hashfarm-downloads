"""
hashfarm-agent · turbo.py
TURBO AI GO2Mine — Motor de auto-tuning inteligente.
Monitora KPIs a cada tick (~30s) e ajusta presets para maximizar
hashrate mantendo seguranca termica. Suporta Vnish, BrainOS e Whatsminer.
Bitmain stock apenas monitoramento (alertas).
"""

import json
import logging
import re
import time
from dataclasses import dataclass, field
from datetime import date
from typing import Callable, Optional, Awaitable

log = logging.getLogger("hashfarm.turbo")

PROFILES = {
    "conservador": {
        "temp_safe": 72, "temp_caution": 78, "temp_emergency": 88,
        "hw_err_caution": 1.5, "hw_err_emergency": 4.0,
        "fan_duty_caution": 90, "fan_duty_safe": 75,
        "max_oc_steps": 1,
        "safe_ticks_to_up": 12,
        "unsafe_ticks_to_down": 2,
        "cooldown_emergency_s": 300,
        "cooldown_normal_s": 240,
    },
    "normal": {
        "temp_safe": 76, "temp_caution": 80, "temp_emergency": 90,
        "hw_err_caution": 2.0, "hw_err_emergency": 5.0,
        "fan_duty_caution": 95, "fan_duty_safe": 80,
        "max_oc_steps": 2,
        "safe_ticks_to_up": 10,
        "unsafe_ticks_to_down": 2,
        "cooldown_emergency_s": 300,
        "cooldown_normal_s": 180,
    },
    "arrojado": {
        "temp_safe": 79, "temp_caution": 83, "temp_emergency": 93,
        "hw_err_caution": 2.5, "hw_err_emergency": 5.0,
        "fan_duty_caution": 97, "fan_duty_safe": 85,
        "max_oc_steps": 3,
        "safe_ticks_to_up": 8,
        "unsafe_ticks_to_down": 3,
        "cooldown_emergency_s": 300,
        "cooldown_normal_s": 150,
    },
}

WM_POWER_LADDER = ["Low", "Normal", "High"]
_WATT_RE = re.compile(r"(\d+)\s*[Ww]")


def _parse_wattage(preset_name: str) -> int:
    m = _WATT_RE.search(preset_name)
    return int(m.group(1)) if m else 0


def _sort_presets(presets: list[str]) -> list[str]:
    return sorted(presets, key=lambda p: (_parse_wattage(p), p))


@dataclass
class TurboDecision:
    action: str = "hold"
    from_preset: str = ""
    to_preset: str = ""
    reason: str = ""
    state: str = "stable"

    def to_dict(self) -> dict:
        return {
            "action": self.action,
            "from_preset": self.from_preset,
            "to_preset": self.to_preset,
            "reason": self.reason,
            "state": self.state,
        }


@dataclass
class MinerTurboState:
    ip: str = ""
    firmware: str = ""
    current_preset: str = ""
    base_preset: str = ""
    turbo_offset: int = 0
    last_change_ts: float = 0.0
    safe_ticks: int = 0
    unsafe_ticks: int = 0
    stock_hr_ths: float = 0.0
    hr_accumulator: float = 0.0
    power_accumulator: float = 0.0
    ticks_today: int = 0
    today: str = ""


class TurboEngine:
    def __init__(self, store=None):
        self._store = store
        self._states: dict[str, MinerTurboState] = {}
        self._config: Optional[dict] = None
        self._available_presets: dict[str, list[str]] = {}
        self._preset_fetch_ts: dict[str, float] = {}
        self._last_report_ts: float = 0.0

    def set_config(self, config: dict):
        self._config = config
        log.info(f"[turbo] config: enabled={config.get('enabled')} profile={config.get('profile', 'normal')}")

    @property
    def enabled(self) -> bool:
        return bool(self._config and self._config.get("enabled"))

    @property
    def _profile(self) -> dict:
        name = (self._config or {}).get("profile", "normal")
        return PROFILES.get(name, PROFILES["normal"])

    def set_presets(self, ip: str, presets: list[str]):
        sorted_p = _sort_presets([p for p in presets if p and p != "__disabled__"])
        if sorted_p:
            self._available_presets[ip] = sorted_p
            self._preset_fetch_ts[ip] = time.time()
            log.info(f"[{ip}] turbo presets: {sorted_p}")

    def _get_state(self, ip: str) -> MinerTurboState:
        today = str(date.today())
        state = self._states.get(ip)
        if not state:
            state = MinerTurboState(ip=ip, today=today)
            self._states[ip] = state
        if state.today != today:
            if self._store and state.ticks_today > 0:
                avg_hr = state.hr_accumulator / state.ticks_today if state.ticks_today else 0
                avg_pw = state.power_accumulator / state.ticks_today if state.ticks_today else 0
                self._store.save_turbo_gains(
                    ip, state.today, state.stock_hr_ths, avg_hr, avg_pw, avg_pw, state.ticks_today
                )
            state.hr_accumulator = 0.0
            state.power_accumulator = 0.0
            state.ticks_today = 0
            state.today = today
        return state

    def _get_preset_index(self, ip: str, preset: str) -> int:
        presets = self._available_presets.get(ip, [])
        for i, p in enumerate(presets):
            if p == preset:
                return i
        return -1

    def _get_preset_at(self, ip: str, index: int) -> Optional[str]:
        presets = self._available_presets.get(ip, [])
        if 0 <= index < len(presets):
            return presets[index]
        return None

    def _wm_index(self, mode: str) -> int:
        try:
            return WM_POWER_LADDER.index(mode)
        except ValueError:
            return 1

    async def tick(
        self,
        ip: str,
        kpis: dict,
        firmware: str,
        apply_fn: Callable[..., Awaitable[bool]],
    ) -> TurboDecision:
        if not self.enabled:
            return TurboDecision(state="disabled")

        prof = self._profile
        state = self._get_state(ip)
        state.firmware = firmware

        chip_temp = kpis.get("chip_temp_max") or 0
        hw_err = kpis.get("hw_errors_pct") or 0.0
        fan_duty = kpis.get("fan_duty") or 0
        hr_real = kpis.get("hr_realtime_ths") or 0.0
        hr_stock = kpis.get("hr_stock_ths") or 0.0
        power_w = kpis.get("power_w") or 0
        current_preset = kpis.get("current_preset") or ""
        fans = kpis.get("fans") or []

        if hr_stock > 0:
            state.stock_hr_ths = hr_stock

        state.hr_accumulator += hr_real
        state.power_accumulator += power_w
        state.ticks_today += 1

        if self._store and state.ticks_today % 10 == 0:
            self._store.save_turbo_gains(
                ip, state.today, state.stock_hr_ths,
                state.hr_accumulator / state.ticks_today if state.ticks_today else 0,
                0, state.power_accumulator / state.ticks_today if state.ticks_today else 0,
                state.ticks_today,
            )

        if current_preset and state.current_preset != current_preset:
            if state.current_preset and state.current_preset != current_preset:
                if time.time() - state.last_change_ts > 10:
                    log.info(f"[{ip}] schedule detected: {state.current_preset} → {current_preset}")
                    state.base_preset = current_preset
                    state.turbo_offset = 0
                    state.safe_ticks = 0
                    state.unsafe_ticks = 0
            state.current_preset = current_preset
            if not state.base_preset:
                state.base_preset = current_preset

        fan_dead = any(
            f.get("rpm", 1) == 0 and f.get("status", "").lower() in ("lost", "dead", "")
            for f in fans
        )

        is_emergency = (
            chip_temp >= prof["temp_emergency"]
            or hw_err >= prof["hw_err_emergency"]
            or fan_dead
        )
        is_caution = (
            chip_temp >= prof["temp_caution"]
            or hw_err >= prof["hw_err_caution"]
            or fan_duty >= prof["fan_duty_caution"]
        )
        is_safe = (
            chip_temp <= prof["temp_safe"]
            and hw_err < 0.5
            and fan_duty <= prof["fan_duty_safe"]
        )

        now = time.time()
        decision = TurboDecision(from_preset=state.current_preset)

        if is_emergency:
            state.safe_ticks = 0
            state.unsafe_ticks += 1
            cooldown = prof["cooldown_emergency_s"]
            if now - state.last_change_ts >= cooldown:
                new_preset = self._step_down(ip, firmware, state, steps=2)
                if new_preset and new_preset != state.current_preset:
                    reason = f"emergency chip={chip_temp} hw={hw_err:.1f}% fan_dead={fan_dead}"
                    ok = await self._apply(ip, firmware, new_preset, apply_fn)
                    if ok:
                        decision = TurboDecision("down", state.current_preset, new_preset, reason, "emergency")
                        state.current_preset = new_preset
                        state.last_change_ts = now
                        self._log_action(ip, decision)
                    return decision
            decision.state = "emergency"
            return decision

        if is_caution:
            state.safe_ticks = 0
            state.unsafe_ticks += 1
            if state.unsafe_ticks >= prof["unsafe_ticks_to_down"]:
                cooldown = prof["cooldown_normal_s"]
                if now - state.last_change_ts >= cooldown:
                    new_preset = self._step_down(ip, firmware, state, steps=1)
                    if new_preset and new_preset != state.current_preset:
                        reason = f"caution chip={chip_temp} hw={hw_err:.1f}% fan={fan_duty}%"
                        ok = await self._apply(ip, firmware, new_preset, apply_fn)
                        if ok:
                            decision = TurboDecision("down", state.current_preset, new_preset, reason, "caution")
                            state.current_preset = new_preset
                            state.last_change_ts = now
                            state.unsafe_ticks = 0
                            self._log_action(ip, decision)
                        return decision
            decision.state = "caution"
            return decision

        if is_safe:
            state.unsafe_ticks = 0
            state.safe_ticks += 1
            if state.safe_ticks >= prof["safe_ticks_to_up"]:
                cooldown = prof["cooldown_normal_s"]
                if now - state.last_change_ts >= cooldown:
                    new_preset = self._step_up(ip, firmware, state, prof["max_oc_steps"])
                    if new_preset and new_preset != state.current_preset:
                        reason = f"overclock chip={chip_temp} hw={hw_err:.1f}% fan={fan_duty}% safe_ticks={state.safe_ticks}"
                        ok = await self._apply(ip, firmware, new_preset, apply_fn)
                        if ok:
                            decision = TurboDecision("up", state.current_preset, new_preset, reason, "overclock")
                            state.current_preset = new_preset
                            state.last_change_ts = now
                            state.safe_ticks = 0
                            self._log_action(ip, decision)
                        return decision
            decision.state = "safe"
            return decision

        state.unsafe_ticks = 0
        state.safe_ticks = 0
        decision.state = "stable"
        return decision

    def _step_down(self, ip: str, firmware: str, state: MinerTurboState, steps: int = 1) -> Optional[str]:
        if firmware == "whatsminer":
            idx = self._wm_index(state.current_preset)
            new_idx = max(0, idx - steps)
            return WM_POWER_LADDER[new_idx]
        presets = self._available_presets.get(ip, [])
        if not presets:
            return None
        idx = self._get_preset_index(ip, state.current_preset)
        if idx < 0:
            return presets[0]
        new_idx = max(0, idx - steps)
        state.turbo_offset = new_idx - self._get_preset_index(ip, state.base_preset)
        return presets[new_idx]

    def _step_up(self, ip: str, firmware: str, state: MinerTurboState, max_oc: int) -> Optional[str]:
        if firmware == "whatsminer":
            idx = self._wm_index(state.current_preset)
            new_idx = min(len(WM_POWER_LADDER) - 1, idx + 1)
            return WM_POWER_LADDER[new_idx]
        presets = self._available_presets.get(ip, [])
        if not presets:
            return None
        idx = self._get_preset_index(ip, state.current_preset)
        base_idx = self._get_preset_index(ip, state.base_preset)
        if idx < 0 or base_idx < 0:
            return None
        max_idx = min(base_idx + max_oc, len(presets) - 1)
        new_idx = min(idx + 1, max_idx)
        state.turbo_offset = new_idx - base_idx
        return presets[new_idx]

    async def _apply(self, ip: str, firmware: str, preset: str, apply_fn) -> bool:
        try:
            ok = await apply_fn(ip, preset)
            if ok:
                log.info(f"[{ip}] turbo applied: {preset}")
                if self._store:
                    self._store.save_turbo_state(
                        ip, preset,
                        self._states.get(ip, MinerTurboState()).base_preset,
                        self._states.get(ip, MinerTurboState()).safe_ticks,
                        self._states.get(ip, MinerTurboState()).unsafe_ticks,
                    )
            return bool(ok)
        except Exception as e:
            log.warning(f"[{ip}] turbo apply failed: {e}")
            return False

    def _log_action(self, ip: str, decision: TurboDecision):
        log.info(f"[{ip}] TURBO {decision.action}: {decision.from_preset} → {decision.to_preset} ({decision.reason})")
        if self._store:
            self._store.save_turbo_action(
                ip, decision.from_preset, decision.to_preset, decision.reason
            )

    def monitor_only(self, ip: str, kpis: dict) -> Optional[dict]:
        prof = self._profile
        chip_temp = kpis.get("chip_temp_max") or 0
        hw_err = kpis.get("hw_errors_pct") or 0.0
        fans = kpis.get("fans") or []
        fan_dead = any(
            f.get("rpm", 1) == 0 and f.get("status", "").lower() in ("lost", "dead", "")
            for f in fans
        )

        state = self._get_state(ip)
        hr_real = kpis.get("hr_realtime_ths") or 0.0
        hr_stock = kpis.get("hr_stock_ths") or 0.0
        power_w = kpis.get("power_w") or 0
        if hr_stock > 0:
            state.stock_hr_ths = hr_stock
        state.hr_accumulator += hr_real
        state.power_accumulator += power_w
        state.ticks_today += 1

        alerts = []
        if chip_temp >= prof["temp_emergency"]:
            alerts.append(f"temp_critica:{chip_temp}°C")
        elif chip_temp >= prof["temp_caution"]:
            alerts.append(f"temp_alta:{chip_temp}°C")
        if hw_err >= prof["hw_err_emergency"]:
            alerts.append(f"hw_err:{hw_err:.1f}%")
        if fan_dead:
            alerts.append("fan_morto")

        if alerts:
            return {"ip": ip, "firmware": "bitmain_stock", "alerts": alerts, "state": "alert"}
        return None

    def get_report(self) -> list[dict]:
        rows = []
        for ip, state in self._states.items():
            avg_hr = state.hr_accumulator / state.ticks_today if state.ticks_today > 0 else 0
            gain_pct = (avg_hr / state.stock_hr_ths - 1) * 100 if state.stock_hr_ths > 0 and avg_hr > 0 else 0
            rows.append({
                "ip": ip,
                "firmware": state.firmware,
                "current_preset": state.current_preset,
                "base_preset": state.base_preset,
                "stock_hr_ths": round(state.stock_hr_ths, 2),
                "turbo_hr_ths": round(avg_hr, 2),
                "gain_pct": round(gain_pct, 2),
                "offset": state.turbo_offset,
                "ticks": state.ticks_today,
                "state": "active",
            })
        return rows
