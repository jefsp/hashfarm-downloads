"""
hashfarm-agent · updater.py
Auto-update: download, apply on startup, rollback on failure.
"""

import asyncio
import hashlib
import json
import logging
import os
import platform
import shutil
import subprocess
import sys
import zipfile
import tarfile
from datetime import datetime, timezone
from pathlib import Path

log = logging.getLogger("hashfarm.updater")

GITHUB_BASE = "https://app.go2mine.com/api/v1/farms/agent-package"
WINDOWS_PKG = "hashfarm-agent-windows.zip"
LINUX_PKG = "hashfarm-agent-linux.tar.gz"

TASK_NAME = "go2mine hashfarm-agent"
SERVICE_NAME = "hashfarm-agent"


def _is_windows() -> bool:
    return platform.system() == "Windows"


def get_install_dir() -> Path:
    return Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _parse_version(v: str) -> tuple:
    try:
        return tuple(int(x) for x in v.split(".")[:3])
    except Exception:
        return (0, 0, 0)


# ── PHASE 2: Download ────────────────────────────────────────────────────────

async def trigger_update(latest_version: str, download_base: str = None):
    from . import __version__
    if _parse_version(latest_version) <= _parse_version(__version__):
        return

    install_dir = get_install_dir()
    update_dir = install_dir / "update"
    manifest = update_dir / "manifest.json"

    if manifest.exists():
        try:
            data = json.loads(manifest.read_text())
            if data.get("version") == latest_version:
                pkg_file = update_dir / data.get("file", "")
                if pkg_file.exists():
                    log.info(f"Update v{latest_version} já baixado — reaplicando")
                    _trigger_restart(install_dir)
                else:
                    log.warning(f"Manifest existe mas pacote sumiu — rebaixando")
                    shutil.rmtree(update_dir, ignore_errors=True)
        except Exception:
            shutil.rmtree(update_dir, ignore_errors=True)

    base_url = download_base or GITHUB_BASE
    log.info(f"Iniciando download da atualização v{latest_version} (install_dir={install_dir})")

    try:
        update_dir.mkdir(parents=True, exist_ok=True)
        pkg_name = WINDOWS_PKG if _is_windows() else LINUX_PKG
        url = f"{base_url}/{pkg_name}"
        dest = update_dir / pkg_name

        log.info(f"Baixando {url} → {dest}")
        sha256 = await _download(url, dest)
        if not sha256:
            raise RuntimeError("Download falhou — sha256 None")

        size = dest.stat().st_size
        log.info(f"Download OK: {size} bytes, sha256={sha256[:12]}...")

        manifest.write_text(json.dumps({
            "version": latest_version,
            "file": pkg_name,
            "sha256": sha256,
            "downloaded_at": datetime.now(timezone.utc).isoformat(),
            "platform": "windows" if _is_windows() else "linux",
        }))

        log.info("Manifest escrito. Reiniciando para aplicar...")
        _trigger_restart(install_dir)

    except Exception as e:
        import traceback
        log.error(f"Erro no auto-update: {e}\n{traceback.format_exc()}")
        shutil.rmtree(update_dir, ignore_errors=True)


async def _download(url: str, dest: Path) -> str | None:
    import aiohttp
    import ssl as _ssl

    for attempt, ssl_ctx in enumerate([None, False]):
        sha = hashlib.sha256()
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url, allow_redirects=True,
                                       timeout=aiohttp.ClientTimeout(total=300),
                                       ssl=ssl_ctx) as resp:
                    if resp.status != 200:
                        log.error(f"Download falhou: HTTP {resp.status}")
                        return None
                    with open(dest, "wb") as f:
                        async for chunk in resp.content.iter_chunked(8192):
                            f.write(chunk)
                            sha.update(chunk)
            return sha.hexdigest()
        except (aiohttp.ClientConnectorCertificateError, _ssl.SSLCertVerificationError):
            dest.unlink(missing_ok=True)
            if attempt == 0:
                log.warning("SSL cert verification failed, retrying without verification...")
                continue
            log.error("Download failed even without SSL verification")
            return None
        except Exception as e:
            log.error(f"Erro no download: {e}")
            dest.unlink(missing_ok=True)
            return None
    return None


def _trigger_restart(install_dir: Path):
    if _is_windows():
        python = str(install_dir / "venv" / "Scripts" / "python.exe")
        script = install_dir / "_restart_update.py"
        script.write_text(
            "import time, subprocess, sys, os\n"
            "time.sleep(5)\n"
            f"os.chdir(r'{install_dir}')\n"
            f"subprocess.Popen([r'{python}', '-m', 'agent'])\n",
            encoding="utf-8",
        )
        subprocess.Popen(
            [python, str(script)],
            creationflags=0x00000008 | 0x08000000,
            cwd=str(install_dir),
        )
        log.info("Restart via _restart_update.py — saindo em 2s")
        import time
        time.sleep(2)
        os._exit(0)
    else:
        log.info("Saindo para aplicar atualização (systemd reiniciará automaticamente)")
        os._exit(0)


# ── PHASE 3: Apply on startup ────────────────────────────────────────────────

def apply_pending_update() -> bool:
    install_dir = get_install_dir()
    update_dir = install_dir / "update"
    manifest_file = update_dir / "manifest.json"
    agent_dir = install_dir / "agent"
    backup_dir = install_dir / "agent_backup"
    marker = install_dir / ".update_pending"

    if not manifest_file.exists():
        return False

    try:
        manifest = json.loads(manifest_file.read_text())
    except Exception:
        shutil.rmtree(update_dir, ignore_errors=True)
        return False

    version = manifest.get("version", "?")
    pkg_file = update_dir / manifest.get("file", "")
    expected_sha = manifest.get("sha256", "")

    if not pkg_file.exists():
        print(f"[updater] Pacote {pkg_file} não encontrado, limpando")
        shutil.rmtree(update_dir, ignore_errors=True)
        return False

    actual_sha = hashlib.sha256(pkg_file.read_bytes()).hexdigest()
    if expected_sha and actual_sha != expected_sha:
        print(f"[updater] Checksum inválido, esperado {expected_sha[:12]}... obtido {actual_sha[:12]}...")
        shutil.rmtree(update_dir, ignore_errors=True)
        return False

    print(f"[updater] Aplicando atualização para v{version}... (pkg={pkg_file}, size={pkg_file.stat().st_size})")

    if backup_dir.exists():
        shutil.rmtree(backup_dir, ignore_errors=True)

    try:
        print(f"[updater] Criando backup: {agent_dir} → {backup_dir}")
        shutil.copytree(agent_dir, backup_dir)
    except Exception as e:
        print(f"[updater] Erro ao criar backup: {e}")
        shutil.rmtree(update_dir, ignore_errors=True)
        return False

    marker.write_text(json.dumps({
        "version": version,
        "applied_at": datetime.now(timezone.utc).isoformat(),
        "crash_count": 0,
    }))

    extract_dir = update_dir / "extracted"
    try:
        if pkg_file.suffix == ".zip":
            with zipfile.ZipFile(pkg_file) as zf:
                zf.extractall(extract_dir)
        else:
            extract_dir.mkdir(parents=True, exist_ok=True)
            with tarfile.open(pkg_file, "r:gz") as tf:
                tf.extractall(extract_dir)

        new_agent = _find_agent_dir(extract_dir)
        if not new_agent:
            contents = list(extract_dir.rglob("*"))[:20]
            raise FileNotFoundError(f"Pasta agent/ não encontrada. Conteúdo: {[str(c.relative_to(extract_dir)) for c in contents]}")

        print(f"[updater] agent/ encontrado em {new_agent}")
        if (new_agent / "__init__.py").exists():
            shutil.rmtree(agent_dir)
            shutil.copytree(new_agent, agent_dir)
            print(f"[updater] agent/ copiado para {agent_dir}")
        else:
            raise FileNotFoundError("__init__.py não encontrado no pacote")

        new_req = _find_file(extract_dir, "requirements.txt")
        if new_req:
            shutil.copy2(new_req, install_dir / "requirements.txt")

        for script in ["Update-agent.bat", "update-linux.sh", "Install-agent.bat",
                        "Uninstall-agent.bat", "Restart-agent.bat",
                        "install-linux.sh", "uninstall-linux.sh", "restart-linux.sh",
                        "_install.ps1", "_uninstall.ps1"]:
            src = _find_file(extract_dir, script)
            if src:
                shutil.copy2(src, install_dir / script)

        _pip_install(install_dir)

    except Exception as e:
        print(f"[updater] Erro ao extrair/aplicar: {e} — restaurando backup")
        if backup_dir.exists():
            shutil.rmtree(agent_dir, ignore_errors=True)
            shutil.copytree(backup_dir, agent_dir)
        shutil.rmtree(update_dir, ignore_errors=True)
        marker.unlink(missing_ok=True)
        return False

    shutil.rmtree(update_dir, ignore_errors=True)
    print(f"[updater] Atualização v{version} aplicada com sucesso")
    return True


def _find_agent_dir(extract_dir: Path) -> Path | None:
    if (extract_dir / "agent").is_dir():
        return extract_dir / "agent"
    for child in extract_dir.iterdir():
        if child.is_dir() and (child / "agent").is_dir():
            return child / "agent"
    return None


def _find_file(extract_dir: Path, name: str) -> Path | None:
    if (extract_dir / name).is_file():
        return extract_dir / name
    for child in extract_dir.iterdir():
        if child.is_dir() and (child / name).is_file():
            return child / name
    return None


def _pip_install(install_dir: Path):
    if _is_windows():
        pip = install_dir / "venv" / "Scripts" / "pip.exe"
    else:
        pip = install_dir / "venv" / "bin" / "pip"
    req = install_dir / "requirements.txt"
    if pip.exists() and req.exists():
        try:
            subprocess.run(
                [str(pip), "install", "--quiet", "--upgrade", "-r", str(req)],
                timeout=120, capture_output=True,
            )
        except Exception as e:
            print(f"[updater] Aviso: pip install falhou: {e}")


# ── PHASE 4: Rollback ────────────────────────────────────────────────────────

def check_rollback() -> bool:
    install_dir = get_install_dir()
    backup_dir = install_dir / "agent_backup"
    marker = install_dir / ".update_pending"

    if not backup_dir.exists() or not marker.exists():
        if backup_dir.exists() and not marker.exists():
            shutil.rmtree(backup_dir, ignore_errors=True)
        return False

    try:
        data = json.loads(marker.read_text())
    except Exception:
        marker.unlink(missing_ok=True)
        shutil.rmtree(backup_dir, ignore_errors=True)
        return False

    crash_count = data.get("crash_count", 0) + 1
    data["crash_count"] = crash_count
    marker.write_text(json.dumps(data))

    if crash_count >= 3:
        version = data.get("version", "?")
        print(f"[updater] ROLLBACK: v{version} crashou {crash_count}x — restaurando backup")
        agent_dir = install_dir / "agent"
        try:
            shutil.rmtree(agent_dir, ignore_errors=True)
            shutil.copytree(backup_dir, agent_dir)
            shutil.rmtree(backup_dir, ignore_errors=True)
            marker.unlink(missing_ok=True)
            print("[updater] Rollback concluído — reiniciando com versão anterior")
            return True
        except Exception as e:
            print(f"[updater] Erro no rollback: {e}")

    return False


async def confirm_update_success():
    await asyncio.sleep(120)
    install_dir = get_install_dir()
    marker = install_dir / ".update_pending"
    backup_dir = install_dir / "agent_backup"
    if marker.exists():
        marker.unlink(missing_ok=True)
    if backup_dir.exists():
        shutil.rmtree(backup_dir, ignore_errors=True)
    log.info("Atualização confirmada com sucesso")
