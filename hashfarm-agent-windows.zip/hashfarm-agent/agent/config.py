"""
hashfarm-agent · config.py · v1.0
Configuração via arquivo TOML + variáveis de ambiente.

Prioridade: env vars > config.toml > defaults.
"""

import json
import os
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

log = logging.getLogger("hashfarm.config")

# Tenta importar tomllib (Python 3.11+) ou tomli (backport)
try:
    import tomllib
except ImportError:
    try:
        import tomli as tomllib
    except ImportError:
        tomllib = None


@dataclass
class MinerEntry:
    ip: str
    port: int = 80
    user: str = "admin"
    password: str = "admin"
    api_key: Optional[str] = None
    label: Optional[str] = None
    preset_day_w: Optional[int] = None
    preset_night_w: Optional[int] = None
    firmware_hint: Optional[str] = None   # força firmware: "vnish"|"whatsminer"|"bitmain_stock"|"braiins"


@dataclass
class CloudConfig:
    url: str = "wss://app.go2mine.com/ws/agent"
    agent_key: str = ""
    reconnect_delay: int = 1       # segundos
    reconnect_max: int = 8         # backoff máximo (reduzido para reagir rápido)
    heartbeat_interval: int = 30


@dataclass
class CollectorConfig:
    interval: int = 15              # segundos entre polls (reduzido para sync mais rápida)
    temp_warn: int = 85             # °C para alarme
    parallel_limit: int = 10        # máx requests simultâneos por IP


@dataclass
class StoreConfig:
    path: str = "hashfarm.db"      # SQLite
    max_queue: int = 10_000        # registros na fila offline


@dataclass
class AgentConfig:
    miners: list[MinerEntry] = field(default_factory=list)
    cloud: CloudConfig = field(default_factory=CloudConfig)
    collector: CollectorConfig = field(default_factory=CollectorConfig)
    store: StoreConfig = field(default_factory=StoreConfig)
    log_level: str = "INFO"


_MINERS_CACHE = "miners_cache.json"


def save_miners_cache(miners: list) -> None:
    try:
        data = [
            {"ip": m.ip, "port": m.port, "user": m.user, "password": m.password,
             "label": m.label, "firmware_hint": m.firmware_hint}
            for m in miners
        ]
        Path(_MINERS_CACHE).write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception as e:
        log.warning(f"Falha ao salvar cache de miners: {e}")


def _load_miners_cache() -> list:
    path = Path(_MINERS_CACHE)
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return [
            MinerEntry(
                ip=m["ip"],
                port=m.get("port", 80),
                user=m.get("user", "admin"),
                password=m.get("password", "admin"),
                label=m.get("label"),
                firmware_hint=m.get("firmware_hint"),
            )
            for m in data if m.get("ip")
        ]
    except Exception as e:
        log.warning(f"Falha ao carregar cache de miners: {e}")
        return []


def load_config(path: str = "config.toml") -> AgentConfig:
    """
    Carrega configuração do arquivo TOML e sobrescreve com env vars.
    Não falha se o arquivo não existir — usa defaults.
    """
    cfg = AgentConfig()
    raw = {}

    config_path = Path(path)
    if config_path.exists():
        if tomllib is None:
            log.error(
                "Arquivo config.toml encontrado mas nem tomllib nem tomli "
                "estão instalados. Instale: pip install tomli"
            )
        else:
            with open(config_path, "r", encoding="utf-8-sig") as f:
                raw = tomllib.loads(f.read())
            log.info(f"Config carregado de {config_path.absolute()}")
    else:
        log.info(f"config.toml não encontrado em {config_path.absolute()}, usando defaults")

    # --- Miners ---
    for m in raw.get("miners", []):
        cfg.miners.append(MinerEntry(
            ip=m["ip"],
            port=m.get("port", 80),
            user=m.get("user", "admin"),
            password=m.get("password", "admin"),
            api_key=m.get("api_key"),
            label=m.get("label"),
            preset_day_w=m.get("preset_day_w"),
            preset_night_w=m.get("preset_night_w"),
        ))

    # --- Cloud ---
    c = raw.get("cloud", {})
    cfg.cloud.url = c.get("url", cfg.cloud.url)
    cfg.cloud.agent_key = c.get("agent_key", cfg.cloud.agent_key)
    cfg.cloud.reconnect_delay = c.get("reconnect_delay", cfg.cloud.reconnect_delay)
    cfg.cloud.reconnect_max = c.get("reconnect_max", cfg.cloud.reconnect_max)

    # --- Collector ---
    co = raw.get("collector", {})
    cfg.collector.interval = co.get("interval", cfg.collector.interval)
    cfg.collector.temp_warn = co.get("temp_warn", cfg.collector.temp_warn)
    cfg.collector.parallel_limit = co.get("parallel_limit", cfg.collector.parallel_limit)

    # --- Store ---
    st = raw.get("store", {})
    cfg.store.path = st.get("path", cfg.store.path)
    cfg.store.max_queue = st.get("max_queue", cfg.store.max_queue)

    # --- Log ---
    cfg.log_level = raw.get("log_level", cfg.log_level)

    # --- Cache local: se config.toml não tem miners, usa cache do último miners_updated ---
    if not cfg.miners:
        cached = _load_miners_cache()
        if cached:
            cfg.miners = cached
            log.info(f"Config: {len(cached)} miner(s) carregados do cache local (miners_cache.json)")

    # --- Env vars sobrescrevem tudo ---
    _apply_env(cfg)

    return cfg


def _apply_env(cfg: AgentConfig):
    """Env vars com prefixo HF_ sobrescrevem o config.toml."""
    if key := os.getenv("HF_AGENT_KEY"):
        cfg.cloud.agent_key = key

    if url := os.getenv("HF_CLOUD_URL"):
        cfg.cloud.url = url

    if interval := os.getenv("HF_INTERVAL"):
        cfg.collector.interval = int(interval)

    if level := os.getenv("HF_LOG_LEVEL"):
        cfg.log_level = level.upper()

    # IPs adicionados via env (útil para containers): HF_MINERS=192.168.1.1,192.168.1.2
    if ips_env := os.getenv("HF_MINERS"):
        default_pass = os.getenv("HF_MINER_PASS", "admin")
        default_user = os.getenv("HF_MINER_USER", "admin")
        existing_ips = {m.ip for m in cfg.miners}
        for ip in ips_env.split(","):
            ip = ip.strip()
            if ip and ip not in existing_ips:
                cfg.miners.append(MinerEntry(
                    ip=ip,
                    user=default_user,
                    password=default_pass,
                ))
