@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "If(-not([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){Start-Process cmd -ArgumentList '/c \"%~s0\"' -Verb RunAs;exit}" ^
  ; $task='go2mine hashfarm-agent'; ^
  Write-Host '  Reiniciando agente go2mine...' -ForegroundColor Cyan; ^
  $t=Get-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue; ^
  if(-not $t){Write-Host '  [ERRO] Tarefa nao encontrada. Execute Install-agent.bat primeiro.' -ForegroundColor Red;pause;exit 1}; ^
  if($t.State -eq 'Running'){Stop-ScheduledTask -TaskName $task -ErrorAction SilentlyContinue;Start-Sleep 3}; ^
  Start-ScheduledTask -TaskName $task; ^
  Start-Sleep 4; ^
  $s=(Get-ScheduledTask -TaskName $task).State; ^
  if($s -eq 'Running'){Write-Host '  [OK] Agente reiniciado com sucesso!' -ForegroundColor Green}else{Write-Host "  [AVISO] Estado: $s - verifique C:\hashfarm-agent\agent.log" -ForegroundColor Yellow}; ^
  pause
