#Requires -Version 5.1
<#
.SYNOPSIS
    go2mine hashfarm-agent - Windows Installer
.DESCRIPTION
    Instala o hashfarm-agent como servico do Windows (Task Scheduler).
    Requer Python 3.9+ instalado.
.PARAMETER AgentKey
    Sua Agent Key do dashboard go2mine.com (opcional - pode ser configurada depois).
.PARAMETER InstallDir
    Diretorio de instalacao (padrao: C:\hashfarm-agent).
.EXAMPLE
    .\_install.ps1 -AgentKey "sua-chave-aqui"
.EXAMPLE
    .\_install.ps1 -InstallDir "D:\hashfarm-agent"
#>

param(
    [string]$AgentKey   = "",
    [string]$InstallDir = "C:\hashfarm-agent"
)

$DASHBOARD_URL  = "https://app.go2mine.com"
$TASK_NAME      = "go2mine hashfarm-agent"
$LOG_PATH       = "$InstallDir\install.log"
$ErrorActionPreference = "Stop"

# ── Cores / helpers ──────────────────────────────────────────
function Ok($msg)   { Write-Host "  [OK] $msg" -ForegroundColor Green }
function Info($msg) { Write-Host "  -->  $msg" -ForegroundColor Cyan }
function Warn($msg) { Write-Host "  [!]  $msg" -ForegroundColor Yellow }
function Die($msg)  { Write-Host "  [X]  $msg" -ForegroundColor Red; exit 1 }
function Hdr($msg)  { Write-Host "`n  $msg" -ForegroundColor White }

# ── Banner ───────────────────────────────────────────────────
Clear-Host
Write-Host ""
Write-Host "  =============================================" -ForegroundColor Cyan
Write-Host "   GO2Mine - hashfarm-agent - Instalador"       -ForegroundColor White
Write-Host "   $DASHBOARD_URL"                               -ForegroundColor DarkCyan
Write-Host "  =============================================" -ForegroundColor Cyan
Write-Host ""

# ── Admin ────────────────────────────────────────────────────
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
if (-not $isAdmin) {
    Die "Execute este script como Administrador (clique direito -> 'Executar como administrador')"
}

if (-not (Test-Path $InstallDir)) { New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
Start-Transcript -Path $LOG_PATH -Append -NoClobber:$false | Out-Null

# ── Python 3.9+ ──────────────────────────────────────────────
Hdr "1/5  Verificando Python"
$pythonCmd = $null
foreach ($cmd in @("python", "python3", "py")) {
    try {
        $ver = & $cmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
        $major, $minor = $ver.Split(".")
        if ([int]$major -ge 3 -and [int]$minor -ge 9) {
            $pythonCmd = $cmd
            Ok "Encontrado: $cmd (v$ver)"
            break
        }
    } catch { }
}

if (-not $pythonCmd) {
    Warn "Python 3.9+ nao encontrado. Baixando automaticamente..."
    $pyUrl  = "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
    $pyExe  = "$env:TEMP\python-installer.exe"
    try {
        Info "Baixando Python 3.11.9 (~25 MB)..."
        Invoke-WebRequest -Uri $pyUrl -OutFile $pyExe -UseBasicParsing
        Info "Instalando Python silenciosamente..."
        $proc = Start-Process -FilePath $pyExe -ArgumentList @("/quiet","InstallAllUsers=1","PrependPath=1","Include_test=0") -Wait -PassThru
        Remove-Item $pyExe -Force -ErrorAction SilentlyContinue
        if ($proc.ExitCode -ne 0) { Die "Instalador do Python falhou (codigo $($proc.ExitCode)). Instale manualmente em https://www.python.org/downloads/" }
        $machinePath = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
        $userPath    = [System.Environment]::GetEnvironmentVariable("Path", "User")
        $env:Path    = $machinePath + ";" + $userPath
        Ok "Python instalado com sucesso."
    } catch {
        Remove-Item $pyExe -Force -ErrorAction SilentlyContinue
        Die "Nao foi possivel baixar/instalar Python. Instale manualmente em https://www.python.org/downloads/ marcando 'Add Python to PATH'."
    }

    foreach ($cmd in @("python", "python3", "py")) {
        try {
            $ver = & $cmd -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
            $major, $minor = $ver.Split(".")
            if ([int]$major -ge 3 -and [int]$minor -ge 9) {
                $pythonCmd = $cmd; Ok "Python detectado: $cmd (v$ver)"; break
            }
        } catch { }
    }
    if (-not $pythonCmd) { Die "Python instalado mas nao encontrado no PATH. Reinicie o terminal e execute novamente." }
}

# ── Copia arquivos ───────────────────────────────────────────
Hdr "2/5  Instalando em $InstallDir"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

if (Test-Path $InstallDir) {
    Warn "Diretorio ja existe - atualizando arquivos do agente..."
} else {
    New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null
}

Copy-Item -Recurse -Force "$scriptDir\agent" "$InstallDir\"
Copy-Item -Force "$scriptDir\requirements.txt" "$InstallDir\"
if (Test-Path "$scriptDir\pyproject.toml")        { Copy-Item -Force "$scriptDir\pyproject.toml"        "$InstallDir\" }
if (Test-Path "$scriptDir\_uninstall.ps1")        { Copy-Item -Force "$scriptDir\_uninstall.ps1"        "$InstallDir\" }
if (Test-Path "$scriptDir\Install-agent.bat")     { Copy-Item -Force "$scriptDir\Install-agent.bat"     "$InstallDir\" }
if (Test-Path "$scriptDir\Uninstall-agent.bat")   { Copy-Item -Force "$scriptDir\Uninstall-agent.bat"   "$InstallDir\" }
if (Test-Path "$scriptDir\Restart-agent.bat")     { Copy-Item -Force "$scriptDir\Restart-agent.bat"     "$InstallDir\" }
if (Test-Path "$scriptDir\Update-agent.bat")      { Copy-Item -Force "$scriptDir\Update-agent.bat"      "$InstallDir\" }
Remove-Item -Force "$InstallDir\update.bat" -ErrorAction SilentlyContinue
Remove-Item -Force "$InstallDir\install-windows.ps1" -ErrorAction SilentlyContinue
Remove-Item -Force "$InstallDir\uninstall-windows.ps1" -ErrorAction SilentlyContinue
Remove-Item -Force "$InstallDir\instalar-agente.bat" -ErrorAction SilentlyContinue
Remove-Item -Force "$InstallDir\desinstalar-agente.bat" -ErrorAction SilentlyContinue
Remove-Item -Force "$InstallDir\reiniciar-agente.bat" -ErrorAction SilentlyContinue
Remove-Item -Force "$InstallDir\instalar-windows.bat" -ErrorAction SilentlyContinue
Remove-Item -Force "$InstallDir\desinstalar-windows.bat" -ErrorAction SilentlyContinue
Ok "Arquivos copiados para $InstallDir"

Info "Criando ambiente virtual Python..."
& $pythonCmd -m venv "$InstallDir\venv"
Ok "Virtualenv criado"

Info "Instalando dependencias (pode demorar alguns segundos)..."
& "$InstallDir\venv\Scripts\pip.exe" install --quiet --upgrade pip
& "$InstallDir\venv\Scripts\pip.exe" install --quiet -r "$InstallDir\requirements.txt"
Ok "Dependencias instaladas"

$configDest = "$InstallDir\config.toml"
if (-not (Test-Path $configDest)) {
    Copy-Item -Force "$scriptDir\config.template.toml" $configDest
    Ok "config.toml criado a partir do template"
} else {
    Ok "config.toml ja existe - mantido sem alteracoes"
}

# ── Agent Key ─────────────────────────────────────────────────
Hdr "3/5  Configurando Agent Key"
if ([string]::IsNullOrWhiteSpace($AgentKey)) {
    Write-Host ""
    Write-Host "  Voce precisa de uma Agent Key do dashboard go2mine." -ForegroundColor Yellow
    Write-Host "  Acesse: $DASHBOARD_URL -> Configuracoes -> Chaves do Agente" -ForegroundColor Cyan
    Write-Host ""
    $AgentKey = Read-Host "  Cole sua Agent Key aqui (ou ENTER para pular)"
}

if (-not [string]::IsNullOrWhiteSpace($AgentKey)) {
    $config = Get-Content $configDest -Raw
    $config = $config -replace 'agent_key\s*=\s*"[^"]*"', "agent_key = `"$AgentKey`""
    [System.IO.File]::WriteAllText($configDest, $config, [System.Text.UTF8Encoding]::new($false))
    Ok "Agent Key configurada"
} else {
    Warn "Agent Key nao configurada. Edite $configDest antes de iniciar o agente."
}

# ── Script de execucao ────────────────────────────────────────
Hdr "4/5  Criando script de inicializacao"

$runScript  = "$InstallDir\_run-agent.ps1"
$pythonExe  = "$InstallDir\venv\Scripts\python.exe"

$psWrapper = "Set-Location `"$InstallDir`"`r`n"
$psWrapper += "& `"$pythonExe`" -m agent`r`n"

Set-Content -Path $runScript -Value $psWrapper -Encoding UTF8
Ok "Script interno de execucao criado"

# ── Task Scheduler ────────────────────────────────────────────
Hdr "5/5  Registrando no Task Scheduler (inicio automatico)"

$existingTask = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
if ($existingTask) {
    Unregister-ScheduledTask -TaskName $TASK_NAME -Confirm:$false
    Info "Tarefa anterior removida"
}

$action = New-ScheduledTaskAction `
    -Execute "$pythonExe" `
    -Argument "-m agent" `
    -WorkingDirectory $InstallDir

$trigger = New-ScheduledTaskTrigger -AtStartup

$settings = New-ScheduledTaskSettingsSet `
    -ExecutionTimeLimit (New-TimeSpan -Hours 0) `
    -RestartCount 5 `
    -RestartInterval (New-TimeSpan -Minutes 1) `
    -StartWhenAvailable

$principal = New-ScheduledTaskPrincipal `
    -UserId "SYSTEM" `
    -LogonType ServiceAccount `
    -RunLevel Highest

Register-ScheduledTask `
    -TaskName $TASK_NAME `
    -Action $action `
    -Trigger $trigger `
    -Settings $settings `
    -Principal $principal `
    -Description "go2mine hashfarm-agent - ASIC Mining Monitor ($DASHBOARD_URL)" | Out-Null

Ok "Tarefa registrada: '$TASK_NAME' (inicia com o Windows)"

if (-not [string]::IsNullOrWhiteSpace($AgentKey)) {
    Info "Iniciando o agente..."
    Start-ScheduledTask -TaskName $TASK_NAME
} else {
    Warn "Agent Key nao informada. Configure $InstallDir\config.toml e execute .\Restart-agent.bat"
    Info "Iniciando o agente assim mesmo (necessario configurar agent_key antes de funcionar)..."
    Start-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
}

Hdr "Verificando status do agente..."
Start-Sleep -Seconds 5
$state = (Get-ScheduledTask -TaskName $TASK_NAME).State
if ($state -eq "Running") {
    Ok "Agente em execucao! (estado: $state)"
} else {
    Warn "Agente nao iniciou (estado: $state). Tentando reiniciar..."
    Stop-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    Start-ScheduledTask -TaskName $TASK_NAME
    Start-Sleep -Seconds 6
    $state2 = (Get-ScheduledTask -TaskName $TASK_NAME).State
    if ($state2 -eq "Running") {
        Ok "Agente iniciado apos reinicio! (estado: $state2)"
    } else {
        Warn "Agente ainda nao esta em execucao (estado: $state2)."
        Warn "Verifique o log em: $InstallDir\agent.log"
        Warn "Ou execute manualmente: powershell -ExecutionPolicy Bypass -File `"$InstallDir\_run-agent.ps1`""
    }
}

Hdr "Verificando conectividade com $DASHBOARD_URL ..."
try {
    $resp = Invoke-WebRequest -Uri "$DASHBOARD_URL/health" -UseBasicParsing -TimeoutSec 10 -ErrorAction Stop
    if ($resp.StatusCode -eq 200) { Ok "Servidor go2mine acessivel." }
    else { Warn "Servidor respondeu com codigo $($resp.StatusCode)." }
} catch {
    Warn "Nao foi possivel acessar $DASHBOARD_URL. Verifique sua conexao com a internet."
}

# ── Resumo ───────────────────────────────────────────────────
$agentVer = ""
$initFile = "$InstallDir\agent\__init__.py"
if (Test-Path $initFile) {
    $match = Select-String -Path $initFile -Pattern '__version__\s*=\s*"([\d.]+)"'
    if ($match) { $agentVer = $match.Matches[0].Groups[1].Value }
}

Write-Host ""
Write-Host "  ============================================" -ForegroundColor Green
Write-Host "    Instalacao concluida!  (v$agentVer)" -ForegroundColor White
Write-Host "  ============================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Diretorio:   $InstallDir" -ForegroundColor White
Write-Host "  Config:      $InstallDir\config.toml" -ForegroundColor White
Write-Host "  Parar:       Stop-ScheduledTask -TaskName '$TASK_NAME'" -ForegroundColor White
Write-Host "  Iniciar:     Start-ScheduledTask -TaskName '$TASK_NAME'" -ForegroundColor White
Write-Host "  Dashboard:   $DASHBOARD_URL" -ForegroundColor Cyan
Write-Host ""
Write-Host "  Proximos passos:" -ForegroundColor Yellow
Write-Host "  1. Acesse $DASHBOARD_URL e faca login"
Write-Host "  2. Seus ASICs aparecerao automaticamente no dashboard"
Write-Host ""
Write-Host "  Log de instalacao: $LOG_PATH" -ForegroundColor DarkGray

Stop-Transcript | Out-Null
