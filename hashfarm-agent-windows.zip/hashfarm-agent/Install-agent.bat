@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process cmd -ArgumentList '/c \"%~s0\"' -Verb RunAs"
    exit /b
)
for /f "tokens=2 delims==" %%A in ('findstr /C:"__version__" "%~dp0agent\__init__.py"') do set "AGENT_VER=%%~A"
set "AGENT_VER=%AGENT_VER: =%"
set "AGENT_VER=%AGENT_VER:"=%"
echo Instalando agente go2mine v%AGENT_VER%...
echo.
powershell -ExecutionPolicy Bypass -File "%~dp0_install.ps1"
if %errorlevel% neq 0 (
    echo.
    echo [ERRO] A instalacao falhou. Leia a mensagem acima.
)
pause
