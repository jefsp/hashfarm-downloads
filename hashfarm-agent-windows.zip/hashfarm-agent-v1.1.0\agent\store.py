"""
hashfarm-agent · store.py · v1.0
Fila offline-first com SQLite.

Dados coletados são gravados localmente antes de enviar para a nuvem.
Se a conexão WebSocket cair, o agente continua coletando e sincroniza
tudo quando reconectar. Leve: SQLite não requer processo separado.
"""

import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Optional

log = logging.getLogger("hashfarm.store")


class LocalStore:
    """
    SQLite store thread-safe via WAL mode.
    Operações síncronas — o collector roda num executor.
    """

    def __init__(self, path: str = "hashfarm.db", max_queue: int = 10_000):
        self.path = Path(path)
        self.max_queue = max_queue
        self._conn = self._connect()
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            self.path,
            check_same_thread=False,  # usamos lock externo / WAL
            timeout=10,
        )
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS snapshots (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                ip      TEXT    NOT NULL,
                ts      INTEGER NOT NULL,
                payload TEXT    NOT NULL,  -- JSON dos KPIs
                sent    INTEGER NOT NULL DEFAULT 0,
                sent_at INTEGER
            );

            CREATE INDEX IF NOT EXISTS idx_snapshots_unsent
                ON snapshots (sent, ts);

            CREATE INDEX IF NOT EXISTS idx_snapshots_ip_ts
                ON snapshots (ip, ts DESC);

            -- Comandos recebidos da nuvem que ainda precisam ser executados
            CREATE TABLE IF NOT EXISTS commands (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                cmd_id      TEXT    NOT NULL UNIQUE,  -- ID vindo da nuvem
                ip          TEXT    NOT NULL,
                command     TEXT    NOT NULL,          -- start|stop|restart|reboot
                params      TEXT,                      -- JSON adicional
                received_at INTEGER NOT NULL,
                executed_at INTEGER,
                result      TEXT,                      -- ok | error: mensagem
                status      TEXT    NOT NULL DEFAULT 'pending'
            );
        """)
        self._conn.commit()

    # ─── Snapshots ─────────────────────────────────────────────────────────

    def save_snapshot(self, kpis: dict) -> int:
        """Grava um snapshot de KPIs. Retorna o ID."""
        # Se fila estiver cheia, descarta os mais antigos ainda não enviados
        count = self._conn.execute(
            "SELECT COUNT(*) FROM snapshots WHERE sent=0"
        ).fetchone()[0]

        if count >= self.max_queue:
            drop = count - self.max_queue + 1
            self._conn.execute(
                "DELETE FROM snapshots WHERE sent=0 AND id IN "
                "(SELECT id FROM snapshots WHERE sent=0 ORDER BY ts ASC LIMIT ?)",
                (drop,),
            )
            log.warning(f"Fila cheia — descartados {drop} snapshots antigos")

        cur = self._conn.execute(
            "INSERT INTO snapshots (ip, ts, payload) VALUES (?, ?, ?)",
            (kpis["ip"], kpis["ts"], json.dumps(kpis)),
        )
        self._conn.commit()
        return cur.lastrowid

    def get_unsent(self, limit: int = 100) -> list[dict]:
        """Retorna até `limit` snapshots não enviados, do mais antigo ao mais novo."""
        rows = self._conn.execute(
            "SELECT id, ip, ts, payload FROM snapshots "
            "WHERE sent=0 ORDER BY ts ASC LIMIT ?",
            (limit,),
        ).fetchall()
        return [
            {"_id": r["id"], "ip": r["ip"], "ts": r["ts"], **json.loads(r["payload"])}
            for r in rows
        ]

    def mark_sent(self, ids: list[int]):
        """Marca snapshots como enviados."""
        if not ids:
            return
        placeholders = ",".join("?" * len(ids))
        self._conn.execute(
            f"UPDATE snapshots SET sent=1, sent_at=? WHERE id IN ({placeholders})",
            [int(time.time()), *ids],
        )
        self._conn.commit()

    def unsent_count(self) -> int:
        return self._conn.execute(
            "SELECT COUNT(*) FROM snapshots WHERE sent=0"
        ).fetchone()[0]

    def latest_snapshot(self, ip: str) -> Optional[dict]:
        """Retorna o snapshot mais recente de um IP (para leitura local)."""
        row = self._conn.execute(
            "SELECT payload FROM snapshots WHERE ip=? ORDER BY ts DESC LIMIT 1",
            (ip,),
        ).fetchone()
        return json.loads(row["payload"]) if row else None

    # ─── Comandos ──────────────────────────────────────────────────────────

    def save_command(self, cmd_id: str, ip: str, command: str, params: Optional[dict] = None):
        try:
            self._conn.execute(
                "INSERT OR IGNORE INTO commands "
                "(cmd_id, ip, command, params, received_at) VALUES (?, ?, ?, ?, ?)",
                (cmd_id, ip, command, json.dumps(params) if params else None, int(time.time())),
            )
            self._conn.commit()
        except Exception as e:
            log.error(f"Erro ao salvar comando {cmd_id}: {e}")

    def complete_command(self, cmd_id: str, result: str):
        status = "ok" if result == "ok" else "error"
        self._conn.execute(
            "UPDATE commands SET executed_at=?, result=?, status=? WHERE cmd_id=?",
            (int(time.time()), result, status, cmd_id),
        )
        self._conn.commit()

    def get_pending_commands(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT cmd_id, ip, command, params FROM commands WHERE status='pending'"
        ).fetchall()
        return [
            {
                "cmd_id": r["cmd_id"],
                "ip": r["ip"],
                "command": r["command"],
                "params": json.loads(r["params"]) if r["params"] else {},
            }
            for r in rows
        ]

    # ─── Cleanup ───────────────────────────────────────────────────────────

    def cleanup_old(self, days: int = 7):
        """Remove snapshots enviados com mais de `days` dias."""
        cutoff = int(time.time()) - days * 86_400
        deleted = self._conn.execute(
            "DELETE FROM snapshots WHERE sent=1 AND sent_at < ?",
            (cutoff,),
        ).rowcount
        self._conn.commit()
        if deleted:
            log.info(f"Cleanup: {deleted} snapshots antigos removidos")

    def close(self):
        self._conn.close()
