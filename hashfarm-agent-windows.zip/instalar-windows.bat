@echo off
:: ============================================================
::  go2mine — hashfarm-agent  |  Instalador Windows
::  Clique duas vezes para instalar. Nenhum comando necessario.
:: ============================================================

:: ── Elevacao automatica (UAC) ────────────────────────────────
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Solicitando permissao de Administrador...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: ── Executa o instalador PowerShell ─────────────────────────
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install-windows.ps1"

pause
