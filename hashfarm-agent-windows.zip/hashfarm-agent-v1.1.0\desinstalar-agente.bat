@echo off
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)
echo Desinstalando agente go2mine...
powershell -ExecutionPolicy Bypass -File "%~dp0uninstall-windows.ps1"
