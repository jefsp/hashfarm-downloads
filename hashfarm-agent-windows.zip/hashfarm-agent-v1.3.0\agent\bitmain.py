"""
hashfarm-agent · bitmain.py
Suporte ao firmware stock do Bitmain Antminer via CGMiner API (TCP 4028).
Reutiliza WhatsminerClient — mesmo protocolo TCP.
"""
import logging
import time
from typing import Optional

from .whatsminer import WhatsminerClient, WhatsminerConfig

log = logging.getLogger("hashfarm.bitmain")

_ANTMINER_STOCK: dict[str, float] = {
    "S9i": 14.0, "S9j": 14.5, "S9": 13.5,
    "S17+": 73.0, "S17 Pro": 53.0, "S17e": 64.0, "S17": 56.0,
    "S19 XP": 140.0, "S19k Pro": 120.0, "S19j Pro": 100.0,
    "S19j": 90.0, "S19 Pro": 110.0, "S19": 95.0,
    "S21 Pro": 234.0, "S21": 200.0,
    "T19": 84.0, "T21": 162.0,
}


def _lookup_antminer_stock(model: Optional[str]) -> Optional[float]:
    if not model:
        return None
    m = model.upper()
    for key in sorted(_ANTMINER_STOCK, key=len, reverse=True):
        if key.upper() in m:
            return _ANTMINER_STOCK[key]
    return None


class BitmainStockPoller:
    def __init__(self, client: WhatsminerClient):
        self.client = client

    async def poll(self, cfg: WhatsminerConfig) -> dict:
        summary = await self.client.send(cfg, "summary")
        pools   = await self.client.send(cfg, "pools")
        devs    = await self.client.send(cfg, "devs")
        version = await self.client.send(cfg, "version")
        stats   = await self.client.send(cfg, "stats")
        return {
            "ip": cfg.ip, "ts": int(time.time()),
            "summary": summary, "pools": pools,
            "devs": devs, "version": version, "stats": stats,
        }

    def extract_kpis(self, raw: dict) -> dict:
        ip = raw["ip"]
        ts = raw["ts"]
        _offline = {
            "ip": ip, "ts": ts, "status": "offline",
            "hr_realtime_ths": None, "hr_stock_ths": None, "hr_average_ths": None,
            "chip_temp_max": None, "chip_temp_min": None, "pcb_temp_max": None,
            "fan_duty": None, "fans": [], "power_w": None,
            "efficiency_w_th": None, "hw_errors_pct": None,
            "pools": [], "chains": [], "model": None,
            "fw_version": None, "uptime": None,
            "alarms": ["offline"], "firmware": "bitmain_stock",
        }

        summary = raw.get("summary")
        if not summary:
            return _offline
        s_list = summary.get("SUMMARY", [])
        if not s_list:
            return _offline
        s = s_list[0]

        def _to_ths(val, unit="GH"):
            if val is None:
                return None
            return round(val / 1_000_000, 4) if unit == "MH" else round(val / 1000, 4)

        hr_rt  = _to_ths(s.get("GHS 5s")) or _to_ths(s.get("MHS 5s"), "MH")
        hr_avg = _to_ths(s.get("GHS av")) or _to_ths(s.get("MHS av"), "MH")
        elapsed = s.get("Elapsed", 0)
        status = "mining" if (hr_rt and hr_rt > 0) else ("init" if elapsed < 120 else "idle")

        ver_data = raw.get("version") or {}
        ver_list = ver_data.get("VERSION", [])
        ver = ver_list[0] if ver_list else {}
        model = ver.get("Type") or ver.get("Model")
        fw_version_str = ver.get("Miner") or ver.get("CompileTime")

        stock_ths = _lookup_antminer_stock(model)

        stats_data = raw.get("stats") or {}
        stats_list = stats_data.get("STATS", [])
        temps = []
        fans_map: dict[int, int] = {}
        for st in stats_list:
            for k, v in st.items():
                if not isinstance(v, (int, float)) or v <= 0:
                    continue
                kl = k.lower()
                if kl.startswith("temp") and v < 200:
                    temps.append(float(v))
                elif kl.startswith("fan"):
                    digits = "".join(c for c in k if c.isdigit())
                    fid = int(digits) if digits else (len(fans_map) + 1)
                    fans_map[fid] = int(v)

        temp_max = max(temps) if temps else None
        temp_min = min(temps) if temps else None
        fans = [{"id": fid, "rpm": rpm, "status": "ok"} for fid, rpm in sorted(fans_map.items())][:4]
        max_rpm = max((f["rpm"] for f in fans), default=0)
        fan_duty = round(max_rpm / 6000 * 100) if max_rpm else None

        hw_err = s.get("Hardware Errors")
        accepted = s.get("Accepted", 1)
        hw_errors_pct = round(hw_err / max(accepted, 1) * 100, 2) if hw_err is not None else None

        pools_raw = (raw.get("pools") or {}).get("POOLS", [])
        pools_norm = [{
            "url": p.get("URL", ""), "user": p.get("User", ""),
            "status": "active" if p.get("Stratum Active") else "backup",
            "accepted": p.get("Accepted", 0), "rejected": p.get("Rejected", 0),
            "pool_type": "UserPool",
        } for p in pools_raw]

        devs_list = (raw.get("devs") or {}).get("DEVS", [])
        chains = []
        for d in devs_list:
            hr_c = _to_ths(d.get("GHS 5s")) or _to_ths(d.get("MHS 5s"), "MH")
            chains.append({
                "index": d.get("ASC", len(chains)),
                "hr_ths": hr_c, "chip_temp": None, "pcb_temp": None,
                "hw_errors": d.get("Hardware Errors", 0), "hw_err_pct": 0,
                "status": "ok" if hr_c and hr_c > 0 else "dead",
            })

        log.info(
            f"[{ip}] Bitmain: model={model} hr_rt={hr_rt} hr_avg={hr_avg} "
            f"stock={stock_ths} temp={temp_max} fans={[f['rpm'] for f in fans]} elapsed={elapsed}s chains={len(chains)}"
        )

        return {
            "ip": ip, "ts": ts, "status": status,
            "hr_realtime_ths": hr_rt, "hr_stock_ths": stock_ths, "hr_average_ths": hr_avg,
            "chip_temp_max": temp_max, "chip_temp_min": temp_min, "pcb_temp_max": None,
            "fan_duty": fan_duty, "fans": fans, "power_w": None,
            "efficiency_w_th": None, "hw_errors_pct": hw_errors_pct,
            "pools": pools_norm, "chains": chains,
            "model": model, "fw_version": fw_version_str, "uptime": elapsed,
            "alarms": [], "firmware": "bitmain_stock",
        }
