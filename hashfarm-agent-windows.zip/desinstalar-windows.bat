@echo off
:: ============================================================
::  go2mine — hashfarm-agent  |  Desinstalador Windows
::  Clique duas vezes para desinstalar.
:: ============================================================

:: ── Elevacao automatica (UAC) ────────────────────────────────
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Solicitando permissao de Administrador...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

:: ── Executa o desinstalador PowerShell ──────────────────────
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall-windows.ps1"

pause
