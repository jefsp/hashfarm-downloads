"""
hashfarm-agent · main.py · v1.1
Entry point. Orquestra collector standalone (sem cloud) e
CloudConnector (on-demand quando há sessão ativa).

Modo de operação:
  - Se cloud.agent_key estiver configurado → usa CloudConnector (on-demand)
  - Se não → modo standalone, coleta local e grava no SQLite
"""

import asyncio
import logging
import signal
import sys

from .config import load_config
from .store import LocalStore


def setup_logging(level: str):
    fmt = "%(asctime)s [%(levelname)s] %(name)s — %(message)s"
    logging.basicConfig(
        level=getattr(logging, level, logging.INFO),
        format=fmt,
        handlers=[logging.StreamHandler(sys.stdout)],
    )
    logging.getLogger("aiohttp").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    logging.getLogger("websockets").setLevel(logging.WARNING)


async def main():
    cfg = load_config()
    setup_logging(cfg.log_level)

    log = logging.getLogger("hashfarm.main")
    log.info("HashFarm Agent v1.1 iniciando…")

    if not cfg.miners:
        log.warning("Nenhum minerador configurado. Edite config.toml e reinicie.")

    store = LocalStore(path=cfg.store.path, max_queue=cfg.store.max_queue)

    loop = asyncio.get_event_loop()
    stop_event = asyncio.Event()

    def _shutdown():
        log.info("Encerrando…")
        stop_event.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _shutdown)
        except (NotImplementedError, RuntimeError):
            # Windows não suporta add_signal_handler — usa signal.signal como fallback
            signal.signal(sig, lambda *_: stop_event.set())

    tasks = []

    if cfg.cloud.agent_key:
        log.info(f"Modo cloud → {cfg.cloud.url}")
        from .cloud import CloudConnector
        connector = CloudConnector(cfg, store)
        tasks.append(asyncio.create_task(connector.run_forever(), name="cloud"))

    else:
        log.info("Modo standalone (sem cloud.agent_key configurado)")
        from .collector import Collector

        async def _run_standalone():
            async with Collector(cfg, store) as col:
                col.on_snapshot = lambda kpis: log.debug(
                    f"  {kpis.get('label', kpis['ip'])} [{kpis.get('status')}] "
                    f"hr={kpis.get('hr_realtime_ths')} TH/s"
                )
                await col.run_forever()

        tasks.append(asyncio.create_task(_run_standalone(), name="standalone"))

    await stop_event.wait()

    for t in tasks:
        t.cancel()
    await asyncio.gather(*tasks, return_exceptions=True)

    store.close()
    log.info("Agente encerrado.")


def run():
    asyncio.run(main())


if __name__ == "__main__":
    run()
