"""
hashfarm-agent · whatsminer.py · v1.0
Cliente assíncrono para a API Whatsminer (MicroBT).

Suporta dois protocolos:
  - TCP port 4028: todos os modelos (M20, M30, M50, M60...)
  - HTTP port 80:  modelos mais novos com webserver ativo

Autenticação:
  - M20/M30 mais antigos: sem autenticação no TCP
  - M30S+/M50+: token via comando "get_token" no TCP, depois assina com MD5
  - Não implementamos AES (M50+ firmware recente) nesta versão

O método extract_kpis() retorna o mesmo schema do VnishClient.extract_kpis()
para que o restante do agente não precise saber qual firmware está rodando.
"""

import asyncio
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

log = logging.getLogger("hashfarm.whatsminer")

# ── Tabela de hashrate nominal por modelo (TH/s) ────────────────────────────
# Fonte: especificações oficiais MicroBT
# Chave: substring do campo "Type" retornado pela API
_STOCK_THS: dict[str, float] = {
    # M20 series
    "M20S":  68.0,
    "M20":   48.0,
    # M30 series
    "M30S++": 112.0,
    "M30S+":  100.0,
    "M30S":    88.0,
    "M30":     34.0,
    # M31 series
    "M31S+":  82.0,
    "M31S":   74.0,
    # M32":
    "M32":    62.0,
    # M33 series
    "M33S++": 198.0,
    "M33S+":  186.0,
    # M50 series
    "M50S++": 146.0,
    "M50S+":  136.0,
    "M50S":   126.0,
    "M50":    126.0,
    # M53 series
    "M53S++": 320.0,
    "M53S+":  306.0,
    "M53S":   290.0,
    "M53":    226.0,
    # M56 series
    "M56S++": 216.0,
    "M56S":   212.0,
    "M56":    212.0,
    # M60 series
    "M60S++": 186.0,
    "M60S+":  170.0,
    "M60S":   162.0,
    "M60":    162.0,
    # M63 series
    "M63S++": 390.0,
    "M63S+":  366.0,
    "M63S":   346.0,
    # M66 series
    "M66S++": 298.0,
    "M66S+":  298.0,
    "M66S":   280.0,
}

def _lookup_stock_ths(model: Optional[str]) -> Optional[float]:
    """Retorna TH/s nominal pelo modelo. Busca pela chave mais longa que dê match."""
    if not model:
        return None
    model_upper = model.upper()
    # Ordena por comprimento decrescente para dar match no modelo mais específico
    for key in sorted(_STOCK_THS, key=len, reverse=True):
        if key.upper() in model_upper:
            return _STOCK_THS[key]
    return None

TCP_PORT     = 4028
TCP_TIMEOUT  = 10
TOKEN_TTL    = 30 * 60  # 30 min


@dataclass
class WhatsminerConfig:
    ip: str
    port: int = TCP_PORT
    password: str = "admin"


@dataclass
class _TokenEntry:
    token: str
    expires_at: float


class WhatsminerClient:
    """
    Cliente TCP assíncrono para a API Whatsminer.
    Uma instância por sessão (compartilhada entre mineradores).
    """

    def __init__(self):
        self._tokens: dict[str, _TokenEntry] = {}
        self._locks:  dict[str, asyncio.Lock] = {}

    def _lock(self, ip: str) -> asyncio.Lock:
        if ip not in self._locks:
            self._locks[ip] = asyncio.Lock()
        return self._locks[ip]

    def _token_valid(self, ip: str) -> bool:
        e = self._tokens.get(ip)
        return bool(e and e.expires_at > time.time() + 60)

    # ── TCP helpers ──────────────────────────────────────────────────────────

    async def _tcp_send(self, ip: str, port: int, payload: dict) -> Optional[dict]:
        """Abre conexão TCP, envia JSON, lê resposta e fecha."""
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(ip, port), timeout=TCP_TIMEOUT
            )
            data = json.dumps(payload).encode()
            writer.write(data)
            await writer.drain()

            buf = b""
            while True:
                chunk = await asyncio.wait_for(reader.read(4096), timeout=TCP_TIMEOUT)
                if not chunk:
                    break
                buf += chunk
                # Whatsminer termina a resposta com \x00
                if b"\x00" in buf:
                    buf = buf.rstrip(b"\x00")
                    break

            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass

            return json.loads(buf.decode(errors="replace"))

        except asyncio.TimeoutError:
            log.debug(f"[{ip}] TCP timeout")
            return None
        except ConnectionRefusedError:
            log.debug(f"[{ip}] TCP conexão recusada")
            return None
        except Exception as e:
            log.debug(f"[{ip}] TCP erro: {e}")
            return None

    # ── Autenticação ─────────────────────────────────────────────────────────

    async def _get_token(self, cfg: WhatsminerConfig) -> Optional[str]:
        """
        Obtém token de sessão via comando get_token.
        Modelos mais antigos retornam token vazio — isso é normal.
        """
        async with self._lock(cfg.ip):
            if self._token_valid(cfg.ip):
                return self._tokens[cfg.ip].token

            resp = await self._tcp_send(cfg.ip, cfg.port, {"cmd": "get_token"})
            if not resp:
                return None

            msg = resp.get("Msg", {})
            if isinstance(msg, str):
                # Firmware antigo: sem autenticação necessária
                token = ""
            else:
                token = msg.get("token", "")

            self._tokens[cfg.ip] = _TokenEntry(token, time.time() + TOKEN_TTL)
            log.debug(f"[{cfg.ip}] Token obtido: {'(vazio)' if not token else token[:8]+'...'}")
            return token

    def _sign(self, token: str, password: str) -> str:
        """Assina o comando com MD5(token + password)."""
        return hashlib.md5(f"{token}{password}".encode()).hexdigest()

    # ── Comandos públicos ────────────────────────────────────────────────────

    async def send(self, cfg: WhatsminerConfig, cmd: str, extra: Optional[dict] = None) -> Optional[dict]:
        """
        Envia comando ao Whatsminer.
        Readable commands (summary, pools, devs, get_version) não precisam de token.
        Writable commands precisam de token assinado.
        Tenta sem token primeiro; só autentica se receber code 45 (permission denied).
        """
        payload: dict = {"cmd": cmd}
        if extra:
            payload.update(extra)

        # Primeira tentativa: sem token (funciona para todos os readable commands)
        resp = await self._tcp_send(cfg.ip, cfg.port, payload)
        if resp:
            codes = [c.get("Code") for c in resp.get("STATUS", []) if isinstance(c, dict)]
            if 45 not in codes:
                return resp

        # Code 45 = permission denied → tentar com token
        token = await self._get_token(cfg)
        if not token:
            return resp

        payload["token"] = self._sign(token, cfg.password)
        resp = await self._tcp_send(cfg.ip, cfg.port, payload)

        # Token expirado → invalida e tenta de novo uma vez
        if resp:
            codes = [c.get("Code") for c in resp.get("STATUS", []) if isinstance(c, dict)]
            if set(codes) & {14, 23}:
                self._tokens.pop(cfg.ip, None)
                token = await self._get_token(cfg)
                if token:
                    payload["token"] = self._sign(token, cfg.password)
                    resp = await self._tcp_send(cfg.ip, cfg.port, payload)

        return resp


class WhatsminerPoller:
    """
    Coleta dados de um Whatsminer via TCP e normaliza para o schema padrão.
    """

    def __init__(self, client: WhatsminerClient):
        self.client = client

    async def poll(self, cfg: WhatsminerConfig) -> dict:
        """Coleta summary, pools, edevs e get_version sequencialmente.
        Sequencial evita problemas com Whatsminer que rejeitam múltiplas
        conexões TCP simultâneas (firmware mais antigo).
        """
        summary = await self.client.send(cfg, "summary")
        pools   = await self.client.send(cfg, "pools")
        devs    = await self.client.send(cfg, "edevs")
        version = await self.client.send(cfg, "get_version")

        return {
            "ip":      cfg.ip,
            "ts":      int(time.time()),
            "summary": summary,
            "pools":   pools,
            "devs":    devs,
            "version": version,
        }

    def extract_kpis(self, raw: dict) -> dict:
        """
        Converte resposta Whatsminer para o schema padrão do HashFarm.
        Mesmo contrato do VnishClient.extract_kpis().
        """
        ip  = raw["ip"]
        ts  = raw["ts"]
        _offline = {
            "ip": ip, "ts": ts, "status": "offline",
            "hr_realtime_ths": None, "hr_stock_ths": None, "hr_average_ths": None,
            "chip_temp_max": None, "chip_temp_min": None, "pcb_temp_max": None,
            "fan_duty": None, "fans": [], "power_w": None,
            "efficiency_w_th": None, "hw_errors_pct": None,
            "pools": [], "chains": [], "model": None,
            "fw_version": None, "uptime": None,
            "alarms": ["offline"], "firmware": "whatsminer",
        }

        summary = raw.get("summary")
        if not summary:
            return _offline

        # A resposta TCP tem formato: {"STATUS":[...], "SUMMARY":[{...}], "id":1}
        s_list = summary.get("SUMMARY", [])
        if not s_list:
            return _offline
        s = s_list[0]

        # ── Hashrate ────────────────────────────────────────────────────────
        # GHS 5s = GH/s → dividir por 1000 para TH/s
        # MHS 5s = MH/s → dividir por 1.000.000 para TH/s
        def _to_ths(val: Optional[float], unit: str = "GH") -> Optional[float]:
            if val is None:
                return None
            if unit == "MH":
                return round(val / 1_000_000, 4)
            return round(val / 1000, 4)  # GH

        def _parse_hr(key_ghs: str, key_mhs: str) -> Optional[float]:
            v = s.get(key_ghs)
            if v is not None:
                return _to_ths(v, "GH")
            v = s.get(key_mhs)
            if v is not None:
                return _to_ths(v, "MH")
            return None

        hr_rt  = _parse_hr("GHS 5s", "MHS 5s")
        hr_avg = _parse_hr("GHS av", "MHS av")

        # ── Temperatura ─────────────────────────────────────────────────────
        # Diferentes firmwares usam campos diferentes
        temp_max = (
            s.get("Temperature Max") or
            s.get("Chip Temp Max") or
            s.get("Temperature") or
            s.get("Temp") or
            None
        )
        if temp_max is not None:
            try:
                temp_max = float(temp_max)
            except (ValueError, TypeError):
                temp_max = None

        # ── Fan ─────────────────────────────────────────────────────────────
        fan1 = s.get("Fan Speed In",  s.get("Fan1 Speed", 0)) or 0
        fan2 = s.get("Fan Speed Out", s.get("Fan2 Speed", 0)) or 0
        fans = []
        if fan1: fans.append({"id": 1, "rpm": int(fan1), "status": "ok"})
        if fan2: fans.append({"id": 2, "rpm": int(fan2), "status": "ok"})
        max_rpm = max((f["rpm"] for f in fans), default=0)
        # RPM máximo típico por série: M20/M30=6000, M50/M60=6600
        ref_rpm = 6600 if max_rpm > 6000 else 6000
        fan_duty = round(max_rpm / ref_rpm * 100) if max_rpm else None

        # ── Status ──────────────────────────────────────────────────────────
        elapsed = s.get("Elapsed", 0)
        status = "mining" if (hr_rt and hr_rt > 0) else ("init" if elapsed < 120 else "idle")

        # ── HW Errors ───────────────────────────────────────────────────────
        hw_err  = s.get("Hardware Errors")
        accepted = s.get("Accepted", 1)
        hw_errors_pct = round(hw_err / max(accepted, 1) * 100, 2) if hw_err is not None else None

        # ── Pools ────────────────────────────────────────────────────────────
        pools_data = raw.get("pools", {})
        pools_list = pools_data.get("POOLS", []) if pools_data else []
        pools_norm = []
        for p in pools_list:
            pools_norm.append({
                "url":        p.get("URL", ""),
                "user":       p.get("User", ""),
                "status":     "active" if p.get("Stratum Active") else "backup",
                "accepted":   p.get("Accepted", 0),
                "rejected":   p.get("Rejected", 0),
                "pool_type":  "UserPool",
            })

        # ── Power ────────────────────────────────────────────────────────────
        power_w = s.get("Power") or s.get("Power Use") or None

        # ── Model via get_version (campo miner_type) ─────────────────────────
        version_data = raw.get("version") or {}
        ver_list = version_data.get("VERSION", [])
        ver = ver_list[0] if ver_list else {}
        model = ver.get("miner_type") or s.get("Type") or s.get("model")
        fw_version_str = ver.get("fw_ver") or s.get("CompileTime") or s.get("fw_version")

        # ── Stock TH/s: tabela por modelo; fallback Factory GHS do summary ───
        stock_ths = _lookup_stock_ths(model)
        if stock_ths is None:
            factory_ghs = s.get("Factory GHS")
            if factory_ghs:
                stock_ths = round(float(factory_ghs) / 1000, 2)

        # ── Chains via devs ──────────────────────────────────────────────────
        devs_data = raw.get("devs", {})
        devs_list = devs_data.get("DEVS", []) if devs_data else []

        log.info(
            f"[{ip}] Whatsminer: model={model} hr_rt={hr_rt} hr_avg={hr_avg} "
            f"stock={stock_ths} temp={temp_max} fans={[f['rpm'] for f in fans]} "
            f"power={s.get('Power')} elapsed={elapsed}s chains={len(devs_list)}"
        )
        chains = []
        for d in devs_list:
            hr_chain_ghs = d.get("GHS 5s")
            hr_chain_mhs = d.get("MHS 5s")
            hr_chain = _to_ths(hr_chain_ghs, "GH") if hr_chain_ghs is not None else _to_ths(hr_chain_mhs, "MH")
            t_chip   = d.get("Chip Temp Max") or d.get("Temperature") or d.get("Temp") or None
            hw_c     = d.get("Hardware Errors", 0)
            acc_c    = d.get("Accepted", 1)
            chains.append({
                "index":      d.get("ASC", d.get("PGA", len(chains))),
                "hr_ths":     hr_chain,
                "chip_temp":  float(t_chip) if t_chip is not None else None,
                "pcb_temp":   None,
                "hw_errors":  hw_c,
                "hw_err_pct": round(hw_c / max(acc_c, 1) * 100, 2),
                "status":     "ok" if hr_chain and hr_chain > 0 else "dead",
            })

        # Temperatura max real: usa chains se disponível
        if chains:
            temps = [c["chip_temp"] for c in chains if c["chip_temp"]]
            if temps:
                temp_max = max(temps)

        return {
            "ip":              ip,
            "ts":              ts,
            "status":          status,
            "hr_realtime_ths": hr_rt,
            "hr_stock_ths":    stock_ths,
            "hr_average_ths":  hr_avg,
            "chip_temp_max":   temp_max,
            "chip_temp_min":   None,
            "pcb_temp_max":    None,
            "fan_duty":        fan_duty,
            "fans":            fans,
            "power_w":         power_w,
            "efficiency_w_th": round(power_w / hr_rt, 2) if (power_w and hr_rt) else None,
            "hw_errors_pct":   hw_errors_pct,
            "pools":           pools_norm,
            "chains":          chains,
            "model":           model,
            "fw_version":      fw_version_str,
            "uptime":          elapsed,
            "alarms":          [],
            "firmware":        "whatsminer",
        }
